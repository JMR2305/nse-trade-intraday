# NSE Algorithmic Trading — Executive Summary

**Generated:** 2026-07-13 21:13:26  
**Git Commit:** `451fe2df83f5` — Add a new phase to expand out-of-sample evidence for analysis  
**System:** Paper trading, research only · ₹5,000 capital · NIFTY 50 universe

---

## Overall Verdict

**Walk-Forward Verdict:** ❓ **INSUFFICIENT DATA**  
**Evidence Expansion (3A.5):** ❓ **None**  

> Only 29 completed out-of-sample trades across 2 test window(s) — at least 100 trades and 2 windows are required for a reliable verdict.

## Key Performance Metrics (Full Model — Variant C)

| Metric | Value |
|--------|-------|
| OOS Trades | 29 |
| Total Return | -3.42% |
| Net P&L | ₹-1,712 |
| Win Rate | 34.50% |
| Profit Factor | 0.70 |
| Expectancy | ₹-59 / trade |
| Sharpe Ratio | -1.04 |
| Max Drawdown | 6.01% |

## Model Comparison

| Model | Trades | Return | Win Rate |
|-------|--------|--------|----------|
| A — Base Technical | 54 | -1.39% | 37.00% |
| C — Full Model | 29 | -3.42% | 34.50% |
| D — Gated Model | 0 | 0.00% | 0.00% |

## Benchmarks

| Benchmark | Return |
|-----------|--------|
| Full Model (compounded) | -3.42% |
| NIFTY 50 Buy & Hold | -5.22% |

## Confidence Calibration

| Metric | Value |
|--------|-------|
| Brier Score | — |
| ECE | — |
| Log Loss | — |

## Phase 3A.5 — Evidence Expansion

| Metric | Value |
|--------|-------|
| Verdict | None |
| OOS Trades | — (target: ≥300) |
| Windows | — (target: ≥8) |
| Expectancy/Trade | — |

## Stability

| Metric | Value |
|--------|-------|
| Profitable Windows | — |
| Concentration Flags | 0 |

## Known Limitations

- Only 50 NIFTY stocks tested — no mid/small-cap coverage.
- Daily candles only — intraday gaps and liquidity are approximated.
- Backfill survivorship bias possible if a stock left NIFTY 50 during test period.
- Short positions are not supported (long-only system).
- Capital limit ₹5,000 constrains position sizing and diversification.
- Confidence calibration re-fits per window but requires ≥10 prior completed trades.
- SEBI/GST/STT rates are hardcoded — changes in tax law are not auto-updated.
- Slippage and spread are estimated; actual market-impact costs may differ.
- Adaptive model weights are version-pinned for the whole run — no intra-run updates.
- Phase 3A.5 evidence targets 300+ OOS trades for PASS; small-window runs are INCONCLUSIVE.

## Run Metadata

| Field | Value |
|-------|-------|
| Generated | 2026-07-13 21:13:26 |
| Git Commit | `451fe2df83f5` |
| Model Version | 0 |
| Universe | 48 stocks |
| Knowledge Trades | 3355 |
| Run Duration | 629.1s |

---

*Out-of-sample historical performance does not guarantee future results. Paper trading and research only. No real orders are placed.*