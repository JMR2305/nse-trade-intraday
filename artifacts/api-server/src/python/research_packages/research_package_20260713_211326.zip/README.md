# NSE Trading Research Package

This package contains all research outputs from one validation run of the
NSE Algorithmic Paper Trading system.

## Contents

| Path | Description |
|------|-------------|
| `executive_summary.md` | High-level narrative summary — start here |
| `chatgpt_report.md` | Upload this single file to ChatGPT instead of screenshots |
| `metadata/run_metadata.json` | Timestamp, git commit, random seed, model version |
| `metadata/config_snapshot.json` | Full ValidationConfig parameters |
| `reports/wf_report.csv` | Overall walk-forward summary |
| `reports/wf_windows.csv` | Per-window metrics for all model variants |
| `reports/wf_evidence_report.csv` | Phase 3A.5 evidence expansion report |
| `trades/wf_trades.csv` | Every simulated OOS trade (full model) |
| `trades/wf_evidence_trades.csv` | OOS trades tagged with Phase 3A.5 metadata |
| `calibration/wf_calibration.csv` | Confidence calibration reliability bands |
| `costs/wf_costs.csv` | Execution cost breakdown |
| `configuration/parameters.json` | Run parameters and cost model |

## Reproducibility

All results are deterministic given the same config and random seed.
The `metadata/run_metadata.json` file contains everything needed to reproduce the run.

## Safety

Out-of-sample historical performance does not guarantee future results. Paper trading and research only. No real orders are placed.
