Research report CSV export
Experiment: 95a7ff31918c
Report version: 2
Generated: 2026-07-14T13:07:34.372553+00:00

Research only — out-of-sample historical performance does not guarantee future results. This report does not affect live or paper-trading strategy selection.
