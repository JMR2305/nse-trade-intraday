RESEARCH NOTEBOOK ARCHIVE — NSE Trader (PAPER / RESEARCH ONLY)
================================================================

Generated: 2026-08-09T09:32:02.488725+00:00

Contents
--------
daily/            One JSON per trading-day notebook entry (draft or finalized)
reviews/          Weekly review, monthly review, evidence accumulation report
issues/           Operational issue log (CSV + JSON)
notes/            All user notes and lessons (CSV)
validation/       Latest Phase 17 QA summary attached for context
trade_links.json  Trade IDs referenced by notebook entries → use Trade Replay

Integrity
---------
- Every entry records its source scan ID, snapshot timestamp, data provider,
  model version and creation/update timestamps.
- live_execution_enabled is false everywhere. No live orders are possible.
- Missing data is marked "Insufficient Data" — nothing is fabricated.
- Credentials, secrets, tokens and broker-private data are excluded.

This archive is a research audit record only. It contains no investment advice.
