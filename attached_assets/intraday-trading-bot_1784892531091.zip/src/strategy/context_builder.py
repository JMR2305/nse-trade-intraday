from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Dict, List, Optional

from src.market_data.contracts import CompletedBar
from src.strategy.contracts import StrategyConfig, StrategyContext

logger = logging.getLogger(__name__)


class ContextBuilder:
    """Builds StrategyContext for each bar cycle.

    RC-10A: Optionally injects market intelligence data.
    RC-10B: Optionally injects AI forecast data.
    """

    def __init__(
        self,
        indicator_engine: Optional[Any] = None,
        regime_detector: Optional[Any] = None,
        announcement_service: Optional[Any] = None,
        watchlist_ranker: Optional[Any] = None,
        ai_forecast_adapter: Optional[Any] = None,
        confidence_gate: Optional[Any] = None,
        volatility_forecaster: Optional[Any] = None,
    ) -> None:
        self._indicator_engine = indicator_engine
        self._regime_detector = regime_detector
        self._announcement_service = announcement_service
        self._watchlist_ranker = watchlist_ranker
        self._ai_forecast = ai_forecast_adapter
        self._confidence_gate = confidence_gate
        self._volatility_forecaster = volatility_forecaster

    def build(
        self,
        config: StrategyConfig,
        state_snapshot: Dict[str, Any],
        bar: Optional[CompletedBar] = None,
    ) -> StrategyContext:
        """Build strategy context. Preserves pre-RC-10 behavior when intelligence not injected."""
        market_snapshots: Dict[str, Any] = {}

        # RC-10A: Populate market intelligence if available
        if self._indicator_engine is not None:
            for token in config.instrument_tokens:
                mtf_data: Dict[str, Any] = {}
                try:
                    all_tf = self._indicator_engine.get_all_timeframes(token)
                    mtf_data["timeframes"] = all_tf
                except Exception as e:
                    logger.debug("IndicatorEngine failed for %s: %s", token, e)

                # Regime detection
                if self._regime_detector is not None and "timeframes" in mtf_data:
                    try:
                        regime_tf = None
                        for tf in ["15m", "1h", "5m", "1m"]:
                            if tf in mtf_data["timeframes"]:
                                regime_tf = tf
                                break
                        if regime_tf:
                            indicators = mtf_data["timeframes"][regime_tf]
                            regime = self._regime_detector.detect(token, indicators)
                            mtf_data["regime"] = regime
                    except Exception as e:
                        logger.debug("Regime detection failed for %s: %s", token, e)

                # Announcements
                if self._announcement_service is not None:
                    try:
                        announcements = self._announcement_service.get_active_announcements_sync(token)
                        mtf_data["active_announcements"] = announcements
                    except Exception as e:
                        logger.debug("Announcement service failed for %s: %s", token, e)

                # RC-10B: AI forecast enrichment
                if self._ai_forecast is not None and self._confidence_gate is not None:
                    try:
                        from src.ai_forecast.features import FeatureGenerator
                        from src.market_intelligence.multi_timeframe_context import MultiTimeframeContext

                        # Build MTF context for feature generation
                        mtf = MultiTimeframeContext(
                            instrument_token=token,
                            snapshot_timestamp=__import__('datetime').datetime.utcnow(),
                            timeframes=mtf_data.get("timeframes", {}),
                            regime=mtf_data.get("regime"),
                            active_announcements=mtf_data.get("active_announcements", []),
                        )

                        # Generate features
                        feature_gen = FeatureGenerator()
                        features = feature_gen.generate(
                            instrument_token=token,
                            mtf_context=mtf,
                            generated_at=__import__('datetime').datetime.utcnow().isoformat(),
                        )

                        # Get forecast
                        forecast = self._ai_forecast.forecast(
                            instrument_token=token,
                            features=features,
                            horizon="15m",
                        )

                        if forecast is not None:
                            gated = self._confidence_gate.apply(forecast)
                            if gated is not None:
                                mtf_data["ai_forecast"] = {
                                    "direction": gated.direction,
                                    "confidence": str(gated.confidence),
                                    "model_version": gated.model_version,
                                }
                    except Exception as e:
                        logger.debug("AI forecast enrichment failed for %s: %s", token, e)

                # RC-10B: Volatility forecast
                if self._volatility_forecaster is not None and "timeframes" in mtf_data:
                    try:
                        from src.market_data.contracts import CompletedBar
                        # Build bars from timeframe data for volatility forecast
                        bars = []
                        for tf_name, tf_indicators in mtf_data["timeframes"].items():
                            # We don't have raw bars here, skip for now
                            pass
                    except Exception as e:
                        logger.debug("Volatility forecast failed for %s: %s", token, e)

                if mtf_data:
                    market_snapshots[token] = mtf_data

        return StrategyContext(
            strategy_id=config.strategy_id,
            instrument_tokens=list(config.instrument_tokens),
            current_positions=state_snapshot.get("current_positions", {}),
            portfolio_snapshot=state_snapshot.get("portfolio_snapshot"),
            market_snapshots=market_snapshots,
            risk_state=state_snapshot.get("risk_state"),
            session_metadata=state_snapshot.get("session_metadata", {}),
        )
