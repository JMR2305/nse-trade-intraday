from __future__ import annotations

import logging
from typing import Optional

from src.execution.contracts import ExecutionOrder, ExecutionOrderSide, ExecutionOrderType
from src.risk.integration_layer import RiskIntegrationLayer
from src.strategy.contracts import Signal, SignalRoutingResult

logger = logging.getLogger(__name__)


class SignalRouter:
    def __init__(
        self,
        risk_layer: RiskIntegrationLayer,
        ai_forecast_adapter: Optional[Any] = None,
        confidence_gate: Optional[Any] = None,
    ) -> None:
        self._risk_layer = risk_layer
        self._ai_forecast = ai_forecast_adapter
        self._confidence_gate = confidence_gate

    async def route(self, signal: Signal, account_id: str) -> SignalRoutingResult:
        # RC-10B: AI forecast enrichment (optional)
        if self._ai_forecast is not None and self._confidence_gate is not None:
            try:
                forecast = await self._ai_forecast.forecast(
                    instrument_token=signal.instrument_token,
                    features=None,  # Would be populated from context
                    horizon="15m",
                )
                if forecast is not None:
                    gated = self._confidence_gate.apply(forecast)
                    if gated is not None:
                        # Enrich signal metadata with forecast
                        enriched_metadata = dict(signal.metadata)
                        enriched_metadata["ai_forecast"] = {
                            "direction": gated.direction,
                            "confidence": str(gated.confidence),
                            "model_version": gated.model_version,
                        }
                        signal = Signal(
                            signal_id=signal.signal_id,
                            strategy_id=signal.strategy_id,
                            instrument_token=signal.instrument_token,
                            action=signal.action,
                            side=signal.side,
                            quantity=signal.quantity,
                            order_type=signal.order_type,
                            limit_price=signal.limit_price,
                            trigger_price=signal.trigger_price,
                            metadata=enriched_metadata,
                        )
                        logger.info(
                            "Signal enriched with AI forecast",
                            extra={
                                "signal_id": signal.signal_id,
                                "instrument_token": signal.instrument_token,
                                "forecast_direction": gated.direction,
                                "forecast_confidence": str(gated.confidence),
                            },
                        )
            except Exception as e:
                logger.warning("AI forecast enrichment failed: %s", e, exc_info=True)

        side = ExecutionOrderSide.BUY if signal.side == "BUY" else ExecutionOrderSide.SELL
        order = ExecutionOrder(
            client_order_id=signal.signal_id,
            instrument_token=signal.instrument_token,
            side=side,
            order_type=ExecutionOrderType(signal.order_type),
            quantity=signal.quantity,
            limit_price=signal.limit_price,
            trigger_price=signal.trigger_price,
        )

        result = await self._risk_layer.submit_order(account_id, order)

        if result.approved:
            return SignalRoutingResult(
                signal_id=signal.signal_id,
                routed=True,
                client_order_id=signal.signal_id,
            )
        else:
            return SignalRoutingResult(
                signal_id=signal.signal_id,
                routed=False,
                rejection_reason="; ".join(
                    v.message for v in result.violations
                ),
            )
