from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class SignalAction(str, Enum):
    ENTER_LONG = "ENTER_LONG"
    ENTER_SHORT = "ENTER_SHORT"
    EXIT_LONG = "EXIT_LONG"
    EXIT_SHORT = "EXIT_SHORT"
    HOLD = "HOLD"


class StrategyLifecycleState(str, Enum):
    REGISTERED = "REGISTERED"
    STARTING = "STARTING"
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    ERROR = "ERROR"


class ConflictResolution(str, Enum):
    KEEP_EXISTING = "KEEP_EXISTING"
    REPLACE = "REPLACE"
    REJECT = "REJECT"


class Signal(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    signal_id: str
    strategy_id: str
    instrument_token: str
    action: SignalAction
    side: str
    quantity: Decimal
    order_type: str = "MARKET"
    limit_price: Optional[Decimal] = None
    trigger_price: Optional[Decimal] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class StrategyConfig(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    strategy_id: str
    strategy_type: str
    name: str
    instrument_tokens: List[str] = Field(default_factory=list)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    max_position_quantity: Decimal = Decimal("1000")
    enabled: bool = True


# RC-10B: AI Forecast Metadata
class AiForecastMetadata(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    direction: str
    confidence: Decimal
    model_version: str
    forecast_horizon: str = "15m"
    price_target: Optional[Decimal] = None


class StrategyContext(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    strategy_id: str
    instrument_tokens: List[str] = Field(default_factory=list)
    current_positions: Dict[str, Any] = Field(default_factory=dict)
    portfolio_snapshot: Optional[Dict[str, Any]] = None
    market_snapshots: Dict[str, Any] = Field(default_factory=dict)
    risk_state: Optional[Dict[str, Any]] = None
    session_metadata: Dict[str, Any] = Field(default_factory=dict)


class StrategyStateSnapshot(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    strategy_id: str
    lifecycle_state: StrategyLifecycleState
    pending_order_ids: List[str] = Field(default_factory=list)
    latest_signal_timestamp: Optional[str] = None
    emitted_signal_count: int = 0
    routed_signal_count: int = 0
    rejected_signal_count: int = 0
    fill_count: int = 0


class StrategyPerformanceSnapshot(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    strategy_id: str
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: Decimal = Decimal("0")
    realized_pnl: Decimal = Decimal("0")
    max_drawdown: Decimal = Decimal("0")
    max_drawdown_pct: Decimal = Decimal("0")
    sharpe_ratio: Decimal = Decimal("0")


class SignalRoutingResult(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    signal_id: str
    routed: bool
    client_order_id: Optional[str] = None
    rejection_reason: Optional[str] = None


class StrategyRegistrationResult(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    strategy_id: str
    success: bool
    message: str = ""
    previous_state: Optional[str] = None
