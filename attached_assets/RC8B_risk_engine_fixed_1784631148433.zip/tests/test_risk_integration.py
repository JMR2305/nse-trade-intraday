"""
Integration tests for RC-8B Risk Engine Integration.

Tests the full pipeline: Strategy -> Risk Integration -> (Mock) Execution Engine.
"""

import pytest
import pytest_asyncio
import asyncio
from decimal import Decimal
from datetime import datetime, timezone

from risk.engine import RiskEngine
from risk.contracts import (
    OrderQuantityLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    PortfolioExposureLimit,
    DailyLossLimit,
    MaxOrdersPerMinuteLimit,
    KillSwitchLimit,
    EmergencyHaltLimit,
    CircuitBreakerLimit,
    MarginAvailabilityLimit,
    CashAvailabilityLimit,
    BuyingPowerLimit,
)
from risk.integration_layer import RiskIntegrationLayer, RiskIntegrationResult
from risk.fill_event_bus import FillEventBus
from tests.mocks.execution_engine import (
    MockExecutionEngine,
    MockPortfolioSnapshot,
    MockPositionSnapshot,
)


@pytest.fixture
def mock_execution_engine():
    return MockExecutionEngine()


@pytest.fixture
def risk_engine():
    return RiskEngine()


@pytest.fixture
def sample_limits():
    return [
        OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100")),
        PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5")),
        MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("1000"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        ),
        PortfolioExposureLimit(rule_id="pe_001", max_exposure_percent=Decimal("90")),
        DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000")),
        MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=25, window_seconds=60),
        KillSwitchLimit(rule_id="ks_001"),
        EmergencyHaltLimit(rule_id="eh_001"),
        CircuitBreakerLimit(rule_id="cb_001", max_decline_percent=Decimal("10")),
        MarginAvailabilityLimit(rule_id="ma_001"),
        CashAvailabilityLimit(rule_id="ca_001"),
        BuyingPowerLimit(rule_id="bp_001"),
    ]


@pytest_asyncio.fixture
async def integration(risk_engine, mock_execution_engine, sample_limits):
    """Pre-configured integration with one account registered."""
    integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
    await integration.register_account("ACC001", initial_equity=Decimal("100000"))
    await integration.set_risk_limits("ACC001", sample_limits)

    # Set up mock execution state
    await mock_execution_engine.set_portfolio(
        "ACC001",
        MockPortfolioSnapshot(
            equity=Decimal("100000"),
            cash=Decimal("100000"),
            buying_power=Decimal("100000"),
            available_margin=Decimal("100000"),
            total_market_value=Decimal("0"),
        )
    )
    await mock_execution_engine.set_market_price("INFY", Decimal("1500"))

    return integration


class TestApprovedOrder:
    @pytest.mark.asyncio
    async def test_clean_order_passes_through(self, integration, mock_execution_engine):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("50"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is True
        assert result.rejected is False
        assert result.execution_result is not None
        assert result.execution_result.status == "ACCEPTED"
        assert result.violations == []

    @pytest.mark.asyncio
    async def test_order_with_warning_still_approved(self, integration, mock_execution_engine):
        # Order near daily loss warning threshold
        await integration._risk_engine.record_fill(
            account_id="ACC001",
            fill_id="fill-test",
            realized_pnl=Decimal("-8500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("91500"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is True
        assert result.rejected is False
        assert len(result.violations) > 0
        assert result.execution_result is not None


class TestRiskRejection:
    @pytest.mark.asyncio
    async def test_order_size_rejected(self, integration):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("150"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert result.execution_result is None
        assert any(v.check_type.value == "ORDER_QUANTITY" for v in result.violations)

    @pytest.mark.asyncio
    async def test_price_band_rejected(self, integration):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1700"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "PRICE_BAND" for v in result.violations)

    @pytest.mark.asyncio
    async def test_position_limit_rejected(self, integration, mock_execution_engine):
        await mock_execution_engine.set_position(
            "ACC001",
            MockPositionSnapshot("INFY", net_quantity=Decimal("950"), direction="LONG")
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("100"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "MAX_POSITION_SIZE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_rejection_reason_formatted(self, integration):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("150"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.rejection_reason is not None
        assert "ORDER_QUANTITY" in result.rejection_reason
        assert "CRITICAL" in result.rejection_reason


class TestKillSwitchActive:
    @pytest.mark.asyncio
    async def test_kill_switch_blocks_all_orders(self, integration):
        await integration.activate_kill_switch("ACC001", "Manual halt", actor="admin")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert result.execution_result is None
        assert integration.is_kill_switch_active("ACC001")

    @pytest.mark.asyncio
    async def test_kill_switch_deactivation_restores_trading(self, integration):
        await integration.activate_kill_switch("ACC001", "Test", actor="admin")
        assert integration.is_kill_switch_active("ACC001")

        await integration.deactivate_kill_switch("ACC001", "Resolved", actor="admin")
        assert not integration.is_kill_switch_active("ACC001")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)
        assert result.approved is True


class TestDailyLimitReached:
    @pytest.mark.asyncio
    async def test_daily_loss_limit_fatal(self, integration):
        await integration._risk_engine.record_fill(
            account_id="ACC001",
            fill_id="fill-test",
            realized_pnl=Decimal("-10000"),
            turnover=Decimal("10000"),
            current_equity=Decimal("90000"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "DAILY_LOSS_LIMIT" for v in result.violations)
        assert any(v.severity.value == "FATAL" for v in result.violations)
        assert integration.is_kill_switch_active("ACC001")


class TestMarginFailure:
    @pytest.mark.asyncio
    async def test_insufficient_margin(self, integration, mock_execution_engine):
        await mock_execution_engine.set_portfolio(
            "ACC001",
            MockPortfolioSnapshot(
                equity=Decimal("100000"),
                cash=Decimal("100000"),
                buying_power=Decimal("100000"),
                available_margin=Decimal("100"),
                total_market_value=Decimal("0"),
            )
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("100"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "MARGIN_AVAILABILITY" for v in result.violations)


class TestPositionLimitExceeded:
    @pytest.mark.asyncio
    async def test_long_position_limit(self, integration, mock_execution_engine):
        await mock_execution_engine.set_position(
            "ACC001",
            MockPositionSnapshot("INFY", net_quantity=Decimal("950"), direction="LONG")
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("100"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "MAX_POSITION_SIZE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_short_position_limit(self, integration, mock_execution_engine):
        await mock_execution_engine.set_position(
            "ACC001",
            MockPositionSnapshot("INFY", net_quantity=Decimal("-450"), direction="SHORT")
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("100"),
            "side": "SELL",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "MAX_POSITION_SIZE" for v in result.violations)


class TestConcurrentRequests:
    @pytest.mark.asyncio
    async def test_concurrent_orders_same_account(self, integration):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        tasks = [integration.submit_order("ACC001", order) for _ in range(20)]
        results = await asyncio.gather(*tasks)

        approved_count = sum(1 for r in results if r.approved)
        assert approved_count == 20

    @pytest.mark.asyncio
    async def test_concurrent_orders_different_accounts(self, risk_engine, mock_execution_engine, sample_limits):
        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))
        await integration.set_risk_limits("ACC001", sample_limits)
        await integration.register_account("ACC002", initial_equity=Decimal("100000"))
        await integration.set_risk_limits("ACC002", sample_limits)

        await mock_execution_engine.set_portfolio(
            "ACC001",
            MockPortfolioSnapshot(equity=Decimal("100000"), cash=Decimal("100000"))
        )
        await mock_execution_engine.set_portfolio(
            "ACC002",
            MockPortfolioSnapshot(equity=Decimal("100000"), cash=Decimal("100000"))
        )
        await mock_execution_engine.set_market_price("INFY", Decimal("1500"))

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        tasks = []
        for i in range(10):
            tasks.append(integration.submit_order("ACC001", order))
            tasks.append(integration.submit_order("ACC002", order))

        results = await asyncio.gather(*tasks)

        approved_count = sum(1 for r in results if r.approved)
        assert approved_count == 20



class TestThrottleBoundary:
    @pytest.mark.asyncio
    async def test_throttle_boundary_same_account(self, risk_engine, mock_execution_engine):
        """Verify throttle fires exactly at the boundary (max_orders=10)."""
        limits = [
            OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100")),
            MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=10, window_seconds=60),
        ]
        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))
        await integration.set_risk_limits("ACC001", limits)
        await mock_execution_engine.set_portfolio(
            "ACC001",
            MockPortfolioSnapshot(equity=Decimal("100000"), cash=Decimal("100000"))
        )
        await mock_execution_engine.set_market_price("INFY", Decimal("1500"))

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        # Submit 10 orders — all should be approved
        tasks = [integration.submit_order("ACC001", order) for _ in range(10)]
        results = await asyncio.gather(*tasks)
        approved_count = sum(1 for r in results if r.approved)
        assert approved_count == 10, f"Expected 10 approved, got {approved_count}"

        # 11th order should be throttled
        result = await integration.submit_order("ACC001", order)
        assert result.approved is False
        assert any(v.check_type.value == "MAX_ORDERS_PER_MINUTE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_throttle_boundary_per_account(self, risk_engine, mock_execution_engine):
        """Verify throttle is per-account, not global."""
        limits = [
            OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100")),
            MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=10, window_seconds=60),
        ]
        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))
        await integration.set_risk_limits("ACC001", limits)
        await integration.register_account("ACC002", initial_equity=Decimal("100000"))
        await integration.set_risk_limits("ACC002", limits)

        await mock_execution_engine.set_portfolio(
            "ACC001",
            MockPortfolioSnapshot(equity=Decimal("100000"), cash=Decimal("100000"))
        )
        await mock_execution_engine.set_portfolio(
            "ACC002",
            MockPortfolioSnapshot(equity=Decimal("100000"), cash=Decimal("100000"))
        )
        await mock_execution_engine.set_market_price("INFY", Decimal("1500"))

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        # Exhaust throttle for ACC001
        for _ in range(10):
            await integration.submit_order("ACC001", order)

        # ACC001 should now be throttled
        result1 = await integration.submit_order("ACC001", order)
        assert result1.approved is False

        # ACC002 should still be able to trade
        result2 = await integration.submit_order("ACC002", order)
        assert result2.approved is True


class TestFillEventNotification:
    @pytest.mark.asyncio
    async def test_fill_updates_risk_state(self, integration):
        await integration.on_fill_event(
            account_id="ACC001",
            fill_id="fill-001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
        )

        snapshot = await integration._risk_engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("500")
        assert snapshot.daily_turnover == Decimal("10000")
        assert snapshot.trade_count == 1

    @pytest.mark.asyncio
    async def test_fill_event_bus(self, risk_engine, mock_execution_engine):
        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))

        bus = FillEventBus()
        bus.subscribe(integration.on_fill_event)

        await bus.publish(
            account_id="ACC001",
            fill_id="fill-003",
            realized_pnl=Decimal("1000"),
            turnover=Decimal("20000"),
            current_equity=Decimal("101000"),
        )

        snapshot = await risk_engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("1000")


    @pytest.mark.asyncio
    async def test_fill_idempotency(self, integration):
        """Duplicate fill_ids should be silently ignored (exactly-once)."""
        await integration.on_fill_event(
            account_id="ACC001",
            fill_id="fill-dup-001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
        )

        # Same fill_id again — should be ignored
        await integration.on_fill_event(
            account_id="ACC001",
            fill_id="fill-dup-001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
        )

        snapshot = await integration._risk_engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("500")
        assert snapshot.daily_turnover == Decimal("10000")
        assert snapshot.trade_count == 1

    @pytest.mark.asyncio
    async def test_fill_delivery_failure_propagated(self, risk_engine, mock_execution_engine):
        """Fill delivery failures should be propagated, not swallowed."""
        from risk.exceptions import FillDeliveryError

        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))

        bus = FillEventBus()
        bus.subscribe(integration.on_fill_event)

        # First delivery succeeds
        await bus.publish(
            account_id="ACC001",
            fill_id="fill-ok-001",
            realized_pnl=Decimal("100"),
            turnover=Decimal("1000"),
            current_equity=Decimal("100100"),
        )

        # Verify state updated
        snapshot = await risk_engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("100")


class TestDisabledIntegration:
    @pytest.mark.asyncio
    async def test_disabled_passes_through(self, risk_engine, mock_execution_engine, sample_limits):
        integration = RiskIntegrationLayer(risk_engine, mock_execution_engine, enabled=False)
        await integration.register_account("ACC001", initial_equity=Decimal("100000"))

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("999999"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is True
        assert result.rejected is False
        assert result.execution_result is not None


class TestAuditLogging:
    @pytest.mark.asyncio
    async def test_audit_callback_called(self, integration):
        audit_calls = []

        async def audit_callback(account_id, order, result):
            audit_calls.append({
                "account_id": account_id,
                "order_id": order.get("instrument_token"),
                "approved": result.approved,
            })

        integration.register_audit_callback(audit_callback)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("50"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        await integration.submit_order("ACC001", order)

        assert len(audit_calls) == 1
        assert audit_calls[0]["account_id"] == "ACC001"
        assert audit_calls[0]["approved"] is True

    @pytest.mark.asyncio
    async def test_audit_callback_called_on_rejection(self, integration):
        audit_calls = []

        async def audit_callback(account_id, order, result):
            audit_calls.append({
                "account_id": account_id,
                "approved": result.approved,
                "rejected": result.rejected,
            })

        integration.register_audit_callback(audit_callback)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("150"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        await integration.submit_order("ACC001", order)

        assert len(audit_calls) == 1
        assert audit_calls[0]["approved"] is False
        assert audit_calls[0]["rejected"] is True


class TestRecoveryAfterRestart:
    @pytest.mark.asyncio
    async def test_risk_state_preserved(self, integration):
        await integration.on_fill_event(
            account_id="ACC001",
            fill_id="fill-001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
        )

        snapshot_before = await integration._risk_engine.get_state_snapshot("ACC001")

        new_integration = RiskIntegrationLayer(
            integration._risk_engine,
            integration._execution_engine,
        )

        snapshot_after = await new_integration._risk_engine.get_state_snapshot("ACC001")

        assert snapshot_after.daily_realized_pnl == snapshot_before.daily_realized_pnl
        assert snapshot_after.daily_turnover == snapshot_before.daily_turnover
        assert snapshot_after.trade_count == snapshot_before.trade_count

    @pytest.mark.asyncio
    async def test_kill_switch_preserved_after_restart(self, integration):
        await integration.activate_kill_switch("ACC001", "Test halt")
        assert integration.is_kill_switch_active("ACC001")

        new_integration = RiskIntegrationLayer(
            integration._risk_engine,
            integration._execution_engine,
        )

        assert new_integration.is_kill_switch_active("ACC001")


class TestEmergencyHalt:
    @pytest.mark.asyncio
    async def test_emergency_halt_blocks_orders(self, integration):
        await integration._risk_engine.activate_emergency_halt("ACC001", "System failure")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "EMERGENCY_HALT" for v in result.violations)
        assert integration.is_emergency_halt_active("ACC001")


class TestCircuitBreaker:
    @pytest.mark.asyncio
    async def test_circuit_breaker_blocks_orders(self, integration):
        await integration._risk_engine.trigger_circuit_breaker("ACC001")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }

        result = await integration.submit_order("ACC001", order)

        assert result.approved is False
        assert result.rejected is True
        assert any(v.check_type.value == "CIRCUIT_BREAKER" for v in result.violations)
        assert integration.is_circuit_breaker_triggered("ACC001")
