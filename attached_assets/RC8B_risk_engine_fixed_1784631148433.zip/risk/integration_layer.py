"""
RC-8B Risk Engine Integration Layer.

Sits between the Strategy Layer and the RC-7 Execution Engine.
Every order is validated by the Risk Engine before reaching execution.

Design principles:
- Pure gate: does not modify execution state
- Adapter pattern: transforms execution state into risk inputs
- Event-driven: fill notifications via event bus (no circular deps)
- Backward compatible: can be disabled via feature flag
- Deterministic and async-safe
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional, Dict, Any, List, Protocol
from datetime import datetime, timezone
import asyncio
import logging

from risk.engine import RiskEngine
from risk.contracts import (
    RiskResult,
    RiskViolation,
    RiskSeverity,
    RiskConfiguration,
    RiskStateSnapshot,
)
from risk.exceptions import RiskEngineException

logger = logging.getLogger(__name__)


class ExecutionEnginePort(Protocol):
    """Minimal interface the Risk Integration needs from the Execution Engine.

    The RC-7 Execution Engine must expose these methods for risk integration.
    This is a Protocol — no inheritance required, just duck typing.
    """

    async def get_portfolio_snapshot(self, account_id: str) -> Optional[Any]:
        """Return current portfolio snapshot for account, or None."""
        ...

    async def get_position_snapshots(self, account_id: str) -> Dict[str, Any]:
        """Return dict of instrument_token -> PositionSnapshot for account."""
        ...

    async def get_open_orders(self, account_id: str) -> List[Any]:
        """Return list of currently open (pending) orders for account."""
        ...

    async def get_market_price(self, instrument_token: str) -> Optional[Decimal]:
        """Return last traded price for instrument, or None if unavailable."""
        ...

    async def submit_order(self, account_id: str, order: Any) -> Any:
        """Submit order to execution engine. Returns OrderResult."""
        ...


class RiskIntegrationResult:
    """Result of an integrated order submission attempt.

    Wraps both the Risk Engine's decision and (if approved) the Execution Engine's result.
    """

    def __init__(
        self,
        risk_result: RiskResult,
        execution_result: Optional[Any] = None,
        rejected: bool = False,
        rejection_reason: Optional[str] = None,
    ):
        self.risk_result: RiskResult = risk_result
        self.execution_result: Optional[Any] = execution_result
        self.rejected: bool = rejected
        self.rejection_reason: Optional[str] = rejection_reason

    @property
    def approved(self) -> bool:
        return self.risk_result.approved

    @property
    def is_blocked(self) -> bool:
        return self.risk_result.is_blocked

    @property
    def violations(self) -> List[RiskViolation]:
        return self.risk_result.violations

    def __repr__(self) -> str:
        if self.rejected:
            return f"RiskIntegrationResult(REJECTED: {self.rejection_reason})"
        if self.execution_result is not None:
            return f"RiskIntegrationResult(APPROVED -> {self.execution_result})"
        return f"RiskIntegrationResult(APPROVED, no execution)"


class RiskIntegrationLayer:
    """Integrates the Risk Engine into the pre-trade execution flow.

    Usage:
        integration = RiskIntegrationLayer(risk_engine, execution_engine)
        result = await integration.submit_order(account_id, order)
        if result.rejected:
            # Handle rejection
        else:
            # Order submitted to execution

    Attributes:
        _risk_engine: The RiskEngine instance.
        _execution_engine: The RC-7 Execution Engine (via Protocol).
        _enabled: Feature flag — when False, orders pass through unchecked.
        _audit_callbacks: List of callbacks for audit logging.
        _lock: Per-account locks for thread safety.
    """

    def __init__(
        self,
        risk_engine: RiskEngine,
        execution_engine: ExecutionEnginePort,
        enabled: bool = True,
    ):
        self._risk_engine: RiskEngine = risk_engine
        self._execution_engine: ExecutionEnginePort = execution_engine
        self._enabled: bool = enabled
        self._audit_callbacks: List[Any] = []
        self._locks: Dict[str, asyncio.Lock] = {}
        self._global_lock: asyncio.Lock = asyncio.Lock()

    def disable(self) -> None:
        """Disable risk checking — orders pass through to execution unchecked."""
        logger.warning("Risk Integration Layer DISABLED — orders will not be checked")
        self._enabled = False

    def enable(self) -> None:
        """Enable risk checking."""
        logger.info("Risk Integration Layer ENABLED")
        self._enabled = True

    def register_audit_callback(self, callback: Any) -> None:
        """Register a callback for audit logging.

        Callback signature: async fn(account_id, order, risk_result, execution_result)
        """
        self._audit_callbacks.append(callback)

    async def submit_order(
        self,
        account_id: str,
        order: Any,
    ) -> RiskIntegrationResult:
        """Submit an order through the risk-checked pipeline.

        Flow:
        1. If disabled, pass through directly to execution engine.
        2. Gather execution state (portfolio, positions, prices, open orders).
        3. Run pre-trade risk check.
        4. If rejected: log audit, return rejection.
        5. If approved: submit to execution engine, log audit, return result.

        Args:
            account_id: Account submitting the order.
            order: The order to submit (format depends on Execution Engine).

        Returns:
            RiskIntegrationResult with risk decision and (if approved) execution result.
        """
        # Fast path: risk checking disabled
        if not self._enabled:
            logger.debug(f"Risk check disabled, passing order through for {account_id}")
            execution_result = await self._execution_engine.submit_order(account_id, order)
            # Create a synthetic "approved" risk result for consistency
            risk_result = RiskResult(
                approved=True,
                violations=[],
                check_timestamp=datetime.now(timezone.utc),
                order_id=self._get_order_id(order),
                account_id=account_id,
            )
            result = RiskIntegrationResult(
                risk_result=risk_result,
                execution_result=execution_result,
            )
            await self._audit(result, account_id, order)
            return result

        # Acquire per-account lock for atomicity
        lock = await self._get_account_lock(account_id)
        async with lock:
            try:
                # 1. Gather execution state for risk context
                portfolio_snapshot = await self._execution_engine.get_portfolio_snapshot(account_id)
                position_snapshots = await self._execution_engine.get_position_snapshots(account_id)
                open_orders = await self._execution_engine.get_open_orders(account_id)

                # Get market price for the order's instrument
                instrument_token = self._get_instrument_token(order)
                market_prices: Dict[str, Decimal] = {}
                if instrument_token:
                    price = await self._execution_engine.get_market_price(instrument_token)
                    if price is not None:
                        market_prices[instrument_token] = price

                # 2. Run pre-trade risk check
                logger.info(f"Running risk check for {account_id} order {self._get_order_id(order)}")
                risk_result = await self._risk_engine.pre_trade_check(
                    account_id=account_id,
                    order=order,
                    portfolio_snapshot=portfolio_snapshot,
                    position_snapshots=position_snapshots,
                    market_prices=market_prices,
                    open_orders=open_orders,
                    check_timestamp=datetime.now(timezone.utc),
                )

                # 3. Handle rejection
                if not risk_result.approved:
                    rejection_reason = self._format_rejection_reason(risk_result)
                    logger.warning(
                        f"Order REJECTED for {account_id}: {rejection_reason}"
                    )
                    result = RiskIntegrationResult(
                        risk_result=risk_result,
                        rejected=True,
                        rejection_reason=rejection_reason,
                    )
                    await self._audit(result, account_id, order)
                    return result

                # 4. Approved — submit to execution engine
                logger.info(f"Order APPROVED for {account_id}, submitting to execution")
                execution_result = await self._execution_engine.submit_order(account_id, order)

                result = RiskIntegrationResult(
                    risk_result=risk_result,
                    execution_result=execution_result,
                )
                await self._audit(result, account_id, order)
                return result

            except RiskEngineException as e:
                # Risk engine internal error — fail-safe: reject the order
                logger.error(f"Risk engine error for {account_id}: {e}", exc_info=True)
                risk_result = RiskResult(
                    approved=False,
                    violations=[],
                    check_timestamp=datetime.now(timezone.utc),
                    order_id=self._get_order_id(order),
                    account_id=account_id,
                )
                result = RiskIntegrationResult(
                    risk_result=risk_result,
                    rejected=True,
                    rejection_reason=f"Risk engine internal error: {e}",
                )
                await self._audit(result, account_id, order)
                return result

            except Exception as e:
                # Unknown error — fail-safe: reject the order
                logger.critical(f"Unexpected error in risk integration for {account_id}: {e}", exc_info=True)
                risk_result = RiskResult(
                    approved=False,
                    violations=[],
                    check_timestamp=datetime.now(timezone.utc),
                    order_id=self._get_order_id(order),
                    account_id=account_id,
                )
                result = RiskIntegrationResult(
                    risk_result=risk_result,
                    rejected=True,
                    rejection_reason=f"Integration error: {e}",
                )
                await self._audit(result, account_id, order)
                return result

    async def on_fill_event(
        self,
        account_id: str,
        fill_id: str,
        realized_pnl: Decimal,
        turnover: Decimal,
        current_equity: Decimal,
        fill_timestamp: Optional[datetime] = None,
    ) -> None:
        """Notify the Risk Engine of a fill event.

        This should be called by the Execution Engine (or event bus subscriber)
        after every fill. It updates the Risk Engine's internal state
        (daily P&L, trade counts, peak equity, etc.).

        Args:
            account_id: Account that received the fill.
            fill_id: Unique identifier for this fill event.
            realized_pnl: Realized P&L from the fill.
            turnover: Turnover value of the fill.
            current_equity: Current portfolio equity after the fill.
            fill_timestamp: When the fill occurred.

        Raises:
            Exception: Re-raised from record_fill so the caller (event bus)
                knows delivery failed and can retry.
        """
        if fill_timestamp is None:
            fill_timestamp = datetime.now(timezone.utc)

        await self._risk_engine.record_fill(
            account_id=account_id,
            fill_id=fill_id,
            realized_pnl=realized_pnl,
            turnover=turnover,
            current_equity=current_equity,
            fill_timestamp=fill_timestamp,
        )
        logger.debug(f"Fill recorded for {account_id}: PnL={realized_pnl}, Turnover={turnover}, fill_id={fill_id}")

    async def set_risk_limits(
        self,
        account_id: str,
        limits: List[RiskConfiguration],
    ) -> None:
        """Set risk limits for an account."""
        await self._risk_engine.set_limits(account_id, limits)
        logger.info(f"Set {len(limits)} risk limits for {account_id}")

    async def register_account(
        self,
        account_id: str,
        initial_equity: Decimal = Decimal("0"),
        limits: Optional[List[RiskConfiguration]] = None,
    ) -> None:
        """Register an account with both risk and execution engines."""
        await self._risk_engine.register_account(account_id, initial_equity, limits)
        logger.info(f"Registered account {account_id} with risk integration")

    async def activate_kill_switch(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
    ) -> None:
        """Manually activate kill switch for an account."""
        await self._risk_engine.activate_kill_switch(account_id, reason, actor=actor)

    async def deactivate_kill_switch(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
    ) -> None:
        """Manually deactivate kill switch for an account."""
        await self._risk_engine.deactivate_kill_switch(account_id, reason, actor=actor)

    def is_kill_switch_active(self, account_id: str) -> bool:
        """Check if kill switch is active for an account."""
        return self._risk_engine.is_kill_switch_active(account_id)

    def is_emergency_halt_active(self, account_id: str) -> bool:
        """Check if emergency halt is active for an account."""
        return self._risk_engine.is_emergency_halt_active(account_id)

    def is_circuit_breaker_triggered(self, account_id: str) -> bool:
        """Check if circuit breaker is triggered for an account."""
        return self._risk_engine.is_circuit_breaker_triggered(account_id)

    # --- Private helpers ---

    async def _get_account_lock(self, account_id: str) -> asyncio.Lock:
        """Get or create per-account lock."""
        async with self._global_lock:
            if account_id not in self._locks:
                self._locks[account_id] = asyncio.Lock()
            return self._locks[account_id]

    async def _audit(
        self,
        result: RiskIntegrationResult,
        account_id: str,
        order: Any,
    ) -> None:
        """Run all registered audit callbacks."""
        for callback in self._audit_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(account_id, order, result)
                else:
                    callback(account_id, order, result)
            except Exception as e:
                logger.error(f"Audit callback error: {e}", exc_info=True)

    @staticmethod
    def _get_order_id(order: Any) -> Optional[str]:
        if isinstance(order, dict):
            return order.get("order_id") or order.get("client_order_id")
        return getattr(order, "order_id", None) or getattr(order, "client_order_id", None)

    @staticmethod
    def _get_instrument_token(order: Any) -> Optional[str]:
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _format_rejection_reason(risk_result: RiskResult) -> str:
        """Format violations into a human-readable rejection reason."""
        if not risk_result.violations:
            return "Risk check failed (no violations recorded)"

        parts = []
        for v in risk_result.violations:
            parts.append(f"[{v.severity.value}] {v.check_type.value}: {v.message}")
        return "; ".join(parts)
