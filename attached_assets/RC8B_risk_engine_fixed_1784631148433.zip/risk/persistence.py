
"""Stub persistence adapter for testing."""
class RiskEnginePersistenceAdapter:
    pass
