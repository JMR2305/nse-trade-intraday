"""Instrument synchronisation with the broker instrument master.

Fetches exchange-level instruments, validates them, performs batch
upsert/deactivate, and returns a structured summary.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from src.market_data.provider import MarketDataProvider


@dataclass(frozen=True)
class InstrumentSyncResult:
    """Summary of an instrument sync operation."""
    exchange: str
    inserted: int = 0
    updated: int = 0
    deactivated: int = 0
    rejected: int = 0
    errors: list[str] = field(default_factory=list)
    refreshed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class InstrumentSync:
    """Synchronises the local instrument master with the broker.

    Args:
        provider: MarketDataProvider (read-only)
        instrument_repo: existing instrument repository from the project
    """

    def __init__(
        self,
        provider: MarketDataProvider,
        instrument_repo,  # type: ignore  # existing repo, injected
    ) -> None:
        self._provider = provider
        self._instrument_repo = instrument_repo

    async def sync(self, exchange: str = "NSE") -> InstrumentSyncResult:
        """Fetch, validate, and sync instruments for an exchange.

        Returns:
            InstrumentSyncResult with counts and any validation errors.
        """
        result = InstrumentSyncResult(exchange=exchange)

        # 1. Fetch from provider
        raw_instruments = await self._provider.get_instruments(exchange)

        # 2. Validate
        valid_items: list[dict[str, Any]] = []
        for raw in raw_instruments:
            validated, error = self._validate(raw, exchange)
            if error:
                # dataclass is frozen; rebuild
                result = InstrumentSyncResult(
                    exchange=exchange,
                    inserted=result.inserted,
                    updated=result.updated,
                    deactivated=result.deactivated,
                    rejected=result.rejected + 1,
                    errors=result.errors + [error],
                    refreshed_at=result.refreshed_at,
                )
            else:
                valid_items.append(validated)

        # 3. Get existing instruments for this exchange
        existing = await self._instrument_repo.get_all_for_exchange(exchange)
        existing_by_uq: dict[tuple, Any] = {}
        for inst in existing:
            key = (
                inst.exchange,
                inst.tradingsymbol,
                inst.expiry,
                inst.strike,
            )
            existing_by_uq[key] = inst

        fetched_keys: set[tuple] = set()
        for item in valid_items:
            key = (
                item["exchange"],
                item["tradingsymbol"],
                item.get("expiry"),
                item.get("strike"),
            )
            fetched_keys.add(key)

            if key in existing_by_uq:
                # Update
                await self._instrument_repo.update_by_uq(key, item)
                result = InstrumentSyncResult(
                    exchange=exchange,
                    inserted=result.inserted,
                    updated=result.updated + 1,
                    deactivated=result.deactivated,
                    rejected=result.rejected,
                    errors=result.errors,
                    refreshed_at=result.refreshed_at,
                )
            else:
                # Insert
                await self._instrument_repo.insert(item)
                result = InstrumentSyncResult(
                    exchange=exchange,
                    inserted=result.inserted + 1,
                    updated=result.updated,
                    deactivated=result.deactivated,
                    rejected=result.rejected,
                    errors=result.errors,
                    refreshed_at=result.refreshed_at,
                )

        # 4. Deactivate instruments no longer returned
        for key, inst in existing_by_uq.items():
            if key not in fetched_keys:
                await self._instrument_repo.deactivate(inst.instrument_token)
                result = InstrumentSyncResult(
                    exchange=exchange,
                    inserted=result.inserted,
                    updated=result.updated,
                    deactivated=result.deactivated + 1,
                    rejected=result.rejected,
                    errors=result.errors,
                    refreshed_at=result.refreshed_at,
                )

        # 5. Update refresh timestamp
        await self._instrument_repo.update_refresh_timestamp(exchange)

        return result

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def _validate(
        self,
        raw: dict[str, Any],
        expected_exchange: str,
    ) -> tuple[dict[str, Any] | None, str | None]:
        """Validate a raw instrument dict.

        Returns (validated_dict, None) on success, (None, error_message) on failure.
        """
        errors: list[str] = []

        token = raw.get("instrument_token")
        if not isinstance(token, int) or token <= 0:
            errors.append("invalid instrument_token")

        exch = raw.get("exchange", "").upper()
        if exch != expected_exchange.upper():
            errors.append(f"exchange mismatch: {exch} != {expected_exchange}")

        symbol = raw.get("tradingsymbol", "")
        if not symbol or not isinstance(symbol, str):
            errors.append("missing or invalid tradingsymbol")

        lot_size = raw.get("lot_size", 1)
        if not isinstance(lot_size, int) or lot_size <= 0:
            errors.append("invalid lot_size")

        tick_size = raw.get("tick_size", Decimal("0.05"))
        try:
            ts = Decimal(str(tick_size))
            if ts <= 0:
                errors.append("invalid tick_size")
        except Exception:
            errors.append("invalid tick_size")

        if errors:
            return None, "; ".join(errors)

        # Normalise
        return {
            "instrument_token": token,
            "exchange": exch,
            "tradingsymbol": symbol,
            "name": raw.get("name"),
            "instrument_type": raw.get("instrument_type"),
            "segment": raw.get("segment"),
            "expiry": raw.get("expiry"),
            "strike": raw.get("strike"),
            "lot_size": lot_size,
            "tick_size": Decimal(str(tick_size)),
            "is_tradable": raw.get("is_tradable", True),
        }, None
