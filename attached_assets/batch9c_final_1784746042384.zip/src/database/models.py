"""src/database/models.py — flat ORM model file.

All SQLAlchemy declarative models live in this single file.
New models (Batch 9C) are appended below existing models.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

from src.database.connection import Base


# =====================================================================
# EXISTING MODELS (assumed already present in the file):
# Account, Position, Order, OrderLeg, Trade, RiskProfile, etc.
# =====================================================================


# =====================================================================
# BATCH 9C — Strategy Persistence Models (APPENDED)
# =====================================================================

class StrategyModel(Base):
    """ORM model for the strategies table.

    Stores strategy registration, type, configuration, instrument tokens,
    lifecycle state, and timestamps. strategy_id is the natural key.
    """

    __tablename__ = "strategies"

    id = sa.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    strategy_id = sa.Column(sa.String(64), nullable=False, index=True)
    strategy_type = sa.Column(sa.String(64), nullable=False)
    name = sa.Column(sa.String(255), nullable=False)
    account_id = sa.Column(sa.String(64), nullable=True, index=True)
    configuration = sa.Column(sa.JSON(), nullable=False, default=dict)
    instrument_tokens = sa.Column(sa.JSON(), nullable=False, default=list)
    lifecycle_state = sa.Column(sa.String(32), nullable=False, index=True)
    enabled = sa.Column(sa.Boolean(), nullable=False, default=True)
    created_at = sa.Column(
        sa.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    updated_at = sa.Column(
        sa.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        sa.UniqueConstraint("strategy_id", name="uq_strategies_strategy_id"),
        sa.Index("ix_strategies_account_lifecycle", "account_id", "lifecycle_state"),
        sa.Index("ix_strategies_type_state", "strategy_type", "lifecycle_state"),
    )


class StrategySignalModel(Base):
    """ORM model for the strategy_signals table.

    Stores every signal emitted by a strategy, including routing status,
    the client_order_id assigned on successful routing, and any rejection reason.
    signal_id uses UUID type to match the domain Signal contract.
    """

    __tablename__ = "strategy_signals"

    id = sa.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    signal_id = sa.Column(UUID(as_uuid=True), nullable=False, index=True)
    strategy_id = sa.Column(sa.String(64), nullable=False, index=True)
    account_id = sa.Column(sa.String(64), nullable=True, index=True)
    instrument_token = sa.Column(sa.String(64), nullable=False, index=True)
    action = sa.Column(sa.String(16), nullable=False)
    side = sa.Column(sa.String(8), nullable=False)
    quantity = sa.Column(sa.Numeric(20, 8), nullable=False)
    order_type = sa.Column(sa.String(16), nullable=False)
    limit_price = sa.Column(sa.Numeric(20, 8), nullable=True)
    trigger_price = sa.Column(sa.Numeric(20, 8), nullable=True)
    timestamp = sa.Column(
        sa.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    routing_status = sa.Column(
        sa.String(16), nullable=False, default="PENDING"
    )
    routed_client_order_id = sa.Column(sa.String(64), nullable=True, index=True)
    rejection_reason = sa.Column(sa.Text(), nullable=True)
    extra_data = sa.Column(sa.JSON(), nullable=False, default=dict)

    __table_args__ = (
        sa.UniqueConstraint("signal_id", name="uq_strategy_signals_signal_id"),
        sa.Index(
            "ix_strategy_signals_strategy_status",
            "strategy_id",
            "routing_status",
        ),
        sa.Index(
            "ix_strategy_signals_pending",
            "routing_status",
            "timestamp",
        ),
    )


class StrategyStateModel(Base):
    """ORM model for the strategy_state_snapshots table.

    Stores a point-in-time snapshot of a strategy's runtime counters,
    pending order IDs, and latest signal timestamp. Counter columns use
    sa.Integer (not Numeric) for efficient storage and indexing.
    """

    __tablename__ = "strategy_state_snapshots"

    id = sa.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    strategy_id = sa.Column(sa.String(64), nullable=False, index=True)
    lifecycle_state = sa.Column(sa.String(32), nullable=False)
    pending_order_ids = sa.Column(sa.JSON(), nullable=False, default=list)
    latest_signal_timestamp = sa.Column(sa.DateTime(timezone=True), nullable=True)
    emitted_signal_count = sa.Column(sa.Integer(), nullable=False, default=0)
    routed_signal_count = sa.Column(sa.Integer(), nullable=False, default=0)
    rejected_signal_count = sa.Column(sa.Integer(), nullable=False, default=0)
    fill_count = sa.Column(sa.Integer(), nullable=False, default=0)
    extra_data = sa.Column(sa.JSON(), nullable=False, default=dict)
    snapshot_timestamp = sa.Column(
        sa.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        sa.UniqueConstraint(
            "strategy_id",
            "snapshot_timestamp",
            name="uq_strategy_state_snapshots_strategy_timestamp",
        ),
        sa.Index(
            "ix_strategy_state_snapshots_strategy_latest",
            "strategy_id",
            "snapshot_timestamp",
        ),
    )
