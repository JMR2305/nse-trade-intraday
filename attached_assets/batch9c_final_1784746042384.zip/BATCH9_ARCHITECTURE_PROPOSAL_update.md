

---

## Appendix: Batch 9C Architecture — Strategy Persistence & Recovery

### Overview

Batch 9C adds durable persistence for the Strategy Engine, enabling crash recovery
without loss of strategy registrations, emitted signals, or runtime counters. All
persistence is append-only and idempotent — repeated saves or recovery runs are safe.

### Files Added

| File | Purpose |
|------|---------|
| `src/database/models.py` (appended) | Three ORM models: `StrategyModel`, `StrategySignalModel`, `StrategyStateModel` |
| `src/database/repositories/strategy.py` | `StrategyRepository` — upsert, load, list non-terminal, update lifecycle |
| `src/database/repositories/strategy_signal.py` | `StrategySignalRepository` — upsert, load, list pending, mark routed/rejected |
| `src/database/repositories/strategy_state.py` | `StrategyStateRepository` — append-only snapshots, load latest |
| `src/strategy/persistence.py` | `StrategyPersistenceAdapter` — domain-to-ORM bridge with DTOs |
| `src/strategy/recovery.py` | `StrategyRecoveryManager` — full recovery orchestration |
| `migrations/versions/0003_rc9c_strategy_persistence.py` | Alembic migration creating three tables |
| `tests/unit/strategy/test_batch9c.py` | ~80 tests covering models, repos, adapter, recovery, idempotency |

### Schema

**`strategies`**
- `id` (UUID PK) — surrogate key
- `strategy_id` (String 64, unique, indexed) — natural key, idempotency anchor
- `strategy_type` (String 64) — factory lookup key
- `name` (String 255) — human-readable
- `account_id` (String 64, nullable, indexed) — optional account binding
- `configuration` (JSON) — strategy parameters
- `instrument_tokens` (JSON) — subscribed instruments
- `lifecycle_state` (String 32, indexed) — REGISTERED/STARTING/ACTIVE/PAUSED/STOPPED/ERROR
- `enabled` (Boolean) — soft-delete flag
- `created_at`, `updated_at` (timestamptz)

**`strategy_signals`**
- `id` (UUID PK)
- `signal_id` (UUID, unique, indexed) — matches domain Signal.id type
- `strategy_id` (String 64, indexed)
- `account_id` (String 64, nullable, indexed)
- `instrument_token` (String 64, indexed)
- `action`, `side` (String)
- `quantity`, `limit_price`, `trigger_price` (Numeric 20,8)
- `timestamp` (timestamptz)
- `routing_status` (String 16, default PENDING) — PENDING/ROUTED/REJECTED
- `routed_client_order_id` (String 64, nullable, indexed)
- `rejection_reason` (Text, nullable)
- `extra_data` (JSON) — renamed from `metadata` to avoid SQLAlchemy reserved attribute

**`strategy_state_snapshots`**
- `id` (UUID PK)
- `strategy_id` (String 64, indexed)
- `lifecycle_state` (String 32)
- `pending_order_ids` (JSON)
- `latest_signal_timestamp` (timestamptz, nullable)
- `emitted_signal_count`, `routed_signal_count`, `rejected_signal_count`, `fill_count` (Integer)
- `extra_data` (JSON)
- `snapshot_timestamp` (timestamptz)
- Unique: `(strategy_id, snapshot_timestamp)`

### Design Decisions

1. **Flat model file** (`src/database/models.py`) — follows existing project convention. All three models are appended to the single file, importing `Base` from `src.database.connection`.

2. **`extra_data` instead of `metadata`** — `metadata` is a reserved SQLAlchemy attribute on `Table` objects. Using it as a column name causes silent shadowing bugs.

3. **`signal_id` as UUID** — matches the domain `Signal` frozen dataclass contract where `id` is a `UUID` field. The repository accepts `UUID` objects, not strings.

4. **Counter columns as `sa.Integer`** — `Numeric(20,0)` was considered but rejected. Integer is more efficient for counting, indexing, and aggregation. The 20-digit precision was unnecessary.

5. **`account_id` is nullable** — strategies may be account-agnostic (e.g., cross-account arbitrage). The domain `StrategyConfig` does not require an account_id.

6. **No `unique=True` on indexed columns** — `strategy_id` and `signal_id` have `index=True` but not `unique=True`. The unique constraint is declared only in `__table_args__` via `UniqueConstraint`. This avoids duplicate constraints (column-level + table-level) that confuse some PostgreSQL drivers.

7. **Repository `save()` is upsert** — checks `scalar_one_or_none()` before insert or update. Guarantees idempotency for repeated calls with the same natural key.

8. **No commit/rollback/close in repositories** — transaction ownership stays with the caller (service layer / coordinator), following the project-wide contract.

9. **Hydration methods are private (`_hydrate_*`)** — `StrategyRepository._hydrate_config()`, `StrategySignalRepository._hydrate_signal()`, `StrategyStateRepository._hydrate_snapshot()`. These serialize ORM rows to plain dicts suitable for domain DTO construction, without coupling ORM to domain contracts.

10. **Recovery manager uses Protocol injection** — `StrategyFactory`, `StrategyRegistry`, and `SignalRouter` are `typing.Protocol` definitions, not imports from frozen `strategy/` internals. This preserves the no-modification rule for frozen components.

### Recovery Flow

```
recover(session)
  ├─ load non-terminal strategies (exclude STOPPED, ERROR)
  │   └─ for each: _recover_strategy()
  │       ├─ skip if already registered
  │       ├─ factory.create() → instance
  │       ├─ registry.register(REGISTERED)
  │       ├─ transition to persisted lifecycle state
  │       │   ├─ PAUSED: REGISTERED→STARTING→ACTIVE→PAUSED (no subscribe)
  │       │   ├─ ACTIVE: REGISTERED→STARTING→ACTIVE→subscribe_market_data()
  │       │   ├─ STARTING: →STARTING
  │       │   └─ REGISTERED: leave as-is
  │       └─ load latest state snapshot → _apply_state_snapshot() (no-op placeholder)
  └─ load pending signals (routing_status=PENDING)
      └─ for each: _recover_signal()
          ├─ skip if routed_client_order_id is not None
          └─ router.enqueue(signal_envelope)
  └─ return StrategyRecoveryResult
```

### Idempotency Guarantees

| Scenario | Guarantee |
|----------|-----------|
| Save same strategy twice | Upsert — second call updates existing row |
| Save same signal twice | Upsert — second call updates existing row |
| Recovery run twice | Already-registered strategies skipped via `is_registered()` |
| Re-queue same signal twice | Router-level dedup; also `routed_client_order_id` guard |
| Already-routed signal in DB | Never re-queued — explicit skip on `routed_client_order_id` |
| Already-routed signal re-played | `is_signal_routed()` returns True, prevents double-routing |

### Integration Points (Batch 9D)

- Wire `StrategyPersistenceAdapter.save_strategy()` into `StrategyCoordinator.register()`
- Wire `StrategyPersistenceAdapter.save_signal()` into `SignalRouter` after successful enqueue
- Wire `StrategyPersistenceAdapter.mark_signal_routed()` into `SignalRouter` after order creation
- Wire `StrategyPersistenceAdapter.save_state_snapshot()` into lifecycle transition hooks
- Implement `_apply_state_snapshot()` counter restoration when runtime exposes public API
- Add scheduled snapshot creation (e.g., every 5 minutes or on every lifecycle transition)
- Connect `StrategyRecoveryManager.recover()` to service startup sequence

### Test Coverage

~80 tests across 10 test classes:
- `TestStrategyModel` — 11 tests (construction, columns, constraints, indexes)
- `TestStrategySignalModel` — 12 tests (construction, columns, constraints, indexes, UUID type, extra_data naming)
- `TestStrategyStateModel` — 9 tests (construction, columns, constraints, indexes, Integer counters, extra_data naming)
- `TestStrategyRepository` — 10 tests (save, upsert, load, list, update, hydrate, nullable account_id)
- `TestStrategySignalRepository` — 11 tests (save, upsert, load, pending, routing status, hydrate, UUID, nullable account_id)
- `TestStrategyStateRepository` — 7 tests (save, load latest, list, hydrate, Integer counters)
- `TestStrategyPersistenceAdapter` — 9 tests (save/load strategy, save/load signal, mark routed, state snapshot, non-terminal list)
- `TestStrategyRecoveryManager` — 14 tests (empty DB, active, paused, starting, registered, terminal skip, dedup, pending signals, routed skip, idempotency, error collection, result structure, state snapshot)
- `TestTransactionOwnership` — 3 tests (rollback after repo, adapter, recovery manager)
- `TestLifecycleStatePersistence` — 4 tests (ACTIVE, PAUSED, STOPPED, ERROR roundtrip)
- `TestImports` — 9 tests (all modules importable)
- `TestEdgeCases` — 15 tests (empty config, null prices, rejection reasons, zero counts, metadata roundtrip, decimal precision, unknown states, pending by strategy, mixed routed/pending, missing loads)

Total: ~80 tests, all async, using in-memory SQLite via aiosqlite.
