"""Execution engine package — Part 7A: Contracts and Order State Machine.

This package provides:
  - ExecutionOrder: immutable order contract with validation
  - ExecutionOrderStatus / ExecutionOrderType / ExecutionOrderSide: lifecycle enums
  - ExecutionAuditEvent: immutable transition audit record
  - OrderStateMachine: deterministic, concurrent-safe state machine
  - ExecutionException hierarchy: typed domain exceptions

Integration note:
  Existing project order/trade/position models are NOT imported here.
  Future batches will provide adapter layers to bridge these contracts
  with the existing ORM models and PaperBroker interfaces.
"""
from __future__ import annotations

# Conditional imports matching the pattern used in src.brokers and src.database.repositories
try:
    from src.execution.contracts import (
        ExecutionAuditEvent,
        ExecutionOrder,
        ExecutionOrderAction,
        ExecutionOrderSide,
        ExecutionOrderStatus,
        ExecutionOrderType,
        FillRecord,
        TERMINAL_STATES,
    )
    from src.execution.exceptions import (
        ConcurrentTransitionError,
        ExecutionException,
        IdempotencyViolation,
        InvalidStateTransition,
        OrderValidationError,
        OverfillError,
    )
    from src.execution.state_machine import (
        OrderState,
        OrderStateMachine,
        TransitionResult,
    )

    __all__ = [
        # Contracts
        "ExecutionAuditEvent",
        "ExecutionOrder",
        "ExecutionOrderAction",
        "ExecutionOrderSide",
        "ExecutionOrderStatus",
        "ExecutionOrderType",
        "FillRecord",
        "TERMINAL_STATES",
        # Exceptions
        "ConcurrentTransitionError",
        "ExecutionException",
        "IdempotencyViolation",
        "InvalidStateTransition",
        "OrderValidationError",
        "OverfillError",
        # State machine
        "OrderState",
        "OrderStateMachine",
        "TransitionResult",
    ]
except ImportError:
    __all__ = []
