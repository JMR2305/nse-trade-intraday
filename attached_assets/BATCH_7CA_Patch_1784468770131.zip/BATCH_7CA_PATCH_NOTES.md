# BATCH 7CA Compatibility Patch

## Files Modified (5 files)

### 1. position_engine.py — CRITICAL FIX
**Bug:** Cumulative realized P&L was incorrect after position close.

**Root Cause:** The `_compute_cumulative_realized_pnl()` method summed `realized_pnl` from `self._positions.values()`. When a position became FLAT, it was removed from `_positions`, so its accumulated realized P&L was lost from the sum. This caused:
- Trade `cumulative_realized_pnl` to show 0 after a full close
- Portfolio `realized_pnl` to show 0 after a full close  
- Historical P&L to be lost after reopening a position

**Fix:**
- Removed `_compute_cumulative_realized_pnl()` method entirely
- Trade now uses `self._cumulative_realized_pnl` directly (already correctly maintained via `+= realized_pnl`)
- `snapshot()` now computes: `self._cumulative_realized_pnl + sum(pos.realized_pnl for open positions)`
- Added documented limitation on reversal accounting in module docstring

**Unused imports removed:** `field`, `timezone`, `UUID`

### 2. test_position_engine.py — REGRESSION TESTS
Added `TestCumulativeRealizedPnLRegression` class with 9 tests:
- LONG partial exit
- LONG full exit
- SHORT partial exit
- SHORT full exit
- Multiple sequential closes
- Reopen after flat
- Reopen and close again
- Unrealized P&L isolation
- Decimal arithmetic preservation

Added `TestReversalAccountingLimitation` class with 2 tests documenting current reversal behaviour (not redesigned per instructions).

### 3. state_machine.py — UNUSED IMPORT REMOVAL
Removed `ConcurrentTransitionError` from imports (imported but never used).

### 4. portfolio.py — UNUSED IMPORT REMOVAL
Removed `ExecutionOrderSide` from imports (imported but never used).

### 5. engine.py — UNUSED IMPORT REMOVAL
Removed: `datetime`, `Decimal`, `Any`, `MatchResult` (all imported but never used in body).

## Files NOT Modified
- contracts.py, exceptions.py, fills.py, matching.py, pnl.py, policies.py, trades.py
- All other test files (test_contracts.py, test_engine.py, test_matching.py, test_pnl.py, test_policies.py, test_portfolio.py, test_state_machine.py, test_trades.py)
- conftest.py, __init__.py
