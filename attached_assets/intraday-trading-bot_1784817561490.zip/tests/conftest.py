from __future__ import annotations

import asyncio
import os
from datetime import datetime
from decimal import Decimal

import pytest


@pytest.fixture
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()
