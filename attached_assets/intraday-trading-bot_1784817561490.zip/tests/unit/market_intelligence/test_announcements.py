from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

import pytest

from src.market_intelligence.multi_timeframe_context import AnnouncementRecord
from src.market_intelligence.announcements import (
    AnnouncementIntelligenceService,
    classify_announcement,
)


class TestClassifyAnnouncement:
    def test_earnings_classification(self) -> None:
        result = classify_announcement("Q1 FY26 Earnings Results", "Net profit increased by 20%")
        assert result == "EARNINGS_RESULT"

    def test_dividend_classification(self) -> None:
        result = classify_announcement("Final Dividend of Rs 10 per share declared", "")
        assert result == "DIVIDEND"

    def test_bonus_classification(self) -> None:
        result = classify_announcement("Bonus Issue in ratio 1:1", "")
        assert result == "BONUS"

    def test_stock_split(self) -> None:
        result = classify_announcement("Stock Split from Rs 10 to Rs 2 face value", "")
        assert result == "STOCK_SPLIT"

    def test_merger(self) -> None:
        result = classify_announcement("Merger with XYZ Ltd approved", "")
        assert result == "MERGER_ACQUISITION"

    def test_board_meeting(self) -> None:
        result = classify_announcement("Board Meeting on 25th July", "")
        assert result == "BOARD_MEETING"

    def test_regulatory(self) -> None:
        result = classify_announcement("SEBI compliance update", "")
        assert result == "REGULATORY"

    def test_other_when_no_match(self) -> None:
        result = classify_announcement("Random announcement about nothing specific", "")
        assert result == "OTHER"

    def test_case_insensitive(self) -> None:
        result = classify_announcement("EARNINGS RESULT Q1", "")
        assert result == "EARNINGS_RESULT"


class TestAnnouncementIntelligenceService:
    def test_ingest_new_announcement(self) -> None:
        service = AnnouncementIntelligenceService()
        record = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        assert service.ingest_announcement(record) is True

    def test_deduplication_same_id(self) -> None:
        service = AnnouncementIntelligenceService()
        record = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        assert service.ingest_announcement(record) is True
        assert service.ingest_announcement(record) is False

    def test_deduplication_different_exchanges(self) -> None:
        service = AnnouncementIntelligenceService()
        record1 = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        record2 = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="BSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        assert service.ingest_announcement(record1) is True
        assert service.ingest_announcement(record2) is True  # Different exchange

    def test_ttl_expiry_returns_empty(self) -> None:
        service = AnnouncementIntelligenceService(ttl_hours=1)
        old_record = AnnouncementRecord(
            announcement_id="ANN_OLD",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Old News",
            published_at=datetime.utcnow() - timedelta(hours=2),
        )
        service.ingest_announcement(old_record)
        active = service.get_active_announcements_sync("INFY")
        assert len(active) == 0

    def test_ttl_active_returns_record(self) -> None:
        service = AnnouncementIntelligenceService(ttl_hours=24)
        record = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        service.ingest_announcement(record)
        active = service.get_active_announcements_sync("INFY")
        assert len(active) == 1
        assert active[0].announcement_id == "ANN001"

    def test_blackout_period_true(self) -> None:
        service = AnnouncementIntelligenceService()
        record = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow(),
        )
        service.ingest_announcement(record)
        assert service.is_blackout_period("INFY", window_minutes=60) is True

    def test_blackout_period_false_after_window(self) -> None:
        service = AnnouncementIntelligenceService()
        record = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Q1 Results",
            published_at=datetime.utcnow() - timedelta(minutes=61),
        )
        service.ingest_announcement(record)
        assert service.is_blackout_period("INFY", window_minutes=60) is False

    def test_blackout_period_false_no_announcements(self) -> None:
        service = AnnouncementIntelligenceService()
        assert service.is_blackout_period("UNKNOWN", window_minutes=60) is False

    def test_clear_expired_removes_old(self) -> None:
        service = AnnouncementIntelligenceService(ttl_hours=1)
        old = AnnouncementRecord(
            announcement_id="ANN_OLD",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="Old",
            published_at=datetime.utcnow() - timedelta(hours=2),
        )
        new = AnnouncementRecord(
            announcement_id="ANN_NEW",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="DIVIDEND",
            headline="New",
            published_at=datetime.utcnow(),
        )
        service.ingest_announcement(old)
        service.ingest_announcement(new)
        service.clear_expired()
        active = service.get_active_announcements_sync("INFY")
        assert len(active) == 1
        assert active[0].announcement_id == "ANN_NEW"

    def test_get_active_no_cache_returns_empty(self) -> None:
        service = AnnouncementIntelligenceService()
        active = service.get_active_announcements_sync("UNKNOWN")
        assert active == []

    def test_multiple_instruments_separate_cache(self) -> None:
        service = AnnouncementIntelligenceService()
        record1 = AnnouncementRecord(
            announcement_id="ANN001",
            instrument_token="INFY",
            exchange="NSE",
            tradingsymbol="INFY",
            classification="EARNINGS_RESULT",
            headline="INFY Results",
            published_at=datetime.utcnow(),
        )
        record2 = AnnouncementRecord(
            announcement_id="ANN002",
            instrument_token="TCS",
            exchange="NSE",
            tradingsymbol="TCS",
            classification="DIVIDEND",
            headline="TCS Dividend",
            published_at=datetime.utcnow(),
        )
        service.ingest_announcement(record1)
        service.ingest_announcement(record2)
        assert len(service.get_active_announcements_sync("INFY")) == 1
        assert len(service.get_active_announcements_sync("TCS")) == 1

    def test_poll_and_classify_returns_zero(self) -> None:
        """Default poll returns 0 (no HTTP in unit tests)."""
        service = AnnouncementIntelligenceService()
        import asyncio
        result = asyncio.run(service.poll_and_classify(None))
        assert result == 0
