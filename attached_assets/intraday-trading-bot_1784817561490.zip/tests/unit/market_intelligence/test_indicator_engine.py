from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import List

import pytest

from src.market_data.contracts import CompletedBar
from src.market_intelligence.indicator_engine import (
    IndicatorEngine,
    compute_sma,
    compute_ema,
    compute_rsi,
    compute_atr,
    compute_adx,
    compute_macd,
    compute_vwap,
    compute_bollinger,
)


def make_bars(count: int, start_price: Decimal = Decimal("100"), token: str = "INFY") -> List[CompletedBar]:
    bars = []
    base = datetime(2026, 7, 23, 9, 15)
    price = start_price
    for i in range(count):
        o = price
        c = price + Decimal(str((i % 5) - 2))  # -2, -1, 0, 1, 2 cycle
        h = max(o, c) + Decimal("1")
        l = min(o, c) - Decimal("1")
        bars.append(CompletedBar(
            instrument_token=token,
            timestamp=(base + __import__('datetime').timedelta(minutes=i)).isoformat(),
            open=o,
            high=h,
            low=l,
            close=c,
            volume=Decimal("1000"),
        ))
        price = c
    return bars


def make_trending_bars(count: int, token: str = "INFY", uptrend: bool = True) -> List[CompletedBar]:
    bars = []
    base = datetime(2026, 7, 23, 9, 15)
    price = Decimal("100")
    for i in range(count):
        delta = Decimal("0.5") if uptrend else Decimal("-0.5")
        o = price
        c = price + delta
        h = max(o, c) + Decimal("0.3")
        l = min(o, c) - Decimal("0.2")
        bars.append(CompletedBar(
            instrument_token=token,
            timestamp=(base + __import__('datetime').timedelta(minutes=i)).isoformat(),
            open=o,
            high=h,
            low=l,
            close=c,
            volume=Decimal("1000"),
        ))
        price = c
    return bars


class TestComputeSMA:
    def test_known_value_simple(self) -> None:
        bars = make_bars(10, Decimal("100"))
        sma = compute_sma(bars, 5)
        assert sma is not None
        # SMA of last 5 closes
        closes = [b.close for b in bars[-5:]]
        expected = sum(closes) / Decimal("5")
        assert sma == expected

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(3)
        assert compute_sma(bars, 5) is None

    def test_single_period(self) -> None:
        bars = make_bars(1, Decimal("100"))
        sma = compute_sma(bars, 1)
        assert sma == Decimal("100")


class TestComputeEMA:
    def test_converges_to_price(self) -> None:
        bars = make_bars(50, Decimal("100"))
        ema = compute_ema(bars, 10)
        assert ema is not None
        # EMA should be close to recent prices
        last_close = bars[-1].close
        assert abs(ema - last_close) < Decimal("10")

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(5)
        assert compute_ema(bars, 10) is None

    def test_ema_vs_sma_seed(self) -> None:
        bars = make_bars(20, Decimal("100"))
        ema = compute_ema(bars, 10)
        sma = compute_sma(bars, 10)
        assert ema is not None
        assert sma is not None
        # EMA and SMA should be reasonably close for stable prices
        assert abs(ema - sma) < Decimal("5")


class TestComputeRSI:
    def test_boundaries(self) -> None:
        # Strong uptrend -> RSI near 100
        up_bars = make_trending_bars(20, uptrend=True)
        rsi = compute_rsi(up_bars, 14)
        assert rsi is not None
        assert Decimal("0") <= rsi <= Decimal("100")
        assert rsi > Decimal("50")

    def test_downtrend_rsi_low(self) -> None:
        down_bars = make_trending_bars(20, uptrend=False)
        rsi = compute_rsi(down_bars, 14)
        assert rsi is not None
        assert rsi < Decimal("50")

    def test_ranging_rsi_mid(self) -> None:
        bars = make_bars(30, Decimal("100"))
        rsi = compute_rsi(bars, 14)
        assert rsi is not None
        assert Decimal("20") <= rsi <= Decimal("80")

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(10)
        assert compute_rsi(bars, 14) is None

    def test_rsi_never_exceeds_100(self) -> None:
        bars = make_trending_bars(30, uptrend=True)
        rsi = compute_rsi(bars, 14)
        assert rsi is not None
        assert rsi <= Decimal("100")

    def test_rsi_never_below_0(self) -> None:
        bars = make_trending_bars(30, uptrend=False)
        rsi = compute_rsi(bars, 14)
        assert rsi is not None
        assert rsi >= Decimal("0")


class TestComputeATR:
    def test_positive(self) -> None:
        bars = make_bars(20, Decimal("100"))
        atr = compute_atr(bars, 14)
        assert atr is not None
        assert atr > Decimal("0")

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(5)
        assert compute_atr(bars, 14) is None

    def test_higher_volatility_higher_atr(self) -> None:
        # Create volatile bars
        bars = []
        base = datetime(2026, 7, 23, 9, 15)
        for i in range(20):
            o = Decimal("100")
            c = Decimal("100") + Decimal(str(i * 2))
            h = max(o, c) + Decimal("5")
            l = min(o, c) - Decimal("5")
            bars.append(CompletedBar(
                instrument_token="VOL",
                timestamp=(base + __import__('datetime').timedelta(minutes=i)).isoformat(),
                open=o,
                high=h,
                low=l,
                close=c,
                volume=Decimal("1000"),
            ))
        atr = compute_atr(bars, 14)
        assert atr is not None
        assert atr > Decimal("2")


class TestComputeADX:
    def test_uptrend_adx_positive(self) -> None:
        bars = make_trending_bars(30, uptrend=True)
        adx, pdi, mdi = compute_adx(bars, 14)
        assert adx is not None
        assert pdi is not None
        assert mdi is not None
        assert adx >= Decimal("0")
        # In uptrend, +DI should generally be higher
        assert pdi >= mdi or adx < Decimal("10")  # ADX may be low early

    def test_downtrend_minus_di_higher(self) -> None:
        bars = make_trending_bars(30, uptrend=False)
        adx, pdi, mdi = compute_adx(bars, 14)
        assert adx is not None
        assert mdi is not None
        assert pdi is not None

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(10)
        adx, pdi, mdi = compute_adx(bars, 14)
        assert adx is None
        assert pdi is None
        assert mdi is None


class TestComputeMACD:
    def test_macd_components_present(self) -> None:
        bars = make_bars(50, Decimal("100"))
        macd_line, signal_line, histogram = compute_macd(bars, 12, 26, 9)
        assert macd_line is not None
        assert signal_line is not None
        assert histogram is not None
        assert histogram == macd_line - signal_line

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(20)
        macd_line, signal_line, histogram = compute_macd(bars, 12, 26, 9)
        assert macd_line is None


class TestComputeVWAP:
    def test_vwap_between_high_low(self) -> None:
        bars = make_bars(10, Decimal("100"))
        vwap = compute_vwap(bars)
        assert vwap is not None
        assert all(vwap >= b.low for b in bars) or vwap >= min(b.low for b in bars)
        assert all(vwap <= b.high for b in bars) or vwap <= max(b.high for b in bars)

    def test_empty_bars_returns_none(self) -> None:
        assert compute_vwap([]) is None


class TestComputeBollinger:
    def test_band_width_positive(self) -> None:
        bars = make_bars(25, Decimal("100"))
        upper, middle, lower = compute_bollinger(bars, 20, Decimal("2"))
        assert upper is not None
        assert middle is not None
        assert lower is not None
        assert upper > middle > lower
        assert upper - lower > Decimal("0")

    def test_insufficient_data_returns_none(self) -> None:
        bars = make_bars(10)
        upper, middle, lower = compute_bollinger(bars, 20, Decimal("2"))
        assert upper is None


class TestIndicatorEngine:
    def test_subscribe_creates_buffer(self) -> None:
        engine = IndicatorEngine(max_bars=10)
        engine.subscribe("INFY", "1m")
        assert "INFY" in engine._buffers
        assert "1m" in engine._buffers["INFY"]

    def test_update_adds_bar(self) -> None:
        engine = IndicatorEngine(max_bars=10)
        bar = make_bars(1)[0]
        engine.update(bar, "1m")
        bars = engine.get_bars("INFY", "1m")
        assert len(bars) == 1

    def test_get_indicators_returns_values(self) -> None:
        engine = IndicatorEngine(max_bars=100)
        bars = make_bars(60, Decimal("100"))
        for b in bars:
            engine.update(b, "1m")
        indicators = engine.get_indicators("INFY", "1m")
        assert "sma_10" in indicators
        assert "sma_20" in indicators
        assert "rsi_14" in indicators
        assert "atr_14" in indicators
        assert "macd_line" in indicators
        assert "vwap" in indicators
        assert "bb_upper_20" in indicators

    def test_buffer_bounded(self) -> None:
        engine = IndicatorEngine(max_bars=5)
        bars = make_bars(10, Decimal("100"))
        for b in bars:
            engine.update(b, "1m")
        stored = engine.get_bars("INFY", "1m")
        assert len(stored) == 5

    def test_insufficient_data_returns_empty_dict(self) -> None:
        engine = IndicatorEngine(max_bars=100)
        bar = make_bars(1)[0]
        engine.update(bar, "1m")
        indicators = engine.get_indicators("INFY", "1m")
        # Most indicators need more data
        assert "rsi_14" not in indicators
        assert "adx_14" not in indicators

    def test_get_all_timeframes(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        bars = make_bars(30, Decimal("100"))
        for b in bars:
            engine.update(b, "1m")
            engine.update(b, "5m")
        all_tf = engine.get_all_timeframes("INFY")
        assert "1m" in all_tf
        assert "5m" in all_tf

    def test_determinism(self) -> None:
        """Same input sequence -> same indicator values."""
        engine1 = IndicatorEngine(max_bars=50)
        engine2 = IndicatorEngine(max_bars=50)
        bars = make_bars(40, Decimal("100"))
        for b in bars:
            engine1.update(b, "1m")
            engine2.update(b, "1m")
        ind1 = engine1.get_indicators("INFY", "1m")
        ind2 = engine2.get_indicators("INFY", "1m")
        assert set(ind1.keys()) == set(ind2.keys())
        for k in ind1:
            assert ind1[k] == ind2[k], f"Mismatch for {k}"

    def test_unknown_instrument_returns_empty(self) -> None:
        engine = IndicatorEngine()
        assert engine.get_indicators("UNKNOWN", "1m") == {}
        assert engine.get_all_timeframes("UNKNOWN") == {}
