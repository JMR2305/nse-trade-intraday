from __future__ import annotations

from datetime import datetime
from decimal import Decimal

import pytest

from src.market_data.contracts import CompletedBar
from src.market_intelligence.indicator_engine import IndicatorEngine
from src.market_intelligence.regime import MarketRegimeDetector
from src.market_intelligence.multi_timeframe_context import MarketRegime


def make_trending_bars(count: int, uptrend: bool = True, token: str = "INFY") -> list:
    bars = []
    base = datetime(2026, 7, 23, 9, 15)
    price = Decimal("100")
    for i in range(count):
        delta = Decimal("1") if uptrend else Decimal("-1")
        o = price
        c = price + delta
        h = max(o, c) + Decimal("0.5")
        l = min(o, c) - Decimal("0.3")
        bars.append(CompletedBar(
            instrument_token=token,
            timestamp=(base + __import__('datetime').timedelta(minutes=i)).isoformat(),
            open=o,
            high=h,
            low=l,
            close=c,
            volume=Decimal("1000"),
        ))
        price = c
    return bars


class TestRegimeFromBars:
    def test_strong_uptrend_from_trending_bars(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        bars = make_trending_bars(40, uptrend=True)
        for b in bars:
            engine.update(b, "1m")

        detector = MarketRegimeDetector()
        indicators = engine.get_indicators("INFY", "1m")
        result = detector.detect("INFY", indicators)
        assert result.regime in (MarketRegime.STRONG_UPTREND, MarketRegime.UPTREND)

    def test_downtrend_from_falling_bars(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        bars = make_trending_bars(40, uptrend=False)
        for b in bars:
            engine.update(b, "1m")

        detector = MarketRegimeDetector()
        indicators = engine.get_indicators("INFY", "1m")
        result = detector.detect("INFY", indicators)
        assert result.regime in (MarketRegime.STRONG_DOWNTREND, MarketRegime.DOWNTREND)
