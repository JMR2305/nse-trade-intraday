from __future__ import annotations

import pytest

from src.strategy.contracts import StrategyConfig
from src.strategy.context_builder import ContextBuilder


class TestContextBuilderNoIntelligence:
    def test_same_result_as_pre_10a(self) -> None:
        builder = ContextBuilder()
        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["INFY", "TCS"],
        )
        state = {
            "current_positions": {"INFY": {"qty": 10}},
            "portfolio_snapshot": {"equity": Decimal("100000")},
        }
        ctx = builder.build(config, state)
        assert ctx.strategy_id == "test"
        assert ctx.instrument_tokens == ["INFY", "TCS"]
        assert ctx.current_positions == {"INFY": {"qty": 10}}
        assert ctx.market_snapshots == {}
        assert ctx.portfolio_snapshot == {"equity": Decimal("100000")}

    def test_positional_constructor_still_valid(self) -> None:
        builder = ContextBuilder()
        assert builder._indicator_engine is None
        assert builder._regime_detector is None
        assert builder._announcement_service is None
        assert builder._watchlist_ranker is None
