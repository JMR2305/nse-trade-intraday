from __future__ import annotations

from datetime import datetime
from decimal import Decimal

import pytest

from src.market_data.contracts import CompletedBar
from src.market_intelligence.indicator_engine import IndicatorEngine
from src.market_intelligence.regime import MarketRegimeDetector
from src.market_intelligence.announcements import AnnouncementIntelligenceService
from src.strategy.contracts import StrategyConfig
from src.strategy.context_builder import ContextBuilder


def make_bars(count: int, token: str = "INFY") -> list:
    bars = []
    base = datetime(2026, 7, 23, 9, 15)
    for i in range(count):
        bars.append(CompletedBar(
            instrument_token=token,
            timestamp=(base + __import__('datetime').timedelta(minutes=i)).isoformat(),
            open=Decimal("100") + Decimal(str(i)),
            high=Decimal("101") + Decimal(str(i)),
            low=Decimal("99") + Decimal(str(i)),
            close=Decimal("100") + Decimal(str(i)),
            volume=Decimal("1000"),
        ))
    return bars


class TestContextBuilderWithIntelligence:
    def test_populates_market_snapshots(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        bars = make_bars(30)
        for b in bars:
            engine.update(b, "1m")

        detector = MarketRegimeDetector()
        ann_service = AnnouncementIntelligenceService()

        builder = ContextBuilder(
            indicator_engine=engine,
            regime_detector=detector,
            announcement_service=ann_service,
        )

        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["INFY"],
        )

        ctx = builder.build(config, {})
        assert "INFY" in ctx.market_snapshots
        assert "timeframes" in ctx.market_snapshots["INFY"]
        assert "regime" in ctx.market_snapshots["INFY"]

    def test_skips_unknown_instruments(self) -> None:
        engine = IndicatorEngine()
        detector = MarketRegimeDetector()
        builder = ContextBuilder(
            indicator_engine=engine,
            regime_detector=detector,
        )
        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["UNKNOWN"],
        )
        ctx = builder.build(config, {})
        assert "UNKNOWN" not in ctx.market_snapshots

    def test_no_intelligence_injection_preserves_behavior(self) -> None:
        builder = ContextBuilder()
        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["INFY"],
        )
        ctx = builder.build(config, {})
        assert ctx.market_snapshots == {}
        assert ctx.strategy_id == "test"

    def test_multiple_instruments(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        for token in ["INFY", "TCS"]:
            bars = make_bars(30, token)
            for b in bars:
                engine.update(b, "1m")

        detector = MarketRegimeDetector()
        builder = ContextBuilder(
            indicator_engine=engine,
            regime_detector=detector,
        )
        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["INFY", "TCS"],
        )
        ctx = builder.build(config, {})
        assert "INFY" in ctx.market_snapshots
        assert "TCS" in ctx.market_snapshots

    def test_regime_confidence_in_range(self) -> None:
        engine = IndicatorEngine(max_bars=50)
        bars = make_bars(30)
        for b in bars:
            engine.update(b, "1m")

        detector = MarketRegimeDetector()
        builder = ContextBuilder(
            indicator_engine=engine,
            regime_detector=detector,
        )
        config = StrategyConfig(
            strategy_id="test",
            strategy_type="trend",
            name="Test",
            instrument_tokens=["INFY"],
        )
        ctx = builder.build(config, {})
        regime = ctx.market_snapshots["INFY"]["regime"]
        assert Decimal("0") <= regime.confidence <= Decimal("1")
