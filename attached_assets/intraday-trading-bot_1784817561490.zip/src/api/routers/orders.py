from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.post("/orders")
async def create_order():
    return {"order_id": "test-order"}


@router.get("/orders/{order_id}")
async def get_order(order_id: str):
    return {"order_id": order_id}
