from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.post("/auth/login")
async def login():
    return {"access_token": "test", "refresh_token": "test"}
