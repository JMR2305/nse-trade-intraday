from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.post("/sessions")
async def create_session():
    return {"session_id": "test-session"}


@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    return {"session_id": session_id, "status": "ACTIVE"}
