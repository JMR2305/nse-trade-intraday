from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/positions")
async def get_positions():
    return []
