from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/risk/state")
async def get_risk_state():
    return {}


@router.post("/risk/kill-switch")
async def toggle_kill_switch():
    return {"activated": True}
