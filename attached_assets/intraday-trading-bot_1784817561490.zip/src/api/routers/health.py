from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    return {"status": "ok"}


@router.get("/health/ready")
async def ready():
    return {"status": "ready"}


@router.get("/health/live")
async def live():
    return {"status": "live"}
