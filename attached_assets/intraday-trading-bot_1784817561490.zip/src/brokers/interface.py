from __future__ import annotations

from abc import ABC, abstractmethod
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class OrderRequest(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)
    instrument_token: str
    side: str
    quantity: Decimal
    order_type: str
    limit_price: Optional[Decimal] = None
    trigger_price: Optional[Decimal] = None


class OrderResponse(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)
    order_id: str
    status: str
    broker_order_id: Optional[str] = None
    message: str = ""


class Position(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)
    instrument_token: str
    tradingsymbol: str
    exchange: str
    quantity: Decimal
    average_price: Decimal


class Margin(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)
    equity: Decimal
    cash: Decimal
    used_margin: Decimal
    available_margin: Decimal


class BrokerInterface(ABC):
    @abstractmethod
    async def place_order(self, request: OrderRequest) -> OrderResponse:
        ...

    @abstractmethod
    async def modify_order(self, order_id: str, **kwargs: Any) -> OrderResponse:
        ...

    @abstractmethod
    async def cancel_order(self, order_id: str) -> bool:
        ...

    @abstractmethod
    async def get_positions(self) -> List[Position]:
        ...

    @abstractmethod
    async def get_orders(self) -> List[Dict[str, Any]]:
        ...

    @abstractmethod
    async def get_margins(self) -> Margin:
        ...

    @abstractmethod
    async def get_instruments(self, exchange: str) -> List[Dict[str, Any]]:
        ...

    @abstractmethod
    async def get_quote(self, symbols: List[str]) -> Dict[str, Any]:
        ...
