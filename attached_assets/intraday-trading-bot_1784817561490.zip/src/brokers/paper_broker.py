from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Dict, List

from src.brokers.interface import (
    BrokerInterface,
    Margin,
    OrderRequest,
    OrderResponse,
    Position,
)
from src.core.config import settings

logger = logging.getLogger(__name__)


class PaperBroker(BrokerInterface):
    def __init__(self) -> None:
        self._cash = settings.paper.initial_capital
        self._positions: Dict[str, Position] = {}
        self._orders: Dict[str, OrderResponse] = {}

    async def place_order(self, request: OrderRequest) -> OrderResponse:
        import uuid
        order_id = str(uuid.uuid4())
        resp = OrderResponse(order_id=order_id, status="COMPLETE")
        self._orders[order_id] = resp
        return resp

    async def modify_order(self, order_id: str, **kwargs: Any) -> OrderResponse:
        return OrderResponse(order_id=order_id, status="MODIFIED")

    async def cancel_order(self, order_id: str) -> bool:
        return True

    async def get_positions(self) -> List[Position]:
        return list(self._positions.values())

    async def get_orders(self) -> List[Dict[str, Any]]:
        return []

    async def get_margins(self) -> Margin:
        return Margin(
            equity=self._cash,
            cash=self._cash,
            used_margin=Decimal("0"),
            available_margin=self._cash,
        )

    async def get_instruments(self, exchange: str) -> List[Dict[str, Any]]:
        return []

    async def get_quote(self, symbols: List[str]) -> Dict[str, Any]:
        return {}
