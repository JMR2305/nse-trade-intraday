from __future__ import annotations

from typing import Any, Dict, List

from src.brokers.interface import BrokerInterface, Margin, OrderRequest, OrderResponse, Position


class ZerodhaReadonly(BrokerInterface):
    """Read-only Zerodha client for quotes and instruments."""

    async def place_order(self, request: OrderRequest) -> OrderResponse:
        raise NotImplementedError("Read-only broker")

    async def modify_order(self, order_id: str, **kwargs: Any) -> OrderResponse:
        raise NotImplementedError("Read-only broker")

    async def cancel_order(self, order_id: str) -> bool:
        raise NotImplementedError("Read-only broker")

    async def get_positions(self) -> List[Position]:
        return []

    async def get_orders(self) -> List[Dict[str, Any]]:
        return []

    async def get_margins(self) -> Margin:
        return Margin(equity=Decimal("0"), cash=Decimal("0"), used_margin=Decimal("0"), available_margin=Decimal("0"))

    async def get_instruments(self, exchange: str) -> List[Dict[str, Any]]:
        return []

    async def get_quote(self, symbols: List[str]) -> Dict[str, Any]:
        return {}
