from __future__ import annotations

import logging
import sys

from src.core.config import settings


def setup_logging() -> None:
    level = getattr(logging, settings.logging.level.upper(), logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    if settings.logging.format == "structured_json":
        # Simple JSON-like format for now
        formatter = logging.Formatter(
            '%(asctime)s %(levelname)s %(name)s %(message)s'
        )
    else:
        formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        )
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers = [handler]
