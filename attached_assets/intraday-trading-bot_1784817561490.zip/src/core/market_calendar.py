from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Optional

# NSE market hours in IST
MARKET_OPEN_IST = time(9, 15)
MARKET_CLOSE_IST = time(15, 30)


def is_market_open(dt: Optional[datetime] = None) -> bool:
    """Check if the market is currently open."""
    if dt is None:
        dt = datetime.now()
    # Simplified: check weekday and time
    if dt.weekday() >= 5:  # Saturday or Sunday
        return False
    t = dt.time()
    return MARKET_OPEN_IST <= t <= MARKET_CLOSE_IST


def get_session_start(dt: Optional[datetime] = None) -> datetime:
    """Return the start of the current trading session."""
    if dt is None:
        dt = datetime.now()
    return datetime.combine(dt.date(), MARKET_OPEN_IST)


def get_next_session_start(dt: Optional[datetime] = None) -> datetime:
    """Return the start of the next trading session."""
    if dt is None:
        dt = datetime.now()
    next_day = dt + timedelta(days=1)
    while next_day.weekday() >= 5:
        next_day += timedelta(days=1)
    return datetime.combine(next_day.date(), MARKET_OPEN_IST)
