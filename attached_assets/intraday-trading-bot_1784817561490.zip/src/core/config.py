from __future__ import annotations

import os
from decimal import Decimal
from typing import Any, List, Optional

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class TradingSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TRADING_", extra="ignore")

    mode: str = "PAPER"
    enforce_paper_mode: bool = True

    @field_validator("mode")
    @classmethod
    def _validate_mode(cls, v: str) -> str:
        v = v.upper()
        allowed = {"PAPER", "REPLAY", "SHADOW", "SIMULATION", "LIVE"}
        if v not in allowed:
            raise ValueError(f"mode must be one of {allowed}")
        return v

    @field_validator("mode")
    @classmethod
    def _block_live(cls, v: str) -> str:
        if v == "LIVE":
            if not (
                os.environ.get("ENABLE_LIVE_TRADING", "").lower() == "true"
                and os.environ.get("LIVE_TRADING_CONFIRMED", "").lower() == "true"
            ):
                raise ValueError(
                    "LIVE mode requires both ENABLE_LIVE_TRADING=true and "
                    "LIVE_TRADING_CONFIRMED=true environment variables"
                )
        return v


class BrokerSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="BROKER_", extra="ignore")

    default_broker: str = "paper"
    zerodha_api_key: Optional[str] = None
    zerodha_api_secret: Optional[str] = None


class RiskSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RISK_", extra="ignore")

    max_leverage: Decimal = Decimal("5")
    daily_loss_limit_pct: Decimal = Decimal("2")
    max_drawdown_pct: Decimal = Decimal("5")
    max_trades_per_day: int = 50
    max_orders_per_minute: int = 10
    sector_exposure_pct: Decimal = Decimal("20")
    correlation_threshold: Decimal = Decimal("0.7")
    risk_per_trade_pct: Decimal = Decimal("1")


class ExecutionSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="EXEC_", extra="ignore")

    default_order_type: str = "MARKET"
    slippage_model: str = "fixed"
    slippage_bps: Decimal = Decimal("1")


class StrategySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="STRATEGY_", extra="ignore")

    max_strategies: int = 20
    default_bar_interval: str = "1m"
    health_check_interval_seconds: int = 30


class LoggingSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LOG_", extra="ignore")

    level: str = "INFO"
    format: str = "structured_json"
    audit_all_sensitive: bool = True
    include_trace_id: bool = True


class IdempotencySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="IDEMPOTENCY_", extra="ignore")

    key_ttl_seconds: int = 86400


class APISettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="API_", extra="ignore")

    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: List[str] = Field(default_factory=lambda: ["http://localhost:3000"])


class PaperSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PAPER_", extra="ignore")

    initial_capital: Decimal = Decimal("1000000")
    commission_bps: Decimal = Decimal("5")


class MarketIntelligenceSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MI_", extra="ignore")

    enabled: bool = True
    enabled_timeframes: List[str] = Field(default_factory=lambda: ["1m", "5m", "15m", "1h"])
    max_indicator_buffer_bars: int = 150
    announcement_poll_interval_seconds: int = 60
    announcement_ttl_hours: int = 24
    announcement_blackout_window_minutes: int = 30
    bse_announcement_base_url: str = (
        "https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w"
    )
    nse_announcement_base_url: str = (
        "https://www.nseindia.com/api/corporate-announcements"
    )

    @field_validator("enabled_timeframes")
    @classmethod
    def _validate_timeframes(cls, v: List[str]) -> List[str]:
        allowed = {"1m", "5m", "15m", "1h", "daily"}
        invalid = set(v) - allowed
        if invalid:
            raise ValueError(f"Invalid timeframes: {invalid}. Allowed: {allowed}")
        return v


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = Field(
        default="postgresql+asyncpg://user:pass@localhost/intraday",
        validation_alias="INTRADAY_DATABASE_URL",
    )
    database_url_sync: str = Field(
        default="postgresql://user:pass@localhost/intraday",
        validation_alias="INTRADAY_DATABASE_URL_SYNC",
    )
    jwt_secret_key: str = Field(
        default="change-me-in-production",
        validation_alias="JWT_SECRET_KEY",
    )

    trading: TradingSettings = Field(default_factory=TradingSettings)
    broker: BrokerSettings = Field(default_factory=BrokerSettings)
    risk: RiskSettings = Field(default_factory=RiskSettings)
    execution: ExecutionSettings = Field(default_factory=ExecutionSettings)
    strategy: StrategySettings = Field(default_factory=StrategySettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    idempotency: IdempotencySettings = Field(default_factory=IdempotencySettings)
    api: APISettings = Field(default_factory=APISettings)
    paper: PaperSettings = Field(default_factory=PaperSettings)
    market_intelligence: MarketIntelligenceSettings = Field(
        default_factory=MarketIntelligenceSettings
    )


settings = Settings()
