from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class KillSwitchRecord:
    account_id: str
    activated: bool
    reason: str
    activated_at: Optional[datetime] = None
    deactivated_at: Optional[datetime] = None
    operator_id: Optional[str] = None


class KillSwitch:
    """Thread-safe async kill switch per account."""

    def __init__(self) -> None:
        self._states: Dict[str, bool] = {}
        self._reasons: Dict[str, str] = {}
        self._timestamps: Dict[str, datetime] = {}
        self._lock = asyncio.Lock()

    async def activate(self, account_id: str, reason: str, operator_id: Optional[str] = None) -> KillSwitchRecord:
        async with self._lock:
            self._states[account_id] = True
            self._reasons[account_id] = reason
            now = datetime.utcnow()
            self._timestamps[account_id] = now
            record = KillSwitchRecord(
                account_id=account_id,
                activated=True,
                reason=reason,
                activated_at=now,
                operator_id=operator_id,
            )
        logger.critical(
            "Kill switch activated",
            extra={"account_id": account_id, "reason": reason, "operator_id": operator_id},
        )
        return record

    async def deactivate(self, account_id: str, operator_id: Optional[str] = None) -> KillSwitchRecord:
        async with self._lock:
            was_active = self._states.get(account_id, False)
            self._states[account_id] = False
            now = datetime.utcnow()
            record = KillSwitchRecord(
                account_id=account_id,
                activated=False,
                reason=self._reasons.get(account_id, ""),
                activated_at=self._timestamps.get(account_id) if was_active else None,
                deactivated_at=now,
                operator_id=operator_id,
            )
        logger.info(
            "Kill switch deactivated",
            extra={"account_id": account_id, "operator_id": operator_id},
        )
        return record

    def is_active(self, account_id: str) -> bool:
        return self._states.get(account_id, False)

    def get_state(self, account_id: str) -> KillSwitchRecord:
        return KillSwitchRecord(
            account_id=account_id,
            activated=self._states.get(account_id, False),
            reason=self._reasons.get(account_id, ""),
            activated_at=self._timestamps.get(account_id),
        )
