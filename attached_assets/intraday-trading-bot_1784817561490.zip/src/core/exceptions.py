from __future__ import annotations


class ApplicationError(Exception):
    """Base application exception."""
    pass


class LiveModeBlockedError(ApplicationError):
    """Raised when LIVE mode is requested but not permitted."""
    pass


class ConfigurationError(ApplicationError):
    """Raised on invalid configuration."""
    pass
