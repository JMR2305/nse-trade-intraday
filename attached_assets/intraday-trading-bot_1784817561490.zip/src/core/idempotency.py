from __future__ import annotations

import hashlib
import uuid


def generate_idempotency_key(*parts: str) -> str:
    """Generate a deterministic idempotency key from parts."""
    base = "|".join(parts) if parts else str(uuid.uuid4())
    return hashlib.sha256(base.encode()).hexdigest()[:32]
