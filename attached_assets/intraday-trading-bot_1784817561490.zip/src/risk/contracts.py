from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class RiskSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class RiskCheckType(str, Enum):
    ORDER_QUANTITY = "ORDER_QUANTITY"
    ORDER_VALUE = "ORDER_VALUE"
    TICK_SIZE = "TICK_SIZE"
    PRICE_BAND = "PRICE_BAND"
    MAX_POSITION_SIZE = "MAX_POSITION_SIZE"
    INSTRUMENT_EXPOSURE = "INSTRUMENT_EXPOSURE"
    NET_EXPOSURE = "NET_EXPOSURE"
    CONCENTRATION_LIMIT = "CONCENTRATION_LIMIT"
    CASH_AVAILABILITY = "CASH_AVAILABILITY"
    BUYING_POWER = "BUYING_POWER"
    PORTFOLIO_EXPOSURE = "PORTFOLIO_EXPOSURE"
    MARGIN_AVAILABILITY = "MARGIN_AVAILABILITY"
    DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
    DAILY_PROFIT_TARGET_LOCK = "DAILY_PROFIT_TARGET_LOCK"
    MAX_TRADES_PER_DAY = "MAX_TRADES_PER_DAY"
    MAX_ORDERS_PER_MINUTE = "MAX_ORDERS_PER_MINUTE"
    KILL_SWITCH = "KILL_SWITCH"
    EMERGENCY_HALT = "EMERGENCY_HALT"
    CIRCUIT_BREAKER = "CIRCUIT_BREAKER"
    DUPLICATE_ORDER = "DUPLICATE_ORDER"
    SELF_TRADE = "SELF_TRADE"
    DRAWDOWN = "DRAWDOWN"
    TURNOVER_VELOCITY = "TURNOVER_VELOCITY"


class RiskViolation(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    check_type: RiskCheckType
    severity: RiskSeverity
    message: str
    limit_value: Optional[Decimal] = None
    actual_value: Optional[Decimal] = None


class RiskResult(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    approved: bool
    violations: List[RiskViolation] = Field(default_factory=list)


class RiskRequest(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    order: Dict[str, Any]
    account_id: str


class RiskContext(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    portfolio: Optional[Dict[str, Any]] = None
    positions: Dict[str, Any] = Field(default_factory=dict)
    open_orders: List[Dict[str, Any]] = Field(default_factory=list)
    market_price: Optional[Decimal] = None
    daily_stats: Optional[Dict[str, Any]] = None


class RiskConfiguration(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    check_type: RiskCheckType
    enabled: bool = True
    limit_value: Optional[Decimal] = None


class RiskStateSnapshot(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    account_id: str
    daily_pnl: Decimal = Decimal("0")
    daily_turnover: Decimal = Decimal("0")
    current_equity: Decimal = Decimal("0")
    peak_equity: Decimal = Decimal("0")
    trade_count_today: int = 0
    order_count_last_minute: int = 0
    kill_switch_active: bool = False
    emergency_halt_active: bool = False
    timestamp: str = ""
