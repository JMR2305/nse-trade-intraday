from __future__ import annotations

from typing import Dict, Type

from src.risk.contracts import RiskConfiguration, RiskCheckType


class RiskRule:
    def evaluate(self, config: RiskConfiguration, context: dict, state: dict) -> bool:
        return True


RULE_REGISTRY: Dict[RiskCheckType, Type[RiskRule]] = {}
