from __future__ import annotations

import asyncio
import logging
from decimal import Decimal
from typing import Dict, List

from src.risk.contracts import (
    RiskCheckType,
    RiskConfiguration,
    RiskContext,
    RiskRequest,
    RiskResult,
    RiskSeverity,
    RiskStateSnapshot,
    RiskViolation,
)

logger = logging.getLogger(__name__)


class RiskState:
    def __init__(self, account_id: str) -> None:
        self.account_id = account_id
        self.daily_pnl = Decimal("0")
        self.daily_turnover = Decimal("0")
        self.current_equity = Decimal("0")
        self.peak_equity = Decimal("0")
        self.trade_count_today = 0
        self.order_count_last_minute = 0
        self.kill_switch_active = False
        self.emergency_halt_active = False


class RiskEngine:
    def __init__(self) -> None:
        self._states: Dict[str, RiskState] = {}
        self._locks: Dict[str, asyncio.Lock] = {}

    def _get_lock(self, account_id: str) -> asyncio.Lock:
        if account_id not in self._locks:
            self._locks[account_id] = asyncio.Lock()
        return self._locks[account_id]

    def _get_state(self, account_id: str) -> RiskState:
        if account_id not in self._states:
            self._states[account_id] = RiskState(account_id)
        return self._states[account_id]

    async def evaluate(
        self,
        request: RiskRequest,
        context: RiskContext,
        limits: List[RiskConfiguration],
    ) -> RiskResult:
        async with self._get_lock(request.account_id):
            state = self._get_state(request.account_id)
            violations = []

            if state.kill_switch_active:
                violations.append(
                    RiskViolation(
                        check_type=RiskCheckType.KILL_SWITCH,
                        severity=RiskSeverity.CRITICAL,
                        message="Kill switch is active",
                    )
                )

            if state.emergency_halt_active:
                violations.append(
                    RiskViolation(
                        check_type=RiskCheckType.EMERGENCY_HALT,
                        severity=RiskSeverity.CRITICAL,
                        message="Emergency halt is active",
                    )
                )

            approved = len(violations) == 0
            return RiskResult(approved=approved, violations=violations)

    def record_fill(
        self,
        account_id: str,
        fill_id: str,
        realized_pnl: Decimal,
        turnover: Decimal,
        current_equity: Decimal,
        ts: str,
    ) -> None:
        state = self._get_state(account_id)
        state.daily_pnl += realized_pnl
        state.daily_turnover += turnover
        state.current_equity = current_equity
        state.peak_equity = max(state.peak_equity, current_equity)
        state.trade_count_today += 1

    def get_state_snapshot(self, account_id: str) -> RiskStateSnapshot:
        state = self._get_state(account_id)
        return RiskStateSnapshot(
            account_id=account_id,
            daily_pnl=state.daily_pnl,
            daily_turnover=state.daily_turnover,
            current_equity=state.current_equity,
            peak_equity=state.peak_equity,
            trade_count_today=state.trade_count_today,
            kill_switch_active=state.kill_switch_active,
            emergency_halt_active=state.emergency_halt_active,
        )

    def activate_kill_switch(self, account_id: str, reason: str) -> None:
        state = self._get_state(account_id)
        state.kill_switch_active = True
        logger.critical("Kill switch activated for %s: %s", account_id, reason)

    def deactivate_kill_switch(self, account_id: str) -> None:
        state = self._get_state(account_id)
        state.kill_switch_active = False
        logger.info("Kill switch deactivated for %s", account_id)
