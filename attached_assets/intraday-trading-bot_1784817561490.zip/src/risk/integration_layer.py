from __future__ import annotations

import asyncio
import logging
from decimal import Decimal
from typing import Any, Dict, List, Optional

from src.execution.contracts import ExecutionOrder
from src.execution.fills import FillEvent, FillEventBus
from src.risk.contracts import (
    RiskConfiguration,
    RiskContext,
    RiskRequest,
    RiskResult,
    RiskStateSnapshot,
)
from src.risk.engine import RiskEngine

logger = logging.getLogger(__name__)


class ExecutionEnginePort:
    async def get_portfolio_snapshot(self, account_id: str) -> Optional[Dict[str, Any]]:
        raise NotImplementedError

    async def get_position_snapshots(self, account_id: str) -> Dict[str, Any]:
        raise NotImplementedError

    async def get_open_orders(self, account_id: str) -> List[Any]:
        raise NotImplementedError

    async def get_market_price(self, instrument_token: str) -> Optional[Decimal]:
        raise NotImplementedError

    async def submit_order(self, account_id: str, order: ExecutionOrder) -> Dict[str, Any]:
        raise NotImplementedError


class RiskIntegrationResult:
    def __init__(
        self,
        approved: bool,
        execution_result: Optional[Dict[str, Any]] = None,
        violations: Optional[List[Any]] = None,
    ) -> None:
        self.approved = approved
        self.execution_result = execution_result or {}
        self.violations = violations or []


class RiskIntegrationLayer:
    def __init__(
        self,
        engine: RiskEngine,
        adapter: ExecutionEnginePort,
        fill_bus: FillEventBus,
        enabled: bool = True,
    ) -> None:
        self._engine = engine
        self._adapter = adapter
        self._fill_bus = fill_bus
        self._enabled = enabled
        self._limits: List[RiskConfiguration] = []
        self._locks: Dict[str, asyncio.Lock] = {}

    def _get_lock(self, account_id: str) -> asyncio.Lock:
        if account_id not in self._locks:
            self._locks[account_id] = asyncio.Lock()
        return self._locks[account_id]

    def add_limit(self, limit: RiskConfiguration) -> None:
        self._limits.append(limit)

    def set_limits(self, limits: List[RiskConfiguration]) -> None:
        self._limits = limits

    @property
    def limits(self) -> List[RiskConfiguration]:
        return self._limits

    async def submit_order(
        self,
        account_id: str,
        order: ExecutionOrder,
        limits: Optional[List[RiskConfiguration]] = None,
    ) -> RiskIntegrationResult:
        if not self._enabled:
            result = await self._adapter.submit_order(account_id, order)
            return RiskIntegrationResult(approved=True, execution_result=result)

        async with self._get_lock(account_id):
            context = RiskContext()
            request = RiskRequest(order=order.model_dump(), account_id=account_id)
            eval_limits = limits or self._limits
            risk_result = await self._engine.evaluate(request, context, eval_limits)

            if not risk_result.approved:
                return RiskIntegrationResult(
                    approved=False,
                    violations=risk_result.violations,
                )

            result = await self._adapter.submit_order(account_id, order)
            return RiskIntegrationResult(approved=True, execution_result=result)
