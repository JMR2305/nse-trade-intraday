from __future__ import annotations


class RiskError(Exception):
    pass


class KillSwitchActive(RiskError):
    pass


class EmergencyHaltActive(RiskError):
    pass


class IntegrationLayerError(RiskError):
    pass
