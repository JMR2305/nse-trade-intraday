from __future__ import annotations

from decimal import Decimal


class RiskState:
    def __init__(self, account_id: str) -> None:
        self.account_id = account_id
        self.daily_pnl = Decimal("0")
        self.daily_turnover = Decimal("0")
        self.current_equity = Decimal("0")
        self.peak_equity = Decimal("0")
        self.trade_count_today = 0
        self.order_count_last_minute = 0
        self.kill_switch_active = False
        self.emergency_halt_active = False
