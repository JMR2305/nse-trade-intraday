from __future__ import annotations

from decimal import Decimal
from typing import Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class PortfolioSnapshot(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    equity: Decimal
    cash: Decimal
    buying_power: Decimal
    available_margin: Decimal
    total_market_value: Decimal


class PositionSnapshot(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    net_quantity: Decimal
    direction: str
    market_value: Decimal
    average_price: Decimal = Decimal("0")
    unrealized_pnl: Decimal = Decimal("0")
