from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ExecutionOrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class ExecutionOrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    SL = "SL"
    SL_M = "SL_M"


class ExecutionOrderStatus(str, Enum):
    PENDING = "PENDING"
    OPEN = "OPEN"
    COMPLETE = "COMPLETE"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    PARTIAL_FILL = "PARTIAL_FILL"


class ExecutionOrderAction(str, Enum):
    PLACE = "PLACE"
    MODIFY = "MODIFY"
    CANCEL = "CANCEL"


class ExecutionOrder(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    client_order_id: str
    instrument_token: str
    side: ExecutionOrderSide
    order_type: ExecutionOrderType
    quantity: Decimal
    limit_price: Optional[Decimal] = None
    trigger_price: Optional[Decimal] = None
    status: ExecutionOrderStatus = ExecutionOrderStatus.PENDING
    filled_quantity: Decimal = Decimal("0")


class FillRecord(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    fill_id: str
    order_id: str
    side: ExecutionOrderSide
    quantity: Decimal
    price: Decimal
    fill_timestamp: str
    broker_fill_id: Optional[str] = None


class ExecutionAuditEvent(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    event_id: str
    order_id: str
    action: ExecutionOrderAction
    timestamp: str
    details: dict = Field(default_factory=dict)
