from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Callable, List, Awaitable, Optional

import logging

logger = logging.getLogger(__name__)


@dataclass(frozen=False)
class FillEvent:
    fill_id: str
    account_id: str
    instrument_token: str
    side: str
    quantity: Decimal
    fill_price: Decimal
    current_equity: Decimal
    fill_timestamp: str
    order_id: str
    broker_fill_id: Optional[str] = None


class FillEventBus:
    def __init__(self) -> None:
        self._subscribers: List[Callable[[FillEvent], Awaitable[None]]] = []

    def subscribe(self, handler: Callable[[FillEvent], Awaitable[None]]) -> None:
        self._subscribers.append(handler)

    def unsubscribe(self, handler: Callable[[FillEvent], Awaitable[None]]) -> None:
        if handler in self._subscribers:
            self._subscribers.remove(handler)

    async def publish(self, event: FillEvent) -> None:
        for handler in self._subscribers:
            try:
                await handler(event)
            except Exception as e:
                logger.warning("FillEvent handler failed: %s", e, exc_info=True)

    def publish_nowait(self, event: FillEvent) -> None:
        import asyncio
        asyncio.create_task(self.publish(event))

    @staticmethod
    def build_fill_event(
        fill_id: str,
        account_id: str,
        instrument_token: str,
        side: str,
        quantity: Decimal,
        fill_price: Decimal,
        current_equity: Decimal,
        fill_timestamp: str,
        order_id: str,
        broker_fill_id: Optional[str] = None,
    ) -> FillEvent:
        return FillEvent(
            fill_id=fill_id,
            account_id=account_id,
            instrument_token=instrument_token,
            side=side,
            quantity=quantity,
            fill_price=fill_price,
            current_equity=current_equity,
            fill_timestamp=fill_timestamp,
            order_id=order_id,
            broker_fill_id=broker_fill_id,
        )
