from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Tick(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    timestamp: str
    last_price: Decimal
    last_quantity: Decimal = Decimal("0")
    volume: Decimal = Decimal("0")
    buy_price: Decimal = Decimal("0")
    buy_quantity: Decimal = Decimal("0")
    sell_price: Decimal = Decimal("0")
    sell_quantity: Decimal = Decimal("0")
    ohlc_open: Optional[Decimal] = None
    ohlc_high: Optional[Decimal] = None
    ohlc_low: Optional[Decimal] = None
    ohlc_close: Optional[Decimal] = None


class CompletedBar(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    timestamp: str
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    interval: str = "1m"


class Quote(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    timestamp: str
    bid: Decimal
    ask: Decimal
    bid_quantity: Decimal = Decimal("0")
    ask_quantity: Decimal = Decimal("0")
    last_price: Decimal = Decimal("0")


class DataGap(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    expected_timestamp: str
    actual_timestamp: str


class SubscriptionRequest(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    interval: str = "1m"


class DataQualityStatus(str, Enum):
    OK = "OK"
    DEGRADED = "DEGRADED"
    STALE = "STALE"
    DOWN = "DOWN"


class DataQualityEvent(BaseModel, frozen=True):
    model_config = ConfigDict(frozen=True)

    instrument_token: str
    status: DataQualityStatus
    timestamp: str
    details: str = ""
