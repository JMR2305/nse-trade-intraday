from __future__ import annotations

import logging
from typing import Callable, Awaitable, List

from src.market_data.contracts import CompletedBar, Tick

logger = logging.getLogger(__name__)


class MarketDataService:
    def __init__(self) -> None:
        self._bar_handlers: List[Callable[[CompletedBar], Awaitable[None]]] = []
        self._tick_handlers: List[Callable[[Tick], Awaitable[None]]] = []
        self._subscriptions: set = set()

    def subscribe(self, instrument_token: str) -> None:
        self._subscriptions.add(instrument_token)

    def unsubscribe(self, instrument_token: str) -> None:
        self._subscriptions.discard(instrument_token)

    def on_bar(self, callback: Callable[[CompletedBar], Awaitable[None]]) -> None:
        self._bar_handlers.append(callback)

    def on_tick(self, callback: Callable[[Tick], Awaitable[None]]) -> None:
        self._tick_handlers.append(callback)

    async def publish_bar(self, bar: CompletedBar) -> None:
        for handler in self._bar_handlers:
            try:
                await handler(bar)
            except Exception as e:
                logger.warning("Bar handler failed: %s", e)

    async def publish_tick(self, tick: Tick) -> None:
        for handler in self._tick_handlers:
            try:
                await handler(tick)
            except Exception as e:
                logger.warning("Tick handler failed: %s", e)
