from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from src.core.config import settings
from src.core.logging import setup_logging

setup_logging()

app = FastAPI(title="Intraday Trading Bot", version="0.10.0")


@app.get("/health")
async def health():
    return {"status": "ok", "version": "0.10.0"}
