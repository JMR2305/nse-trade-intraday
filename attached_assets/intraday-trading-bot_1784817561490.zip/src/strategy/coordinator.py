from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from src.market_data.contracts import CompletedBar
from src.market_data.service import MarketDataService
from src.execution.fills import FillEvent, FillEventBus
from src.strategy.contracts import (
    StrategyConfig,
    StrategyLifecycleState,
    StrategyRegistrationResult,
)
from src.strategy.context_builder import ContextBuilder
from src.strategy.exceptions import StrategyNotFoundError, StrategyAlreadyRegisteredError
from src.strategy.health import StrategyHealthMonitor
from src.strategy.metrics import MetricsCollector
from src.strategy.runtime import StrategyRuntime
from src.strategy.signal_router import SignalRouter
from src.strategy.state_machine import StrategyStateMachine

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ShutdownResult:
    strategies_stopped: int
    strategies_failed: int
    snapshots_flushed: int
    completed_at: str


class StrategyCoordinator:
    def __init__(
        self,
        market_data_service: MarketDataService,
        fill_event_bus: FillEventBus,
        context_builder: ContextBuilder,
        signal_router: SignalRouter,
        metrics_collector: Optional[MetricsCollector] = None,
        health_monitor: Optional[StrategyHealthMonitor] = None,
    ) -> None:
        self._mds = market_data_service
        self._feb = fill_event_bus
        self._context_builder = context_builder
        self._signal_router = signal_router
        self._metrics = metrics_collector or MetricsCollector()
        self._health = health_monitor
        self._runtimes: Dict[str, StrategyRuntime] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._shutting_down = False

    def _get_lock(self, strategy_id: str) -> asyncio.Lock:
        if strategy_id not in self._locks:
            self._locks[strategy_id] = asyncio.Lock()
        return self._locks[strategy_id]

    async def register(
        self,
        config: StrategyConfig,
        strategy_instance: Any,
    ) -> StrategyRegistrationResult:
        if self._shutting_down:
            raise StrategyAlreadyRegisteredError("Coordinator is shutting down")

        async with self._get_lock(config.strategy_id):
            if config.strategy_id in self._runtimes:
                return StrategyRegistrationResult(
                    strategy_id=config.strategy_id,
                    success=False,
                    message="Strategy already registered",
                )

            self._metrics.initialize(config.strategy_id)
            runtime = StrategyRuntime(
                config=config,
                strategy=strategy_instance,
                context_builder=self._context_builder,
                market_data_service=self._mds,
                fill_event_bus=self._feb,
                signal_router=self._signal_router,
                metrics_collector=self._metrics,
            )
            self._runtimes[config.strategy_id] = runtime

            return StrategyRegistrationResult(
                strategy_id=config.strategy_id,
                success=True,
                message="Registered successfully",
            )

    async def start(self, strategy_id: str) -> None:
        runtime = self._runtimes.get(strategy_id)
        if runtime is None:
            raise StrategyNotFoundError(f"Strategy {strategy_id} not found")
        await runtime.start()

    async def pause(self, strategy_id: str) -> None:
        runtime = self._runtimes.get(strategy_id)
        if runtime is None:
            raise StrategyNotFoundError(f"Strategy {strategy_id} not found")
        await runtime.pause()

    async def resume(self, strategy_id: str) -> None:
        runtime = self._runtimes.get(strategy_id)
        if runtime is None:
            raise StrategyNotFoundError(f"Strategy {strategy_id} not found")
        await runtime.resume()

    async def stop(self, strategy_id: str) -> None:
        runtime = self._runtimes.get(strategy_id)
        if runtime is None:
            raise StrategyNotFoundError(f"Strategy {strategy_id} not found")
        await runtime.stop()

    async def shutdown(self, timeout_seconds: int = 30) -> ShutdownResult:
        self._shutting_down = True
        stopped = 0
        failed = 0

        for sid, runtime in list(self._runtimes.items()):
            try:
                await runtime.stop()
                stopped += 1
            except Exception as e:
                logger.error("Failed to stop strategy %s: %s", sid, e)
                failed += 1

        return ShutdownResult(
            strategies_stopped=stopped,
            strategies_failed=failed,
            snapshots_flushed=len(self._runtimes),
            completed_at="",
        )
