from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any, Dict, List, Optional

from src.market_data.contracts import CompletedBar
from src.strategy.contracts import StrategyConfig, StrategyContext

logger = logging.getLogger(__name__)


class ContextBuilder:
    """Builds StrategyContext for each bar cycle.

    RC-10A: Optionally injects market intelligence data.
    """

    def __init__(
        self,
        indicator_engine: Optional[Any] = None,
        regime_detector: Optional[Any] = None,
        announcement_service: Optional[Any] = None,
        watchlist_ranker: Optional[Any] = None,
    ) -> None:
        self._indicator_engine = indicator_engine
        self._regime_detector = regime_detector
        self._announcement_service = announcement_service
        self._watchlist_ranker = watchlist_ranker

    def build(
        self,
        config: StrategyConfig,
        state_snapshot: Dict[str, Any],
        bar: Optional[CompletedBar] = None,
    ) -> StrategyContext:
        """Build strategy context. Preserves pre-RC-10A behavior when intelligence not injected."""
        market_snapshots: Dict[str, Any] = {}

        if self._indicator_engine is not None:
            for token in config.instrument_tokens:
                mtf_data: Dict[str, Any] = {}
                try:
                    all_tf = self._indicator_engine.get_all_timeframes(token)
                    mtf_data["timeframes"] = all_tf
                except Exception as e:
                    logger.debug("IndicatorEngine failed for %s: %s", token, e)

                if self._regime_detector is not None and "timeframes" in mtf_data:
                    try:
                        regime_tf = None
                        for tf in ["15m", "1h", "5m", "1m"]:
                            if tf in mtf_data["timeframes"]:
                                regime_tf = tf
                                break
                        if regime_tf:
                            indicators = mtf_data["timeframes"][regime_tf]
                            regime = self._regime_detector.detect(token, indicators)
                            mtf_data["regime"] = regime
                    except Exception as e:
                        logger.debug("Regime detection failed for %s: %s", token, e)

                if self._announcement_service is not None:
                    try:
                        announcements = self._announcement_service.get_active_announcements_sync(token)
                        mtf_data["active_announcements"] = announcements
                    except Exception as e:
                        logger.debug("Announcement service failed for %s: %s", token, e)

                if mtf_data:
                    market_snapshots[token] = mtf_data

        return StrategyContext(
            strategy_id=config.strategy_id,
            instrument_tokens=list(config.instrument_tokens),
            current_positions=state_snapshot.get("current_positions", {}),
            portfolio_snapshot=state_snapshot.get("portfolio_snapshot"),
            market_snapshots=market_snapshots,
            risk_state=state_snapshot.get("risk_state"),
            session_metadata=state_snapshot.get("session_metadata", {}),
        )
