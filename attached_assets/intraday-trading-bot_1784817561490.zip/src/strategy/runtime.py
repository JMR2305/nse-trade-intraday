from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

from src.market_data.contracts import CompletedBar, Tick
from src.market_data.service import MarketDataService
from src.execution.fills import FillEvent, FillEventBus
from src.strategy.contracts import (
    Signal,
    StrategyConfig,
    StrategyContext,
    StrategyLifecycleState,
)
from src.strategy.context_builder import ContextBuilder
from src.strategy.exceptions import StrategyRuntimeError
from src.strategy.fill_tracker import StrategyFillTracker
from src.strategy.metrics import MetricsCollector
from src.strategy.signal_router import SignalRouter
from src.strategy.state_machine import StrategyStateMachine

logger = logging.getLogger(__name__)


class StrategyRuntime:
    def __init__(
        self,
        config: StrategyConfig,
        strategy: Any,
        context_builder: ContextBuilder,
        market_data_service: MarketDataService,
        fill_event_bus: FillEventBus,
        signal_router: SignalRouter,
        metrics_collector: Optional[MetricsCollector] = None,
    ) -> None:
        self._config = config
        self._strategy = strategy
        self._context_builder = context_builder
        self._mds = market_data_service
        self._feb = fill_event_bus
        self._signal_router = signal_router
        self._metrics = metrics_collector
        self._state_machine = StrategyStateMachine(config.strategy_id)
        self._fill_tracker = StrategyFillTracker()
        self._task: Optional[asyncio.Task] = None
        self._running = False

    async def start(self) -> None:
        self._state_machine.transition(StrategyLifecycleState.STARTING)
        self._running = True
        self._state_machine.transition(StrategyLifecycleState.ACTIVE)
        for token in self._config.instrument_tokens:
            self._mds.subscribe(token)

    async def pause(self) -> None:
        self._state_machine.transition(StrategyLifecycleState.PAUSED)
        self._running = False

    async def resume(self) -> None:
        self._state_machine.transition(StrategyLifecycleState.ACTIVE)
        self._running = True

    async def stop(self) -> None:
        self._state_machine.transition(StrategyLifecycleState.STOPPING)
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._state_machine.transition(StrategyLifecycleState.STOPPED)

    async def _process_bar(self, bar: CompletedBar) -> None:
        if not self._state_machine.can_emit_signals:
            return

        try:
            ctx = self._context_builder.build(self._config, {})
            signal = self._strategy.on_bar(bar, ctx)
            if signal and self._metrics:
                await self._metrics.record_signal(self._config.strategy_id)
            if signal:
                await self._signal_router.route(signal, self._config.strategy_id)
        except Exception as e:
            logger.error("Error processing bar for %s: %s", self._config.strategy_id, e)
            if self._metrics:
                await self._metrics.record_error(self._config.strategy_id)

    async def _on_fill(self, event: FillEvent) -> None:
        self._fill_tracker.record_fill(event)
        ctx = self._context_builder.build(self._config, {})
        signal = self._strategy.on_fill(event, ctx)
        if signal:
            await self._signal_router.route(signal, self._config.strategy_id)
