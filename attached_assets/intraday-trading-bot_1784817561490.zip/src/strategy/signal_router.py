from __future__ import annotations

import logging
from typing import Optional

from src.execution.contracts import ExecutionOrder, ExecutionOrderSide, ExecutionOrderType
from src.risk.integration_layer import RiskIntegrationLayer
from src.strategy.contracts import Signal, SignalRoutingResult

logger = logging.getLogger(__name__)


class SignalRouter:
    def __init__(self, risk_layer: RiskIntegrationLayer) -> None:
        self._risk_layer = risk_layer

    async def route(self, signal: Signal, account_id: str) -> SignalRoutingResult:
        side = ExecutionOrderSide.BUY if signal.side == "BUY" else ExecutionOrderSide.SELL
        order = ExecutionOrder(
            client_order_id=signal.signal_id,
            instrument_token=signal.instrument_token,
            side=side,
            order_type=ExecutionOrderType(signal.order_type),
            quantity=signal.quantity,
            limit_price=signal.limit_price,
            trigger_price=signal.trigger_price,
        )

        result = await self._risk_layer.submit_order(account_id, order)

        if result.approved:
            return SignalRoutingResult(
                signal_id=signal.signal_id,
                routed=True,
                client_order_id=signal.signal_id,
            )
        else:
            return SignalRoutingResult(
                signal_id=signal.signal_id,
                routed=False,
                rejection_reason="; ".join(
                    v.message for v in result.violations
                ),
            )
