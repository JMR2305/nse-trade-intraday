from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional

from src.strategy.metrics import MetricsCollector, StrategyMetrics


class StrategyHealthStatus(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    UNHEALTHY = "UNHEALTHY"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class HealthReport:
    status: StrategyHealthStatus
    reason: str
    consecutive_errors: int
    last_bar_latency_ms: float
    bars_processed: int
    signals_emitted: int
    error_count: int
    last_checked: str


class StrategyHealthMonitor:
    def __init__(
        self,
        metrics: MetricsCollector,
        degraded_consecutive_errors: int = 3,
        unhealthy_consecutive_errors: int = 5,
        degraded_latency_ms: float = 500.0,
        unhealthy_latency_ms: float = 2000.0,
    ) -> None:
        self._metrics = metrics
        self._degraded_errors = degraded_consecutive_errors
        self._unhealthy_errors = unhealthy_consecutive_errors
        self._degraded_latency = degraded_latency_ms
        self._unhealthy_latency = unhealthy_latency_ms

    def compute_health(self, strategy_id: str) -> HealthReport:
        metrics = self._metrics.get_metrics(strategy_id)
        if metrics is None:
            return HealthReport(
                status=StrategyHealthStatus.UNKNOWN,
                reason="No metrics recorded",
                consecutive_errors=0,
                last_bar_latency_ms=0.0,
                bars_processed=0,
                signals_emitted=0,
                error_count=0,
                last_checked="",
            )

        status = StrategyHealthStatus.HEALTHY
        reason = "All systems normal"

        if metrics.consecutive_errors >= self._unhealthy_errors:
            status = StrategyHealthStatus.UNHEALTHY
            reason = f"Consecutive errors: {metrics.consecutive_errors}"
        elif metrics.consecutive_errors >= self._degraded_errors:
            status = StrategyHealthStatus.DEGRADED
            reason = f"Consecutive errors: {metrics.consecutive_errors}"
        elif metrics.last_bar_latency_ms >= self._unhealthy_latency:
            status = StrategyHealthStatus.UNHEALTHY
            reason = f"Latency: {metrics.last_bar_latency_ms}ms"
        elif metrics.last_bar_latency_ms >= self._degraded_latency:
            status = StrategyHealthStatus.DEGRADED
            reason = f"Latency: {metrics.last_bar_latency_ms}ms"

        return HealthReport(
            status=status,
            reason=reason,
            consecutive_errors=metrics.consecutive_errors,
            last_bar_latency_ms=metrics.last_bar_latency_ms,
            bars_processed=metrics.bars_processed,
            signals_emitted=metrics.signals_emitted,
            error_count=metrics.error_count,
            last_checked="",
        )
