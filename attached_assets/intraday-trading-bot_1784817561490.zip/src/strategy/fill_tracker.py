from __future__ import annotations

from typing import Dict, List

from src.execution.fills import FillEvent


class StrategyFillTracker:
    def __init__(self) -> None:
        self._fills: Dict[str, List[FillEvent]] = {}

    def record_fill(self, event: FillEvent) -> None:
        if event.instrument_token not in self._fills:
            self._fills[event.instrument_token] = []
        self._fills[event.instrument_token].append(event)

    def get_fills(self, instrument_token: str) -> List[FillEvent]:
        return self._fills.get(instrument_token, [])
