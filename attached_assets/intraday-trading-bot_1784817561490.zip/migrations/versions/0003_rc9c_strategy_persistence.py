"""RC-9C: Strategy persistence

Revision ID: 0003
Revises: 0002
Create Date: 2024-02-01 00:00:00

"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "strategy_configs",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("strategy_id", sa.String(50), unique=True, nullable=False),
        sa.Column("strategy_type", sa.String(50), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("account_id", sa.String(50), nullable=True),
        sa.Column("configuration", sa.JSON, default=dict),
        sa.Column("instrument_tokens", sa.JSON, default=list),
        sa.Column("lifecycle_state", sa.String(20), nullable=False, default="REGISTERED"),
        sa.Column("enabled", sa.Boolean, default=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "strategy_signals",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("signal_id", sa.String(50), unique=True, nullable=False),
        sa.Column("strategy_id", sa.String(50), nullable=False),
        sa.Column("account_id", sa.String(50), nullable=True),
        sa.Column("instrument_token", sa.String(50), nullable=False),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column("side", sa.String(10), nullable=False),
        sa.Column("quantity", sa.Numeric(15, 4), nullable=False),
        sa.Column("order_type", sa.String(20), nullable=False, default="MARKET"),
        sa.Column("routing_status", sa.String(20), nullable=False, default="PENDING"),
        sa.Column("routed_client_order_id", sa.String(50), nullable=True),
        sa.Column("rejection_reason", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "strategy_state_snapshots",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("strategy_id", sa.String(50), nullable=False),
        sa.Column("lifecycle_state", sa.String(20), nullable=False),
        sa.Column("pending_order_ids", sa.JSON, default=list),
        sa.Column("latest_signal_timestamp", sa.DateTime(timezone=True), nullable=True),
        sa.Column("emitted_signal_count", sa.Integer, default=0),
        sa.Column("routed_signal_count", sa.Integer, default=0),
        sa.Column("rejected_signal_count", sa.Integer, default=0),
        sa.Column("fill_count", sa.Integer, default=0),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("strategy_state_snapshots")
    op.drop_table("strategy_signals")
    op.drop_table("strategy_configs")
