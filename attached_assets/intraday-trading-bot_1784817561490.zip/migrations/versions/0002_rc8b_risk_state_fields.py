"""RC-8B: Risk state fields

Revision ID: 0002
Revises: 0001
Create Date: 2024-01-15 00:00:00

"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "risk_state_snapshots",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("account_id", sa.String(50), nullable=False),
        sa.Column("snapshot_data", sa.JSON, default=dict),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("risk_state_snapshots")
