"""Initial schema

Revision ID: 0001
Revises: 
Create Date: 2024-01-01 00:00:00

"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "instrument_master",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("instrument_token", sa.String(50), unique=True, nullable=False),
        sa.Column("tradingsymbol", sa.String(50), nullable=False),
        sa.Column("exchange", sa.String(10), nullable=False),
        sa.Column("instrument_type", sa.String(20), nullable=False),
        sa.Column("tick_size", sa.Numeric(10, 4), default=0.05),
        sa.Column("lot_size", sa.Integer, default=1),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "trading_sessions",
        sa.Column("session_id", sa.String(50), primary_key=True),
        sa.Column("status", sa.String(20), nullable=False, default="INITIALIZING"),
        sa.Column("trading_mode", sa.String(20), nullable=False, default="PAPER"),
        sa.Column("idempotency_key", sa.String(64), unique=True, nullable=False),
        sa.Column("previous_session_id", sa.String(50), nullable=True),
        sa.Column("recovery_reason", sa.Text, nullable=True),
        sa.Column("recovery_snapshot", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "orders",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("order_id", sa.String(50), unique=True, nullable=False),
        sa.Column("client_order_id", sa.String(50), nullable=False),
        sa.Column("account_id", sa.String(50), nullable=False),
        sa.Column("instrument_token", sa.String(50), nullable=False),
        sa.Column("side", sa.String(10), nullable=False),
        sa.Column("order_type", sa.String(20), nullable=False),
        sa.Column("quantity", sa.Numeric(15, 4), nullable=False),
        sa.Column("filled_quantity", sa.Numeric(15, 4), default=0),
        sa.Column("limit_price", sa.Numeric(15, 4), nullable=True),
        sa.Column("trigger_price", sa.Numeric(15, 4), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, default="PENDING"),
        sa.Column("broker_order_id", sa.String(50), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "positions",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("account_id", sa.String(50), nullable=False),
        sa.Column("instrument_token", sa.String(50), nullable=False),
        sa.Column("tradingsymbol", sa.String(50), nullable=False),
        sa.Column("net_quantity", sa.Numeric(15, 4), nullable=False),
        sa.Column("average_price", sa.Numeric(15, 4), nullable=False),
        sa.Column("market_value", sa.Numeric(15, 4), default=0),
        sa.Column("realized_pnl", sa.Numeric(15, 4), default=0),
        sa.Column("unrealized_pnl", sa.Numeric(15, 4), default=0),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_unique_constraint("uq_position", "positions", ["account_id", "instrument_token"])

    op.create_table(
        "fills",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("fill_id", sa.String(50), unique=True, nullable=False),
        sa.Column("order_id", sa.String(50), sa.ForeignKey("orders.order_id"), nullable=False),
        sa.Column("account_id", sa.String(50), nullable=False),
        sa.Column("instrument_token", sa.String(50), nullable=False),
        sa.Column("side", sa.String(10), nullable=False),
        sa.Column("quantity", sa.Numeric(15, 4), nullable=False),
        sa.Column("price", sa.Numeric(15, 4), nullable=False),
        sa.Column("fill_timestamp", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("broker_fill_id", sa.String(50), nullable=True),
    )

    op.create_table(
        "paper_account_ledger",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("account_id", sa.String(50), nullable=False),
        sa.Column("entry_type", sa.String(20), nullable=False),
        sa.Column("amount", sa.Numeric(15, 4), nullable=False),
        sa.Column("balance", sa.Numeric(15, 4), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "audit_log",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("table_name", sa.String(50), nullable=False),
        sa.Column("record_id", sa.String(50), nullable=False),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column("old_values", sa.JSON, nullable=True),
        sa.Column("new_values", sa.JSON, nullable=True),
        sa.Column("operator_id", sa.String(50), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "incidents",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("incident_id", sa.String(50), unique=True, nullable=False),
        sa.Column("severity", sa.String(20), nullable=False),
        sa.Column("category", sa.String(50), nullable=False),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("strategy_id", sa.String(50), nullable=True),
        sa.Column("instrument_token", sa.String(50), nullable=True),
        sa.Column("metadata", sa.JSON, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "system_heartbeats",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("component", sa.String(50), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("last_beat_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    op.create_table(
        "idempotency_keys",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("key", sa.String(64), unique=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("idempotency_keys")
    op.drop_table("system_heartbeats")
    op.drop_table("incidents")
    op.drop_table("audit_log")
    op.drop_table("paper_account_ledger")
    op.drop_table("fills")
    op.drop_table("positions")
    op.drop_table("orders")
    op.drop_table("trading_sessions")
    op.drop_table("instrument_master")
