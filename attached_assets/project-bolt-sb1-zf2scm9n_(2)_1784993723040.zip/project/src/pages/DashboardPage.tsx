import {
  Activity,
  ArrowUpRight,
  Brain,
  FileText,
  GitBranch,
  Plus,
  Play,
  Shield,
  Sparkles,
  TrendingUp,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge, StatusBadge } from '@/components/ui/Badge';
import { MetricCard } from '@/components/data-display/MetricCard';
import { ProgressGauge } from '@/components/data-display/ProgressGauge';
import { AreaChart, BarChart, DonutChart, Heatmap, Sparkline, Timeline } from '@/components/charts/Charts';
import { SectionHeading, PageHero } from '@/components/ui/Section';
import {
  aiConfidenceSeries,
  aiSummary,
  capitalAllocation,
  holdings,
  marketBreadth,
  marketStatus,
  pnlContribution,
  portfolioGrowth,
  portfolioSummary,
  projectTimeline,
  quickActions,
  recentActivity,
  recentSignals,
  releases,
  riskHeatmap,
  riskOverview,
  riskTrend,
  sectorAllocation,
  strategies,
} from '@/lib/demo-data';
import { formatCurrency, formatPercent, relativeTime } from '@/lib/utils';
import { toneRgb, type Tone } from '@/lib/theme';

const quickActionIcons: Record<string, LucideIcon> = { Plus, Play, Shield, Sparkles, FileText };

export function DashboardPage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Command Center · 25 Jul 2026"
        title="Good morning, Ava"
        description="Markets are risk-on. Your AI ensemble is running 3 live strategies with 78% confidence. Net liquidation is up 1.84% today."
      >
        <Button variant="gradient" leftIcon={<Plus className="h-4 w-4" />}>New Order</Button>
        <Button variant="secondary" leftIcon={<Sparkles className="h-4 w-4" />}>Ask AI</Button>
      </PageHero>

      {/* Portfolio snapshot metrics */}
      <section>
        <SectionHeading title="Portfolio Snapshot" subtitle="Net liquidation, P&L and liquidity at a glance" />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {portfolioSummary.map((m, i) => (
            <MetricCard key={m.label} {...m} delay={i * 80} icon={<TrendingUp className="h-4 w-4" />} />
          ))}
        </div>
      </section>

      {/* Platform overview + AI assistant summary */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader
            title="Portfolio Growth"
            subtitle="Net liquidation over the last 18 sessions"
            action={<Badge tone="success" dot pulse>+14.3% MTD</Badge>}
          />
          <CardBody>
            <AreaChart data={portfolioGrowth} tone="primary" height={240}
              labels={['Jun 24', 'Jul 1', 'Jul 8', 'Jul 15', 'Jul 22', 'Today']} />
          </CardBody>
        </Card>

        <Card hover gradientBorder>
          <CardHeader title="AI Assistant Summary" subtitle="Ensemble v4.2.1" action={<Badge tone="primary" dot pulse>AI ACTIVE</Badge>} />
          <CardBody className="space-y-4">
            <div className="flex items-center gap-4">
              <ProgressGauge value={aiSummary.confidence} tone="primary" size={104} label="Confidence" />
              <div className="flex-1 space-y-2.5">
                <div className="flex items-center justify-between text-[13px]">
                  <span className="text-muted">Market Regime</span>
                  <Badge tone="success">{aiSummary.marketRegime}</Badge>
                </div>
                <div className="flex items-center justify-between text-[13px]">
                  <span className="text-muted">Sentiment</span>
                  <span className="font-semibold tabular-nums text-fg">{aiSummary.sentiment}/100</span>
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px] text-faint">
                    <span>Bearish</span><span>Bullish</span>
                  </div>
                  <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
                    <div className="h-full rounded-full bg-gradient-to-r from-danger via-warning to-success" style={{ width: `${aiSummary.sentiment}%` }} />
                  </div>
                </div>
              </div>
            </div>
            <p className="rounded-xl border border-border/60 bg-surface-2/40 p-3 text-[12px] leading-relaxed text-muted">
              {aiSummary.narrative}
            </p>
          </CardBody>
        </Card>
      </section>

      {/* Market intelligence */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Market Intelligence" subtitle="Cross-asset regime and breadth" action={<Badge tone="info">{marketStatus.regime}</Badge>} />
          <CardBody>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: 'VIX', value: marketStatus.vix.toFixed(2), delta: marketStatus.vixChange, tone: 'info' as Tone },
                { label: 'Breadth', value: `${(marketStatus.breadth * 100).toFixed(0)}%`, delta: marketStatus.breadthChange, tone: 'success' as Tone },
                { label: '10Y Yield', value: `${marketStatus.tenYear.toFixed(2)}%`, delta: marketStatus.tenYearChange, tone: 'warning' as Tone },
                { label: 'DXY', value: marketStatus.dollar.toFixed(2), delta: marketStatus.dollarChange, tone: 'accent' as Tone },
              ].map((s) => (
                <div key={s.label} className="rounded-xl border border-border/60 bg-surface-2/40 p-3">
                  <p className="text-[11px] uppercase tracking-wider text-faint">{s.label}</p>
                  <p className="mt-1 font-display text-lg font-semibold tabular-nums text-fg">{s.value}</p>
                  <p className={s.delta >= 0 ? 'text-[11px] font-medium text-success' : 'text-[11px] font-medium text-danger'}>
                    {formatPercent(s.delta)}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <p className="mb-2 text-[12px] text-muted">Advance/Decline Breadth (7d)</p>
              <AreaChart data={marketBreadth.map((b) => b * 100)} tone="accent" height={120} showAxis={false} />
            </div>
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Sector Allocation" subtitle="Current weights" />
          <CardBody>
            <DonutChart data={sectorAllocation.map((s) => ({ label: s.label, value: s.value, color: s.color as Tone }))} size={170} />
          </CardBody>
        </Card>
      </section>

      {/* Recent signals + strategy health */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Recent Signals" subtitle="AI-generated trade signals" action={<Button variant="ghost" size="sm" rightIcon={<ArrowUpRight className="h-3.5 w-3.5" />}>View all</Button>} />
          <CardBody className="space-y-2">
            {recentSignals.map((s) => (
              <div key={s.id} className="flex items-center justify-between gap-3 rounded-xl border border-border/50 bg-surface-2/30 p-3 transition hover:border-border/80 hover:bg-surface-2/60">
                <div className="flex min-w-0 items-center gap-3">
                  <span className={`grid h-9 w-9 place-items-center rounded-lg font-mono text-[12px] font-semibold ${s.side === 'Long' ? 'bg-success/12 text-success' : s.side === 'Short' ? 'bg-danger/12 text-danger' : 'bg-surface-2 text-muted'}`}>
                    {s.symbol.slice(0, 4)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-medium text-fg">{s.strategy}</p>
                    <p className="truncate text-[11px] text-muted">{s.side} {s.symbol} @ {formatCurrency(s.price, { compact: s.price > 1000 })} · {relativeTime(s.time)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="hidden text-right sm:block">
                    <p className="text-[10px] text-faint">Confidence</p>
                    <p className="text-[13px] font-semibold tabular-nums text-primary">{s.confidence}%</p>
                  </div>
                  <StatusBadge status={s.status} pulse={s.status === 'Executing'} />
                </div>
              </div>
            ))}
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Strategy Health" subtitle="Top performers" />
          <CardBody className="space-y-3">
            {strategies.filter((s) => s.status === 'Running' || s.status === 'Paper Trading').slice(0, 4).map((s) => (
              <div key={s.id} className="rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-medium text-fg">{s.name}</span>
                  <StatusBadge status={s.status} pulse={s.status === 'Running'} />
                </div>
                <div className="mt-2 flex items-center justify-between text-[12px]">
                  <span className={s.pnl >= 0 ? 'text-success' : 'text-danger'}>{formatCurrency(s.pnl, { compact: true })} ({formatPercent(s.pnlPct)})</span>
                  <span className="text-muted">Sharpe {s.sharpe}</span>
                </div>
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
                  <div className="h-full rounded-full bg-gradient-to-r from-primary to-accent" style={{ width: `${s.aiConfidence}%` }} />
                </div>
              </div>
            ))}
          </CardBody>
        </Card>
      </section>

      {/* Risk overview + capital allocation */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card hover>
          <CardHeader title="Risk Overview" subtitle="1-day VaR & drawdown" action={<Badge tone="success" dot>Within limits</Badge>} />
          <CardBody className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-3">
                <p className="text-[11px] uppercase text-faint">VaR (95%)</p>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums text-fg">{formatCurrency(riskOverview.var95)}</p>
                <p className="text-[11px] text-success">{formatPercent(riskOverview.varChange)}</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-3">
                <p className="text-[11px] uppercase text-faint">VaR (99%)</p>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums text-fg">{formatCurrency(riskOverview.var99)}</p>
                <p className="text-[11px] text-muted">1-day</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-3">
                <p className="text-[11px] uppercase text-faint">Max Drawdown</p>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums text-danger">{riskOverview.maxDrawdown}%</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-3">
                <p className="text-[11px] uppercase text-faint">Sharpe</p>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums text-success">{riskOverview.sharpe}</p>
              </div>
            </div>
            <div>
              <p className="mb-1 text-[12px] text-muted">Risk trend (lower is better)</p>
              <AreaChart data={riskTrend} tone="success" height={90} showAxis={false} />
            </div>
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Capital Allocation" subtitle="Deployed vs. reserve" />
          <CardBody>
            <DonutChart data={capitalAllocation.map((c) => ({ label: c.label, value: c.value, color: c.color as Tone }))} size={170} />
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-border/50 bg-surface-2/40 p-2 text-center">
                <p className="text-[10px] text-faint">Gross Lev.</p>
                <p className="text-[14px] font-semibold tabular-nums text-fg">{riskOverview.grossLeverage}x</p>
              </div>
              <div className="rounded-lg border border-border/50 bg-surface-2/40 p-2 text-center">
                <p className="text-[10px] text-faint">Net Lev.</p>
                <p className="text-[14px] font-semibold tabular-nums text-fg">{riskOverview.netLeverage}x</p>
              </div>
            </div>
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Risk Heatmap" subtitle="Exposure by asset class" />
          <CardBody>
            <Heatmap data={riskHeatmap} />
            <div className="mt-4">
              <div className="flex items-center justify-between text-[12px]">
                <span className="text-muted">Risk Budget Used</span>
                <span className="font-semibold text-fg">{riskOverview.riskBudgetUsed}%</span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
                <div className="h-full rounded-full bg-gradient-to-r from-success via-warning to-danger" style={{ width: `${riskOverview.riskBudgetUsed}%` }} />
              </div>
            </div>
          </CardBody>
        </Card>
      </section>

      {/* P&L contribution bar */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Daily P&L Contribution" subtitle="Last 7 days" action={<Badge tone="success" dot>+18.6K net</Badge>} />
          <CardBody>
            <BarChart data={pnlContribution.map((p) => p.value)} labels={pnlContribution.map((p) => p.label)} tone="primary" height={200} />
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="AI Confidence Trend" subtitle="Ensemble over 12 sessions" />
          <CardBody>
            <AreaChart data={aiConfidenceSeries} tone="secondary" height={200} showAxis />
            <div className="mt-3 flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/8 p-3">
              <Brain className="h-4 w-4 text-primary" />
              <p className="text-[12px] text-muted">Confidence up <span className="font-semibold text-primary">+16pts</span> since retrain</p>
            </div>
          </CardBody>
        </Card>
      </section>

      {/* Top holdings sparkline grid */}
      <section>
        <SectionHeading title="Top Holdings" subtitle="Live positions with intraday sparklines" action={<Button variant="ghost" size="sm">Manage portfolio</Button>} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {holdings.slice(0, 4).map((h) => {
            const spark = Array.from({ length: 12 }, (_, i) => h.last * (1 + (Math.sin(i) + h.changePct) * 0.004));
            return (
              <Card key={h.symbol} hover className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-mono text-[14px] font-semibold text-fg">{h.symbol}</p>
                    <p className="text-[11px] text-muted">{h.name}</p>
                  </div>
                  <Badge tone={h.changePct >= 0 ? 'success' : 'danger'}>{formatPercent(h.changePct)}</Badge>
                </div>
                <p className="mt-2 font-display text-xl font-semibold tabular-nums text-fg">{formatCurrency(h.last)}</p>
                <Sparkline data={spark} tone={h.changePct >= 0 ? 'success' : 'danger'} width={240} height={40} className="mt-2 w-full" />
                <p className="mt-1 text-[11px] text-faint">Weight {h.weight}% · {h.sector}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Quick actions */}
      <section>
        <SectionHeading title="Quick Actions" subtitle="Common workflows" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {quickActions.map((a) => {
            const Icon = quickActionIcons[a.icon] ?? Plus;
            return (
              <button key={a.id} className="group glass rounded-2xl border border-border/70 p-4 text-left transition hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-card-hover">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/30 transition group-hover:scale-110">
                  <Icon className="h-5 w-5" />
                </span>
                <p className="mt-3 text-[13px] font-semibold text-fg">{a.label}</p>
                <p className="text-[11px] text-muted">{a.hint}</p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Project timeline + recent activity + latest releases */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card hover>
          <CardHeader title="Project Timeline" subtitle="Roadmap progress" action={<GitBranch className="h-4 w-4 text-faint" />} />
          <CardBody>
            <Timeline items={projectTimeline} />
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Recent Activity" subtitle="System & trading events" action={<Activity className="h-4 w-4 text-faint" />} />
          <CardBody className="space-y-2.5">
            {recentActivity.slice(0, 6).map((a) => (
              <div key={a.id} className="flex gap-3">
                <span className="mt-1 h-2 w-2 shrink-0 rounded-full" style={{ background: toneRgb(kindTone(a.kind) as Tone) }} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium text-fg">{a.title}</p>
                  <p className="truncate text-[11px] text-muted">{a.detail} · {relativeTime(a.time)}</p>
                </div>
              </div>
            ))}
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Latest Releases" subtitle="Platform changelog" action={<Zap className="h-4 w-4 text-faint" />} />
          <CardBody className="space-y-3">
            {releases.slice(0, 4).map((r) => (
              <div key={r.version} className="rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[12px] font-semibold text-primary">{r.version}</span>
                  <Badge tone={r.tag === 'security' ? 'danger' : r.tag === 'fix' ? 'warning' : r.tag === 'improvement' ? 'info' : 'success'}>{r.tag}</Badge>
                </div>
                <p className="mt-1 text-[12px] font-medium text-fg">{r.name}</p>
                <p className="mt-0.5 text-[11px] text-muted">{r.notes}</p>
                <p className="mt-1 text-[10px] text-faint">{r.date}</p>
              </div>
            ))}
          </CardBody>
        </Card>
      </section>
    </div>
  );
}

function kindTone(kind: string): string {
  return { signal: 'primary', order: 'success', strategy: 'accent', risk: 'warning', system: 'info', document: 'secondary' }[kind] ?? 'faint';
}
