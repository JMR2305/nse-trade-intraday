import { FileText, Upload, Search, File, Notebook, BookOpen, ClipboardList, FileBarChart } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { documents } from '@/lib/demo-data';
import { relativeTime } from '@/lib/utils';
import type { DocItem } from '@/lib/demo-data';

const typeIcon: Record<DocItem['type'], React.ComponentType<{ className?: string }>> = {
  PDF: File,
  Research: BookOpen,
  Notebook: Notebook,
  Report: ClipboardList,
  Spec: FileBarChart,
};

const typeTone: Record<DocItem['type'], 'primary' | 'secondary' | 'accent' | 'info' | 'success'> = {
  PDF: 'danger' as never,
  Research: 'secondary',
  Notebook: 'accent',
  Report: 'info',
  Spec: 'success',
} as Record<DocItem['type'], 'primary' | 'secondary' | 'accent' | 'info' | 'success'>;

export function DocumentsPage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Documents · Knowledge base"
        title="Documents"
        description="Research, specifications, reports and notebooks — organized, searchable and versioned."
      >
        <Button variant="gradient" leftIcon={<Upload className="h-4 w-4" />}>Upload</Button>
        <Button variant="secondary" leftIcon={<FileText className="h-4 w-4" />}>New</Button>
      </PageHero>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {(['Research', 'Spec', 'Report', 'Notebook', 'PDF'] as DocItem['type'][]).map((t) => {
          const Icon = typeIcon[t];
          const count = documents.filter((d) => d.type === t).length;
          return (
            <Card key={t} hover className="p-5">
              <Icon className="h-5 w-5 text-primary" />
              <p className="mt-3 text-[12px] uppercase text-faint">{t}</p>
              <p className="font-display text-2xl font-semibold text-fg">{count}</p>
            </Card>
          );
        })}
      </section>

      <section>
        <SectionHeading
          title="All Documents"
          subtitle="Research, specs and reports"
          action={
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
              <input placeholder="Filter…" className="h-9 w-48 rounded-lg border border-border bg-surface-2 pl-9 pr-3 text-[13px] focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
          }
        />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {documents.map((d) => {
            const Icon = typeIcon[d.type];
            return (
              <Card key={d.id} hover className="p-5">
                <div className="flex items-start justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/30">
                    <Icon className="h-5 w-5" />
                  </span>
                  <Badge tone={typeTone[d.type]}>{d.type}</Badge>
                </div>
                <p className="mt-3 text-[14px] font-semibold leading-snug text-fg">{d.name}</p>
                <p className="mt-1 text-[11px] text-muted">by {d.author} · {d.size}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {d.tags.map((t) => (
                    <span key={t} className="rounded-full bg-surface-2 px-2 py-0.5 text-[10px] text-muted">#{t}</span>
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-between border-t border-border/50 pt-3">
                  <span className="text-[11px] text-faint">{relativeTime(d.updated)}</span>
                  <button className="text-[12px] font-medium text-primary hover:underline">Open</button>
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      <Card hover>
        <CardHeader title="Recently Updated" subtitle="Latest activity" />
        <CardBody className="space-y-2">
          {documents.slice(0, 4).map((d) => (
            <div key={d.id} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/30 p-3">
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary/12 text-primary">{(() => { const Icon = typeIcon[d.type]; return <Icon className="h-4 w-4" />; })()}</span>
                <div>
                  <p className="text-[13px] font-medium text-fg">{d.name}</p>
                  <p className="text-[11px] text-muted">{d.author} · {relativeTime(d.updated)}</p>
                </div>
              </div>
              <Badge tone={typeTone[d.type]}>{d.type}</Badge>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}
