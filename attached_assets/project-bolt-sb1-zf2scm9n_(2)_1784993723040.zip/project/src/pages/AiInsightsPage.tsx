import { Brain, Sparkles, TrendingUp, AlertTriangle, Lightbulb, Cpu } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressGauge } from '@/components/data-display/ProgressGauge';
import { AreaChart, BarChart, DonutChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { aiConfidenceSeries, aiSummary, recentSignals, sectorAllocation } from '@/lib/demo-data';
import { formatCurrency, relativeTime } from '@/lib/utils';
import type { Tone } from '@/lib/theme';

const modelBreakdown = [
  { label: 'Transformer', value: 42, color: 'primary' as Tone },
  { label: 'Gradient Boost', value: 31, color: 'secondary' as Tone },
  { label: 'Mean Reversion', value: 18, color: 'accent' as Tone },
  { label: 'Sentiment NLP', value: 9, color: 'info' as Tone },
];

const featureImportance = [88, 74, 61, 55, 48, 42, 33, 28, 22, 18];
const featureLabels = ['Momentum', 'Volume', 'Volatility', 'Breadth', 'Sentiment', 'Rates', 'Earnings', 'FX', 'Flows', 'Seasonal'];

export function AiInsightsPage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="AI Insights · Ensemble v4.2.1"
        title="Intelligence Layer"
        description="The OmniRoute ensemble fuses transformer forecasts, gradient-boosted signals and sentiment models into a single actionable view."
      >
        <Button variant="gradient" leftIcon={<Sparkles className="h-4 w-4" />}>Ask AI</Button>
        <Button variant="secondary" leftIcon={<Cpu className="h-4 w-4" />}>Retrain</Button>
      </PageHero>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        <Card hover className="p-5">
          <div className="flex items-center justify-between">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/30"><Brain className="h-5 w-5" /></span>
            <Badge tone="success" dot pulse>Live</Badge>
          </div>
          <p className="mt-3 text-[12px] uppercase tracking-wider text-faint">Ensemble Confidence</p>
          <p className="font-display text-2xl font-semibold tabular-nums text-fg">{aiSummary.confidence}%</p>
          <p className="text-[11px] text-success">+16pts since retrain</p>
        </Card>
        <Card hover className="p-5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-success/12 text-success ring-1 ring-success/30"><TrendingUp className="h-5 w-5" /></span>
          <p className="mt-3 text-[12px] uppercase tracking-wider text-faint">Market Regime</p>
          <p className="font-display text-2xl font-semibold text-fg">{aiSummary.marketRegime}</p>
          <p className="text-[11px] text-muted">Volatility compressing</p>
        </Card>
        <Card hover className="p-5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-warning/12 text-warning ring-1 ring-warning/30"><AlertTriangle className="h-5 w-5" /></span>
          <p className="mt-3 text-[12px] uppercase tracking-wider text-faint">Active Alerts</p>
          <p className="font-display text-2xl font-semibold tabular-nums text-fg">3</p>
          <p className="text-[11px] text-muted">2 concentration · 1 VaR</p>
        </Card>
        <Card hover className="p-5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-secondary/15 text-secondary ring-1 ring-secondary/40"><Lightbulb className="h-5 w-5" /></span>
          <p className="mt-3 text-[12px] uppercase tracking-wider text-faint">Recommendations</p>
          <p className="font-display text-2xl font-semibold tabular-nums text-fg">{aiSummary.recommendations.length}</p>
          <p className="text-[11px] text-muted">Awaiting review</p>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="AI Narrative" subtitle="Ensemble-generated market read" />
          <CardBody>
            <p className="rounded-2xl border border-border/60 bg-surface-2/40 p-4 text-[14px] leading-relaxed text-muted">
              {aiSummary.narrative}
            </p>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
              {aiSummary.recommendations.map((r) => (
                <div key={r.id} className="rounded-xl border border-border/60 bg-surface-2/30 p-4">
                  <div className="flex items-start gap-2">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-primary/12 text-primary"><Lightbulb className="h-4 w-4" /></span>
                    <p className="text-[13px] font-medium text-fg">{r.title}</p>
                  </div>
                  <p className="mt-2 text-[12px] text-muted">{r.rationale}</p>
                  <p className="mt-2 text-[11px] font-medium text-success">{r.impact}</p>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card hover gradientBorder>
          <CardHeader title="Confidence Gauge" subtitle="Ensemble agreement" />
          <CardBody className="flex flex-col items-center gap-4">
            <ProgressGauge value={aiSummary.confidence} tone="primary" size={160} thickness={14} label="Model consensus" />
            <div className="w-full space-y-2">
              <div className="flex justify-between text-[12px]"><span className="text-muted">Sentiment</span><span className="font-semibold text-fg">{aiSummary.sentiment}/100</span></div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
                <div className="h-full rounded-full bg-gradient-to-r from-danger via-warning to-success" style={{ width: `${aiSummary.sentiment}%` }} />
              </div>
            </div>
          </CardBody>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Confidence Trend" subtitle="Last 12 sessions" />
          <CardBody><AreaChart data={aiConfidenceSeries} tone="secondary" height={220} labels={['W1','W2','W3','W4','Now']} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Model Mix" subtitle="Weight by architecture" />
          <CardBody><DonutChart data={modelBreakdown} size={170} /></CardBody>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card hover>
          <CardHeader title="Feature Importance" subtitle="Top signal drivers" />
          <CardBody><BarChart data={featureImportance} labels={featureLabels} tone="primary" height={220} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Recent AI Signals" subtitle="Generated this session" />
          <CardBody className="space-y-2">
            {recentSignals.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <div>
                  <p className="text-[13px] font-medium text-fg">{s.side} {s.symbol}</p>
                  <p className="text-[11px] text-muted">{s.strategy} · {relativeTime(s.time)}</p>
                </div>
                <div className="text-right">
                  <p className="text-[13px] font-semibold text-primary">{s.confidence}%</p>
                  <p className="text-[11px] text-muted">{formatCurrency(s.price, { compact: s.price > 1000 })}</p>
                </div>
              </div>
            ))}
          </CardBody>
        </Card>
      </section>

      <Card hover>
        <CardHeader title="Sector Bias" subtitle="Where the ensemble sees edge" />
        <CardBody>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
            {sectorAllocation.map((s) => (
              <div key={s.label} className="rounded-xl border border-border/60 bg-surface-2/30 p-3 text-center">
                <p className="text-[11px] text-muted">{s.label}</p>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums text-fg">{s.value}%</p>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
