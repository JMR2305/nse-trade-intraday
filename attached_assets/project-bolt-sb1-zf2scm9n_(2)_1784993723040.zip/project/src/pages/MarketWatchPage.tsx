import { LineChart, Plus, Eye, Activity } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { AreaChart, Sparkline } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { marketBreadth, marketStatus, watchList } from '@/lib/demo-data';
import { formatCurrency, formatPercent } from '@/lib/utils';

export function MarketWatchPage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Market Watch · Cross-asset"
        title="Market Monitor"
        description="Live watchlist, cross-asset regime and market breadth across equities and digital assets."
      >
        <Button variant="gradient" leftIcon={<Plus className="h-4 w-4" />}>Add Ticker</Button>
        <Button variant="secondary" leftIcon={<Eye className="h-4 w-4" />}>Layouts</Button>
      </PageHero>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'VIX', value: marketStatus.vix.toFixed(2), delta: marketStatus.vixChange, tone: 'info' },
          { label: 'Breadth', value: `${(marketStatus.breadth * 100).toFixed(0)}%`, delta: marketStatus.breadthChange, tone: 'success' },
          { label: '10Y', value: `${marketStatus.tenYear.toFixed(2)}%`, delta: marketStatus.tenYearChange, tone: 'warning' },
          { label: 'DXY', value: marketStatus.dollar.toFixed(2), delta: marketStatus.dollarChange, tone: 'accent' },
        ].map((s) => (
          <Card key={s.label} hover className="p-5">
            <div className="flex items-center justify-between">
              <p className="text-[12px] uppercase tracking-wider text-faint">{s.label}</p>
              <Activity className="h-4 w-4 text-faint" />
            </div>
            <p className="mt-2 font-display text-2xl font-semibold tabular-nums text-fg">{s.value}</p>
            <p className={s.delta >= 0 ? 'text-[12px] font-medium text-success' : 'text-[12px] font-medium text-danger'}>{formatPercent(s.delta)}</p>
          </Card>
        ))}
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Market Breadth" subtitle="Advance/decline ratio (7d)" action={<Badge tone="success" dot>Risk-On</Badge>} />
          <CardBody><AreaChart data={marketBreadth.map((b) => b * 100)} tone="accent" height={220} labels={['Mon','Tue','Wed','Thu','Fri','Sat','Sun']} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Regime Indicator" subtitle="Current state" />
          <CardBody>
            <div className="flex flex-col items-center gap-3 py-4">
              <span className="grid h-16 w-16 place-items-center rounded-2xl bg-success/12 text-success ring-1 ring-success/30">
                <LineChart className="h-8 w-8" />
              </span>
              <p className="font-display text-xl font-semibold text-success">{marketStatus.regime}</p>
              <p className="text-[12px] text-muted">Volatility compressing, breadth expanding</p>
            </div>
          </CardBody>
        </Card>
      </section>

      <section>
        <SectionHeading title="Watchlist" subtitle="Live quotes with sparklines" action={<Button variant="ghost" size="sm">Manage</Button>} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {watchList.map((w) => (
            <Card key={w.symbol} hover className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-mono text-[14px] font-semibold text-fg">{w.symbol}</p>
                  <p className="text-[11px] text-muted">{w.name}</p>
                </div>
                <Badge tone={w.changePct >= 0 ? 'success' : 'danger'}>{formatPercent(w.changePct)}</Badge>
              </div>
              <p className="mt-2 font-display text-xl font-semibold tabular-nums text-fg">{formatCurrency(w.last, { compact: w.last > 1000, decimals: w.last > 1000 ? 1 : 2 })}</p>
              <Sparkline data={w.spark} tone={w.changePct >= 0 ? 'success' : 'danger'} width={240} height={40} className="mt-2 w-full" />
              <div className="mt-2 flex items-center justify-between text-[11px] text-faint">
                <span>Vol {w.volume}</span>
                <button className="text-primary hover:underline">Trade</button>
              </div>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
