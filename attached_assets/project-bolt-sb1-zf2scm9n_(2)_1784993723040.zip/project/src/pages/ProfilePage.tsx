import { KeyRound, Shield, Users, Mail, Building2, Pencil } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressGauge } from '@/components/data-display/ProgressGauge';
import { AreaChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { portfolioGrowth } from '@/lib/demo-data';
import { formatPercent } from '@/lib/utils';

const team = [
  { name: 'Ava Rivera', role: 'Portfolio Manager', initials: 'AR', tone: 'primary' as const },
  { name: 'Ravi Chen', role: 'Quant Research', initials: 'RC', tone: 'secondary' as const },
  { name: 'Lena Park', role: 'Strategy Engineer', initials: 'LP', tone: 'accent' as const },
  { name: 'Javier Ortiz', role: 'Execution', initials: 'JO', tone: 'info' as const },
];

const apiKeys = [
  { name: 'Production · Read', scope: 'read-only', created: '2026-06-12', lastUsed: '2m ago' },
  { name: 'Production · Trade', scope: 'trade', created: '2026-06-12', lastUsed: '14m ago' },
  { name: 'Sandbox · Dev', scope: 'read-only', created: '2026-07-01', lastUsed: '3d ago' },
];

export function ProfilePage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Profile · Account"
        title="Ava Rivera"
        description="Portfolio Manager at Meridian Capital. Manage your identity, team access and API credentials."
      >
        <Button variant="gradient" leftIcon={<Pencil className="h-4 w-4" />}>Edit Profile</Button>
      </PageHero>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card hover className="lg:col-span-1" gradientBorder>
          <CardBody className="flex flex-col items-center gap-4 py-6">
            <span className="grid h-20 w-20 place-items-center rounded-2xl bg-primary font-display text-2xl font-semibold text-primary-fg shadow-card">AR</span>
            <div className="text-center">
              <p className="font-display text-lg font-semibold text-fg">Ava Rivera</p>
              <p className="text-[13px] text-muted">Portfolio Manager</p>
            </div>
            <div className="flex gap-2">
              <Badge tone="primary" dot>Pro</Badge>
              <Badge tone="success" dot pulse>Online</Badge>
            </div>
            <div className="w-full space-y-2 border-t border-border/50 pt-4">
              {[
                { icon: Mail, label: 'ava@meridian.cap' },
                { icon: Building2, label: 'Meridian Capital' },
                { icon: Shield, label: '2FA enabled' },
              ].map((r) => (
                <div key={r.label} className="flex items-center gap-2 text-[13px] text-muted">
                  <r.icon className="h-4 w-4 text-faint" /> {r.label}
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card hover>
            <CardHeader title="Performance" subtitle="Your attributed P&L" action={<Badge tone="success" dot>+14.3% MTD</Badge>} />
            <CardBody><AreaChart data={portfolioGrowth} tone="primary" height={200} labels={['Jun','Jul 1','Jul 8','Jul 15','Today']} /></CardBody>
          </Card>
          <Card hover>
            <CardHeader title="Completion" subtitle="Profile strength" />
            <CardBody className="flex items-center gap-6">
              <ProgressGauge value={88} tone="success" size={130} label="Profile strength" />
              <div className="flex-1 space-y-2">
                {['Identity verified', '2FA enabled', 'API keys configured', 'Team invited', 'Risk limits set'].map((c, i) => (
                  <div key={c} className="flex items-center justify-between text-[13px]">
                    <span className="text-muted">{c}</span>
                    <Badge tone={i < 4 ? 'success' : 'warning'} dot>{i < 4 ? 'Done' : 'Pending'}</Badge>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      </section>

      <section>
        <SectionHeading title="Team" subtitle="Workspace members" action={<Button variant="secondary" size="sm" leftIcon={<Users className="h-4 w-4" />}>Invite</Button>} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {team.map((m) => (
            <Card key={m.name} hover className="p-5">
              <div className="flex items-center gap-3">
                <span className={`grid h-11 w-11 place-items-center rounded-xl font-display text-[14px] font-semibold text-primary-fg bg-${m.tone}`}>{m.initials}</span>
                <div>
                  <p className="text-[13px] font-semibold text-fg">{m.name}</p>
                  <p className="text-[11px] text-muted">{m.role}</p>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <Badge tone={m.tone} dot>{m.role.includes('Manager') ? 'Admin' : 'Member'}</Badge>
                <span className="text-[11px] text-faint">Active</span>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading title="API Credentials" subtitle="Keys and scopes" action={<Button variant="secondary" size="sm" leftIcon={<KeyRound className="h-4 w-4" />}>New Key</Button>} />
        <div className="card-surface overflow-hidden">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border/70 bg-surface-2/40 text-[11px] uppercase tracking-wider text-faint">
                <th className="px-4 py-3 text-left">Name</th>
                <th className="px-4 py-3 text-left">Scope</th>
                <th className="px-4 py-3 text-left">Created</th>
                <th className="px-4 py-3 text-left">Last used</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {apiKeys.map((k) => (
                <tr key={k.name} className="border-b border-border/40 hover:bg-surface-2/30">
                  <td className="px-4 py-3 font-medium text-fg">{k.name}</td>
                  <td className="px-4 py-3"><Badge tone={k.scope === 'trade' ? 'warning' : 'info'}>{k.scope}</Badge></td>
                  <td className="px-4 py-3 text-muted">{k.created}</td>
                  <td className="px-4 py-3 text-muted">{k.lastUsed}</td>
                  <td className="px-4 py-3 text-right"><button className="text-primary hover:underline">Rotate</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <Card hover>
        <CardHeader title="Attribution" subtitle="Risk-adjusted contribution" />
        <CardBody>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { label: 'Alpha', value: formatPercent(4.2) },
              { label: 'Beta', value: '1.12' },
              { label: 'Sharpe', value: '1.84' },
              { label: 'Hit Rate', value: '63%' },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-border/60 bg-surface-2/40 p-4 text-center">
                <p className="text-[11px] uppercase text-faint">{s.label}</p>
                <p className="mt-1 font-display text-xl font-semibold tabular-nums text-fg">{s.value}</p>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
