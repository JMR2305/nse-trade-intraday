import { ShieldAlert, ShieldCheck, AlertTriangle, TrendingDown } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProgressGauge } from '@/components/data-display/ProgressGauge';
import { AreaChart, Heatmap, BarChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { riskHeatmap, riskOverview, riskTrend } from '@/lib/demo-data';
import { formatCurrency, formatPercent } from '@/lib/utils';

export function RiskCenterPage() {
  const limits = [
    { label: 'Max Gross Leverage', value: riskOverview.grossLeverage, limit: 2.0, tone: 'success' as const },
    { label: 'Max Net Leverage', value: riskOverview.netLeverage, limit: 1.5, tone: 'success' as const },
    { label: 'VaR (99%)', value: riskOverview.var99 / 1000, limit: 100, tone: 'success' as const },
    { label: 'Concentration (HHI)', value: riskOverview.concentrationHHI, limit: 0.25, tone: 'warning' as const },
  ];

  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Risk Center · Real-time"
        title="Risk Management"
        description="Value at risk, exposures, limits and drawdown monitoring across the full portfolio."
      >
        <Button variant="gradient" leftIcon={<ShieldCheck className="h-4 w-4" />}>Run Stress Test</Button>
        <Button variant="secondary" leftIcon={<AlertTriangle className="h-4 w-4" />}>Limits</Button>
      </PageHero>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card hover className="p-5"><ShieldAlert className="h-5 w-5 text-danger" /><p className="mt-3 text-[12px] uppercase text-faint">VaR (99%)</p><p className="font-display text-2xl font-semibold text-fg">{formatCurrency(riskOverview.var99)}</p><p className="text-[11px] text-success">{formatPercent(riskOverview.varChange)}</p></Card>
        <Card hover className="p-5"><TrendingDown className="h-5 w-5 text-warning" /><p className="mt-3 text-[12px] uppercase text-faint">Max Drawdown</p><p className="font-display text-2xl font-semibold text-danger">{riskOverview.maxDrawdown}%</p><p className="text-[11px] text-muted">90d</p></Card>
        <Card hover className="p-5"><ShieldCheck className="h-5 w-5 text-success" /><p className="mt-3 text-[12px] uppercase text-faint">Sharpe</p><p className="font-display text-2xl font-semibold text-success">{riskOverview.sharpe}</p><p className="text-[11px] text-muted">Sortino {riskOverview.sortino}</p></Card>
        <Card hover className="p-5"><ShieldAlert className="h-5 w-5 text-info" /><p className="mt-3 text-[12px] uppercase text-faint">Gross Leverage</p><p className="font-display text-2xl font-semibold text-fg">{riskOverview.grossLeverage}x</p><p className="text-[11px] text-muted">Net {riskOverview.netLeverage}x</p></Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Risk Trend" subtitle="1-day 99% VaR over time (lower is better)" action={<Badge tone="success" dot>Improving</Badge>} />
          <CardBody><AreaChart data={riskTrend} tone="success" height={240} labels={['W1','W2','W3','W4','Now']} /></CardBody>
        </Card>
        <Card hover gradientBorder>
          <CardHeader title="Risk Budget" subtitle="Utilization" />
          <CardBody className="flex flex-col items-center gap-4">
            <ProgressGauge value={riskOverview.riskBudgetUsed} tone="warning" size={150} label="Budget used" />
            <p className="text-[12px] text-muted">36% headroom remaining</p>
          </CardBody>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card hover>
          <CardHeader title="Exposure Heatmap" subtitle="By asset class" />
          <CardBody><Heatmap data={riskHeatmap} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Risk Limits" subtitle="Current vs. cap" />
          <CardBody className="space-y-4">
            {limits.map((l) => {
              const pct = (l.value / l.limit) * 100;
              return (
                <div key={l.label}>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="text-muted">{l.label}</span>
                    <span className="font-semibold tabular-nums text-fg">{l.value.toFixed(2)} / {l.limit.toFixed(2)}</span>
                  </div>
                  <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
                    <div className={pct > 80 ? 'h-full rounded-full bg-danger' : pct > 60 ? 'h-full rounded-full bg-warning' : 'h-full rounded-full bg-success'} style={{ width: `${Math.min(100, pct)}%` }} />
                  </div>
                </div>
              );
            })}
          </CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Correlation & Beta" subtitle="To benchmark" />
          <CardBody>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-4 text-center"><p className="text-[11px] uppercase text-faint">Beta</p><p className="mt-1 font-display text-2xl font-semibold tabular-nums text-fg">{riskOverview.beta}</p></div>
              <div className="rounded-xl border border-border/60 bg-surface-2/40 p-4 text-center"><p className="text-[11px] uppercase text-faint">Correlation</p><p className="mt-1 font-display text-2xl font-semibold tabular-nums text-fg">{riskOverview.correlation}</p></div>
              <div className="col-span-2 rounded-xl border border-border/60 bg-surface-2/40 p-4 text-center"><p className="text-[11px] uppercase text-faint">Sortino Ratio</p><p className="mt-1 font-display text-2xl font-semibold tabular-nums text-success">{riskOverview.sortino}</p></div>
            </div>
          </CardBody>
        </Card>
      </section>

      <section>
        <SectionHeading title="Stress Scenarios" subtitle="Hypothetical portfolio impact" />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { name: '2008 GFC repeat', impact: -18.4, tone: 'danger' as const },
            { name: '2020 COVID crash', impact: -12.8, tone: 'danger' as const },
            { name: 'Rates +200bps', impact: -6.2, tone: 'warning' as const },
            { name: 'Oil shock +40%', impact: -3.1, tone: 'warning' as const },
          ].map((s) => (
            <Card key={s.name} hover className="p-5">
              <ShieldAlert className={`h-5 w-5 ${s.tone === 'danger' ? 'text-danger' : 'text-warning'}`} />
              <p className="mt-3 text-[12px] uppercase text-faint">{s.name}</p>
              <p className={`font-display text-2xl font-semibold tabular-nums ${s.tone === 'danger' ? 'text-danger' : 'text-warning'}`}>{formatPercent(s.impact)}</p>
              <p className="text-[11px] text-muted">Projected NAV impact</p>
            </Card>
          ))}
        </div>
      </section>

      <Card hover>
        <CardHeader title="VaR by Asset Class" subtitle="Marginal contribution" />
        <CardBody><BarChart data={riskHeatmap.map((r) => r[1])} labels={riskHeatmap.map((r) => r[0])} tone="warning" height={180} /></CardBody>
      </Card>
    </div>
  );
}
