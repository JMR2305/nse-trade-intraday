import { Plus, Download, ShoppingCart } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge, StatusBadge } from '@/components/ui/Badge';
import { DataTable, type Column } from '@/components/data-display/DataTable';
import { BarChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { orders } from '@/lib/demo-data';
import { formatCurrency, relativeTime } from '@/lib/utils';
import type { Order } from '@/lib/demo-data';

const columns: Column<Order>[] = [
  { key: 'id', header: 'Order ID', sortable: true, render: (r) => <span className="font-mono text-[12px] text-primary">{r.id}</span> },
  { key: 'symbol', header: 'Symbol', sortable: true, render: (r) => <span className="font-mono font-semibold">{r.symbol}</span> },
  { key: 'side', header: 'Side', render: (r) => <Badge tone={r.side === 'Buy' ? 'success' : 'danger'}>{r.side}</Badge> },
  { key: 'type', header: 'Type', sortable: true, render: (r) => <span className="text-muted">{r.type}</span> },
  { key: 'qty', header: 'Qty', align: 'right', sortable: true, render: (r) => r.qty.toLocaleString() },
  { key: 'price', header: 'Price', align: 'right', sortable: true, render: (r) => formatCurrency(r.price, { compact: r.price > 1000 }) },
  {
    key: 'filled',
    header: 'Filled',
    align: 'right',
    render: (r) => (
      <div className="flex items-center justify-end gap-2">
        <div className="h-1.5 w-14 overflow-hidden rounded-full bg-surface-2">
          <div className="h-full rounded-full bg-primary" style={{ width: `${(r.filled / r.qty) * 100}%` }} />
        </div>
        <span className="tabular-nums">{r.filled}/{r.qty}</span>
      </div>
    ),
  },
  { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} pulse={r.status === 'Working'} /> },
  { key: 'time', header: 'Time', align: 'right', render: (r) => <span className="text-faint">{relativeTime(r.time)}</span> },
];

export function OrdersPage() {
  const working = orders.filter((o) => o.status === 'Working').length;
  const filled = orders.filter((o) => o.status === 'Filled').length;
  const partial = orders.filter((o) => o.status === 'Partial').length;

  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Orders · Live blotter"
        title="Order Management"
        description="Live order blotter with execution status, fill progress and routing analytics."
      >
        <Button variant="gradient" leftIcon={<Plus className="h-4 w-4" />}>New Order</Button>
        <Button variant="secondary" leftIcon={<Download className="h-4 w-4" />}>Export</Button>
      </PageHero>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card hover className="p-5"><ShoppingCart className="h-5 w-5 text-primary" /><p className="mt-3 text-[12px] uppercase text-faint">Working</p><p className="font-display text-2xl font-semibold text-primary">{working}</p></Card>
        <Card hover className="p-5"><ShoppingCart className="h-5 w-5 text-success" /><p className="mt-3 text-[12px] uppercase text-faint">Filled Today</p><p className="font-display text-2xl font-semibold text-success">{filled}</p></Card>
        <Card hover className="p-5"><ShoppingCart className="h-5 w-5 text-warning" /><p className="mt-3 text-[12px] uppercase text-faint">Partial</p><p className="font-display text-2xl font-semibold text-warning">{partial}</p></Card>
        <Card hover className="p-5"><ShoppingCart className="h-5 w-5 text-faint" /><p className="mt-3 text-[12px] uppercase text-faint">Total</p><p className="font-display text-2xl font-semibold text-fg">{orders.length}</p></Card>
      </section>

      <section>
        <SectionHeading title="Order Blotter" subtitle="All orders this session" />
        <DataTable columns={columns} rows={orders} searchKeys={['id', 'symbol', 'side', 'type', 'status']} />
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card hover>
          <CardHeader title="Fill Distribution" subtitle="By status" />
          <CardBody>
            <BarChart
              data={[
                orders.filter((o) => o.status === 'Filled').length,
                orders.filter((o) => o.status === 'Working').length,
                orders.filter((o) => o.status === 'Partial').length,
                orders.filter((o) => o.status === 'Cancelled').length,
                orders.filter((o) => o.status === 'Rejected').length,
              ]}
              labels={['Filled', 'Working', 'Partial', 'Cancelled', 'Rejected']}
              tone="primary"
              height={180}
            />
          </CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Order Type Mix" subtitle="Execution style" />
          <CardBody>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {['Market', 'Limit', 'Stop', 'Iceberg'].map((t) => {
                const count = orders.filter((o) => o.type === t).length;
                return (
                  <div key={t} className="rounded-xl border border-border/60 bg-surface-2/30 p-4 text-center">
                    <p className="font-display text-2xl font-semibold tabular-nums text-fg">{count}</p>
                    <p className="text-[12px] text-muted">{t}</p>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      </section>
    </div>
  );
}
