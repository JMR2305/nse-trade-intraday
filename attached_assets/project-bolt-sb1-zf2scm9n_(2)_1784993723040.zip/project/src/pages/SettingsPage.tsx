import { useState } from 'react';
import { Save, Bell, KeyRound, Plug, Sliders, Monitor } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { cn } from '@/lib/utils';

function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      className={cn('relative h-6 w-11 rounded-full transition', on ? 'bg-primary' : 'bg-surface-2 border border-border')}
    >
      <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all', on ? 'left-[22px]' : 'left-0.5')} />
    </button>
  );
}

export function SettingsPage() {
  const [notif, setNotif] = useState({ signals: true, fills: true, risk: true, news: false, weekly: true });
  const [prefs, setPrefs] = useState({ reducedMotion: false, compact: false, confirmOrders: true });
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Settings · Workspace"
        title="Settings"
        description="Workspace preferences, connectivity, notifications and security for your OmniRoute environment."
      >
        <Button variant="gradient" leftIcon={<Save className="h-4 w-4" />}>Save Changes</Button>
      </PageHero>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card hover className="lg:col-span-1">
          <CardHeader title="Appearance" subtitle="Theme & density" />
          <CardBody className="space-y-4">
            <div>
              <p className="mb-2 text-[12px] text-muted">Theme</p>
              <div className="grid grid-cols-2 gap-2">
                {(['dark', 'light'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className={cn('flex items-center gap-2 rounded-xl border p-3 text-[13px] capitalize transition', theme === t ? 'border-primary bg-primary/10 text-primary ring-1 ring-primary/30' : 'border-border text-muted hover:bg-surface-2')}
                  >
                    <Monitor className="h-4 w-4" /> {t}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              {[
                { key: 'compact', label: 'Compact density', desc: 'Tighter spacing' },
                { key: 'reducedMotion', label: 'Reduced motion', desc: 'Minimize animations' },
                { key: 'confirmOrders', label: 'Confirm orders', desc: 'Require approval' },
              ].map((p) => (
                <div key={p.key} className="flex items-center justify-between">
                  <div>
                    <p className="text-[13px] font-medium text-fg">{p.label}</p>
                    <p className="text-[11px] text-muted">{p.desc}</p>
                  </div>
                  <Toggle on={prefs[p.key as keyof typeof prefs]} onChange={() => setPrefs((s) => ({ ...s, [p.key]: !s[p.key as keyof typeof prefs] }))} />
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card hover className="lg:col-span-2">
          <CardHeader title="Notifications" subtitle="What we alert you about" action={<Bell className="h-4 w-4 text-faint" />} />
          <CardBody className="space-y-3">
            {[
              { key: 'signals', label: 'AI signals', desc: 'New trade signals from the ensemble' },
              { key: 'fills', label: 'Order fills', desc: 'Execution confirmations' },
              { key: 'risk', label: 'Risk breaches', desc: 'VaR and limit warnings' },
              { key: 'news', label: 'Market news', desc: 'Breaking headlines' },
              { key: 'weekly', label: 'Weekly digest', desc: 'Performance summary email' },
            ].map((n) => (
              <div key={n.key} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <div>
                  <p className="text-[13px] font-medium text-fg">{n.label}</p>
                  <p className="text-[11px] text-muted">{n.desc}</p>
                </div>
                <Toggle on={notif[n.key as keyof typeof notif]} onChange={() => setNotif((s) => ({ ...s, [n.key]: !s[n.key as keyof typeof notif] }))} />
              </div>
            ))}
          </CardBody>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card hover>
          <CardHeader title="Connectivity" subtitle="Broker & data feeds" action={<Plug className="h-4 w-4 text-faint" />} />
          <CardBody className="space-y-3">
            {[
              { name: 'Interactive Brokers', status: 'Connected', tone: 'success' as const },
              { name: 'Alpaca Markets', status: 'Connected', tone: 'success' as const },
              { name: 'Bloomberg Data License', status: 'Connected', tone: 'success' as const },
              { name: 'Polygon.io', status: 'Degraded', tone: 'warning' as const },
              { name: 'Coinbase Prime', status: 'Disconnected', tone: 'danger' as const },
            ].map((c) => (
              <div key={c.name} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <div className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-surface-2 text-muted"><Plug className="h-4 w-4" /></span>
                  <span className="text-[13px] font-medium text-fg">{c.name}</span>
                </div>
                <Badge tone={c.tone} dot pulse={c.tone === 'warning'}>{c.status}</Badge>
              </div>
            ))}
          </CardBody>
        </Card>

        <Card hover>
          <CardHeader title="Security" subtitle="API & access" action={<KeyRound className="h-4 w-4 text-faint" />} />
          <CardBody className="space-y-3">
            {[
              { label: 'Two-factor auth', value: 'Enabled', tone: 'success' as const },
              { label: 'API key rotation', value: '90 days', tone: 'info' as const },
              { label: 'IP allowlist', value: '3 addresses', tone: 'info' as const },
              { label: 'Audit log', value: 'Streaming', tone: 'success' as const },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/30 p-3">
                <span className="text-[13px] font-medium text-fg">{s.label}</span>
                <Badge tone={s.tone} dot>{s.value}</Badge>
              </div>
            ))}
            <Button variant="secondary" className="w-full" leftIcon={<KeyRound className="h-4 w-4" />}>Rotate API Keys</Button>
          </CardBody>
        </Card>
      </section>

      <Card hover>
        <CardHeader title="Execution Preferences" subtitle="Routing & slippage" action={<Sliders className="h-4 w-4 text-faint" />} />
        <CardBody>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="text-[12px] text-muted">Default venue</label>
              <select className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 text-[13px] text-fg focus:border-primary focus:outline-none">
                <option>Smart routing</option><option>NSDQ</option><option>NYSE</option><option>Dark pool</option>
              </select>
            </div>
            <div>
              <label className="text-[12px] text-muted">Max slippage (bps)</label>
              <input defaultValue="5" className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 text-[13px] text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <div>
              <label className="text-[12px] text-muted">Iceberg display qty</label>
              <input defaultValue="10%" className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 text-[13px] text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
