import { useState } from 'react';
import { Send, Zap, Layers } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge, StatusBadge } from '@/components/ui/Badge';
import { AreaChart, BarChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { holdings, orders, portfolioGrowth } from '@/lib/demo-data';
import { formatCurrency, formatPercent } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function TradingPage() {
  const [side, setSide] = useState<'Buy' | 'Sell'>('Buy');
  const [orderType, setOrderType] = useState('Limit');
  const [symbol, setSymbol] = useState('NVDA');

  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Trading · Order ticket"
        title="Execution Desk"
        description="Route orders across venues with smart execution, iceberg support and pre-trade risk checks."
      >
        <Button variant="gradient" leftIcon={<Zap className="h-4 w-4" />}>Quick Trade</Button>
        <Button variant="secondary" leftIcon={<Layers className="h-4 w-4" />}>Venues</Button>
      </PageHero>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Order ticket */}
        <Card hover className="lg:col-span-1" gradientBorder>
          <CardHeader title="Order Ticket" subtitle="Single-leg entry" />
          <CardBody className="space-y-4">
            <div>
              <label className="text-[12px] text-muted">Symbol</label>
              <input
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 font-mono text-[14px] font-semibold text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSide('Buy')}
                className={cn('h-10 rounded-xl text-[14px] font-semibold transition', side === 'Buy' ? 'bg-success text-white shadow-card' : 'border border-border text-muted hover:bg-surface-2')}
              >Buy</button>
              <button
                onClick={() => setSide('Sell')}
                className={cn('h-10 rounded-xl text-[14px] font-semibold transition', side === 'Sell' ? 'bg-danger text-white shadow-card' : 'border border-border text-muted hover:bg-surface-2')}
              >Sell</button>
            </div>
            <div>
              <label className="text-[12px] text-muted">Order Type</label>
              <div className="mt-1 grid grid-cols-4 gap-1">
                {['Market', 'Limit', 'Stop', 'Iceberg'].map((t) => (
                  <button
                    key={t}
                    onClick={() => setOrderType(t)}
                    className={cn('h-9 rounded-lg text-[12px] font-medium transition', orderType === t ? 'bg-primary/10 text-primary ring-1 ring-primary/25' : 'border border-border text-muted hover:bg-surface-2')}
                  >{t}</button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[12px] text-muted">Quantity</label>
                <input defaultValue="100" className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 text-[14px] text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
              <div>
                <label className="text-[12px] text-muted">Limit Price</label>
                <input defaultValue="624.30" className="mt-1 h-10 w-full rounded-xl border border-border bg-surface-2 px-3 text-[14px] text-fg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
              </div>
            </div>
            <div className="rounded-xl border border-border/60 bg-surface-2 p-3 text-[12px]">
              <div className="flex justify-between"><span className="text-muted">Est. Notional</span><span className="font-semibold tabular-nums text-fg">$62,430</span></div>
              <div className="mt-1 flex justify-between"><span className="text-muted">Commission</span><span className="tabular-nums text-fg">$2.40</span></div>
              <div className="mt-1 flex justify-between"><span className="text-muted">Risk check</span><span className="font-medium text-success">Pass</span></div>
            </div>
            <Button variant={side === 'Buy' ? 'gradient' : 'danger'} className="w-full" size="lg" leftIcon={<Send className="h-4 w-4" />}>
              Submit {side} {orderType}
            </Button>
          </CardBody>
        </Card>

        {/* Chart + positions */}
        <div className="space-y-6 lg:col-span-2">
          <Card hover>
            <CardHeader title={`${symbol} · 624.30`} subtitle="Intraday price action" action={<Badge tone="success" dot>+1.92%</Badge>} />
            <CardBody><AreaChart data={portfolioGrowth.slice(-12)} tone="primary" height={240} labels={['9:30','10:30','11:30','12:30','13:30','14:30','15:30']} /></CardBody>
          </Card>

          <Card hover>
            <CardHeader title="Open Positions" subtitle="Live exposure" />
            <CardBody className="space-y-2">
              {holdings.slice(0, 5).map((h) => (
                <div key={h.symbol} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/60 p-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary/12 font-mono text-[12px] font-semibold text-primary">{h.symbol.slice(0, 3)}</span>
                    <div>
                      <p className="text-[13px] font-medium text-fg">{h.symbol}</p>
                      <p className="text-[11px] text-muted">{h.shares} sh · {formatCurrency(h.avgCost)} avg</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-semibold tabular-nums text-fg">{formatCurrency(h.last)}</p>
                    <p className={h.changePct >= 0 ? 'text-[11px] text-success' : 'text-[11px] text-danger'}>{formatPercent(h.changePct)}</p>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card hover>
          <CardHeader title="Recent Executions" subtitle="Latest fills" />
          <CardBody className="space-y-2">
            {orders.filter((o) => o.status === 'Filled' || o.status === 'Partial').slice(0, 5).map((o) => (
              <div key={o.id} className="flex items-center justify-between rounded-xl border border-border/50 bg-surface-2/60 p-3">
                <div className="flex items-center gap-2">
                  <Badge tone={o.side === 'Buy' ? 'success' : 'danger'}>{o.side}</Badge>
                  <span className="font-mono text-[13px] font-semibold text-fg">{o.symbol}</span>
                  <span className="text-[12px] text-muted">{o.filled}/{o.qty} @ {formatCurrency(o.price, { compact: o.price > 1000 })}</span>
                </div>
                <StatusBadge status={o.status} />
              </div>
            ))}
          </CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Venue Routing" subtitle="Fills by venue (last 30d)" />
          <CardBody><BarChart data={[42, 28, 18, 8, 4]} labels={['NSDQ', 'NYSE', 'EDGX', 'BATS', 'Dark']} tone="secondary" height={180} /></CardBody>
        </Card>
      </section>
    </div>
  );
}
