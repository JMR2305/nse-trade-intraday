import { Play, Pause, Plus, Target, Activity } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge, StatusBadge } from '@/components/ui/Badge';
import { ProgressGauge } from '@/components/data-display/ProgressGauge';
import { DataTable, type Column } from '@/components/data-display/DataTable';
import { AreaChart, BarChart } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { strategies, strategyHealthSeries, strategyPerformance } from '@/lib/demo-data';
import { formatCurrency, formatPercent } from '@/lib/utils';
import type { Strategy } from '@/lib/demo-data';

const columns: Column<Strategy>[] = [
  { key: 'name', header: 'Strategy', sortable: true, render: (r) => <span className="font-medium">{r.name}</span> },
  { key: 'type', header: 'Type', sortable: true, render: (r) => <span className="text-muted">{r.type}</span> },
  { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} pulse={r.status === 'Running'} /> },
  { key: 'pnl', header: 'P&L', align: 'right', sortable: true, render: (r) => <span className={r.pnl >= 0 ? 'text-success' : 'text-danger'}>{formatCurrency(r.pnl, { compact: true })}</span> },
  { key: 'pnlPct', header: 'Return', align: 'right', sortable: true, render: (r) => <span className={r.pnlPct >= 0 ? 'text-success' : 'text-danger'}>{formatPercent(r.pnlPct)}</span> },
  { key: 'sharpe', header: 'Sharpe', align: 'right', sortable: true, render: (r) => <span className="tabular-nums">{r.sharpe.toFixed(2)}</span> },
  { key: 'maxDrawdown', header: 'Max DD', align: 'right', sortable: true, render: (r) => <span className="text-danger tabular-nums">{r.maxDrawdown}%</span> },
  { key: 'winRate', header: 'Win Rate', align: 'right', sortable: true, render: (r) => <span className="tabular-nums">{r.winRate}%</span> },
  { key: 'trades', header: 'Trades', align: 'right', sortable: true, render: (r) => r.trades.toLocaleString() },
  { key: 'aiConfidence', header: 'AI', align: 'right', render: (r) => <span className="font-semibold text-primary tabular-nums">{r.aiConfidence}%</span> },
];

export function StrategiesPage() {
  const running = strategies.filter((s) => s.status === 'Running').length;
  const totalPnl = strategies.reduce((s, x) => s + x.pnl, 0);

  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Strategies · 6 deployed"
        title="Strategy Management"
        description="Deploy, monitor and pause systematic strategies with AI confidence scoring and live health metrics."
      >
        <Button variant="gradient" leftIcon={<Plus className="h-4 w-4" />}>New Strategy</Button>
        <Button variant="secondary" leftIcon={<Activity className="h-4 w-4" />}>Backtest</Button>
      </PageHero>

      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card hover className="p-5"><Target className="h-5 w-5 text-primary" /><p className="mt-3 text-[12px] uppercase text-faint">Active</p><p className="font-display text-2xl font-semibold text-fg">{running}</p></Card>
        <Card hover className="p-5"><Activity className="h-5 w-5 text-success" /><p className="mt-3 text-[12px] uppercase text-faint">Total P&L</p><p className="font-display text-2xl font-semibold text-success">{formatCurrency(totalPnl, { compact: true })}</p></Card>
        <Card hover className="p-5"><Target className="h-5 w-5 text-accent" /><p className="mt-3 text-[12px] uppercase text-faint">Avg Sharpe</p><p className="font-display text-2xl font-semibold text-fg">{(strategies.reduce((s, x) => s + x.sharpe, 0) / strategies.length).toFixed(2)}</p></Card>
        <Card hover className="p-5"><Activity className="h-5 w-5 text-secondary" /><p className="mt-3 text-[12px] uppercase text-faint">Total Trades</p><p className="font-display text-2xl font-semibold text-fg">{strategies.reduce((s, x) => s + x.trades, 0).toLocaleString()}</p></Card>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Aggregate Strategy Performance" subtitle="Cumulative return %" />
          <CardBody><AreaChart data={strategyPerformance} tone="primary" height={220} labels={['Q1','Apr','May','Jun','Jul']} /></CardBody>
        </Card>
        <Card hover gradientBorder>
          <CardHeader title="Deployment Health" subtitle="Ensemble confidence" />
          <CardBody className="flex flex-col items-center gap-4">
            <ProgressGauge value={Math.round(strategies.reduce((s, x) => s + x.aiConfidence, 0) / strategies.length)} tone="primary" size={150} label="Avg AI confidence" />
            <div className="grid w-full grid-cols-2 gap-2">
              <div className="rounded-lg border border-border/50 bg-surface-2/40 p-2 text-center"><p className="text-[10px] text-faint">Running</p><p className="text-[14px] font-semibold text-success">{running}</p></div>
              <div className="rounded-lg border border-border/50 bg-surface-2/40 p-2 text-center"><p className="text-[10px] text-faint">Frozen</p><p className="text-[14px] font-semibold text-info">{strategies.filter((s) => s.status === 'Frozen').length}</p></div>
            </div>
          </CardBody>
        </Card>
      </section>

      <section>
        <SectionHeading title="Strategy Cards" subtitle="Individual health and P&L" />
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {strategies.map((s) => {
            const series = strategyHealthSeries[s.id] ?? [20, 30, 40, 50, 60];
            return (
              <Card key={s.id} hover className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-[14px] font-semibold text-fg">{s.name}</p>
                    <p className="text-[11px] text-muted">{s.type}</p>
                  </div>
                  <StatusBadge status={s.status} pulse={s.status === 'Running'} />
                </div>
                <div className="mt-3 flex items-end justify-between">
                  <div>
                    <p className="font-display text-xl font-semibold tabular-nums text-fg">{formatCurrency(s.pnl, { compact: true })}</p>
                    <p className={s.pnlPct >= 0 ? 'text-[12px] text-success' : 'text-[12px] text-danger'}>{formatPercent(s.pnlPct)}</p>
                  </div>
                  <AreaChart data={series} tone={s.pnlPct >= 0 ? 'success' : 'danger'} height={48} width={140} showAxis={false} className="w-[140px]" />
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div><p className="text-[10px] text-faint">Sharpe</p><p className="text-[13px] font-semibold tabular-nums">{s.sharpe.toFixed(2)}</p></div>
                  <div><p className="text-[10px] text-faint">Win</p><p className="text-[13px] font-semibold tabular-nums">{s.winRate}%</p></div>
                  <div><p className="text-[10px] text-faint">AI</p><p className="text-[13px] font-semibold tabular-nums text-primary">{s.aiConfidence}%</p></div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button variant="secondary" size="sm" className="flex-1" leftIcon={s.status === 'Running' ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}>
                    {s.status === 'Running' ? 'Pause' : 'Start'}
                  </Button>
                  <Button variant="ghost" size="sm">Details</Button>
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      <section>
        <SectionHeading title="All Strategies" subtitle="Full deployment table" />
        <DataTable columns={columns} rows={strategies} searchKeys={['name', 'type', 'status']} />
      </section>

      <Card hover>
        <CardHeader title="Trade Count by Strategy" subtitle="Last 30 days" />
        <CardBody><BarChart data={strategies.map((s) => s.trades)} labels={strategies.map((s) => s.name.split(' ')[0])} tone="secondary" height={180} /></CardBody>
      </Card>
    </div>
  );
}
