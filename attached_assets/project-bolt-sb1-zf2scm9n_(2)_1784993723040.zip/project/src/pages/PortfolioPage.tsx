import { Wallet, Download, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Card, CardBody, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { MetricCard } from '@/components/data-display/MetricCard';
import { DataTable, type Column } from '@/components/data-display/DataTable';
import { AreaChart, DonutChart, BarChart, Sparkline } from '@/components/charts/Charts';
import { PageHero, SectionHeading } from '@/components/ui/Section';
import { holdings, portfolioGrowth, portfolioSummary, sectorAllocation, pnlContribution } from '@/lib/demo-data';
import { formatCurrency, formatPercent } from '@/lib/utils';
import type { Tone } from '@/lib/theme';
import type { PortfolioHolding } from '@/lib/demo-data';

const columns: Column<PortfolioHolding>[] = [
  { key: 'symbol', header: 'Symbol', sortable: true, render: (r) => <span className="font-mono font-semibold">{r.symbol}</span> },
  { key: 'name', header: 'Name', sortable: true, render: (r) => <span className="text-muted">{r.name}</span> },
  { key: 'sector', header: 'Sector', sortable: true, render: (r) => <span className="text-muted">{r.sector}</span> },
  { key: 'shares', header: 'Shares', align: 'right', sortable: true, render: (r) => r.shares.toLocaleString() },
  { key: 'avgCost', header: 'Avg Cost', align: 'right', sortable: true, render: (r) => formatCurrency(r.avgCost) },
  { key: 'last', header: 'Last', align: 'right', sortable: true, render: (r) => formatCurrency(r.last) },
  {
    key: 'changePct',
    header: 'Change',
    align: 'right',
    sortable: true,
    render: (r) => (
      <span className={r.changePct >= 0 ? 'text-success' : 'text-danger'}>
        {r.changePct >= 0 ? <ArrowUpRight className="mr-0.5 inline h-3.5 w-3.5" /> : <ArrowDownRight className="mr-0.5 inline h-3.5 w-3.5" />}
        {formatPercent(r.changePct)}
      </span>
    ),
  },
  {
    key: 'weight',
    header: 'Weight',
    align: 'right',
    sortable: true,
    render: (r) => (
      <div className="flex items-center justify-end gap-2">
        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-surface-2">
          <div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, r.weight * 4)}%` }} />
        </div>
        <span className="tabular-nums">{r.weight}%</span>
      </div>
    ),
  },
];

export function PortfolioPage() {
  return (
    <div className="space-y-8">
      <PageHero
        eyebrow="Portfolio · 25 Jul 2026"
        title="Portfolio Overview"
        description="Holdings, allocation and performance attribution across equities and digital assets."
      >
        <Button variant="gradient" leftIcon={<Download className="h-4 w-4" />}>Export</Button>
        <Button variant="secondary" leftIcon={<Wallet className="h-4 w-4" />}>Rebalance</Button>
      </PageHero>

      <section>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {portfolioSummary.map((m, i) => <MetricCard key={m.label} {...m} delay={i * 80} />)}
        </div>
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" hover>
          <CardHeader title="Net Liquidation" subtitle="18-session growth" action={<Badge tone="success" dot>+14.3% MTD</Badge>} />
          <CardBody><AreaChart data={portfolioGrowth} tone="primary" height={240} labels={['Jun','Jul 1','Jul 8','Jul 15','Today']} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Sector Allocation" subtitle="Weights" />
          <CardBody><DonutChart data={sectorAllocation.map((s) => ({ label: s.label, value: s.value, color: s.color as Tone }))} size={170} /></CardBody>
        </Card>
      </section>

      <section>
        <SectionHeading title="Holdings" subtitle="All open positions" action={<Button variant="ghost" size="sm">View as grid</Button>} />
        <DataTable
          columns={columns}
          rows={holdings.map((h) => ({ ...h, id: h.symbol }))}
          searchKeys={['symbol', 'name', 'sector']}
        />
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card hover>
          <CardHeader title="Daily P&L Contribution" subtitle="Last 7 days" />
          <CardBody><BarChart data={pnlContribution.map((p) => p.value)} labels={pnlContribution.map((p) => p.label)} tone="primary" height={200} /></CardBody>
        </Card>
        <Card hover>
          <CardHeader title="Top Movers" subtitle="Intraday sparklines" />
          <CardBody className="space-y-2">
            {holdings.slice(0, 5).map((h) => {
              const spark = Array.from({ length: 12 }, (_, i) => h.last * (1 + (Math.sin(i) + h.changePct) * 0.004));
              return (
                <div key={h.symbol} className="flex items-center justify-between gap-3 rounded-xl border border-border/50 bg-surface-2/30 p-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-[13px] font-semibold text-fg">{h.symbol}</span>
                    <Sparkline data={spark} tone={h.changePct >= 0 ? 'success' : 'danger'} width={100} height={32} />
                  </div>
                  <div className="text-right">
                    <p className="text-[13px] font-semibold tabular-nums text-fg">{formatCurrency(h.last)}</p>
                    <p className={h.changePct >= 0 ? 'text-[11px] text-success' : 'text-[11px] text-danger'}>{formatPercent(h.changePct)}</p>
                  </div>
                </div>
              );
            })}
          </CardBody>
        </Card>
      </section>
    </div>
  );
}
