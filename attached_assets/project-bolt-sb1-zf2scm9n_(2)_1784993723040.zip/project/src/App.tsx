import { useEffect, useState } from 'react';
import { AppLayout } from '@/components/layout/AppLayout';
import {
  AiInsightsPage,
  DashboardPage,
  DocumentsPage,
  MarketWatchPage,
  OrdersPage,
  PortfolioPage,
  ProfilePage,
  RiskCenterPage,
  SettingsPage,
  StrategiesPage,
  TradingPage,
} from '@/pages';

const pages: Record<string, React.ComponentType> = {
  dashboard: DashboardPage,
  'ai-insights': AiInsightsPage,
  portfolio: PortfolioPage,
  strategies: StrategiesPage,
  orders: OrdersPage,
  'market-watch': MarketWatchPage,
  trading: TradingPage,
  'risk-center': RiskCenterPage,
  documents: DocumentsPage,
  settings: SettingsPage,
  profile: ProfilePage,
};

type Theme = 'dark' | 'light';

const THEME_KEY = 'omniroute-theme';

function getInitialTheme(): Theme {
  if (typeof window === 'undefined') return 'light';
  const saved = window.localStorage.getItem(THEME_KEY);
  return saved === 'dark' || saved === 'light' ? saved : 'light';
}

function App() {
  const [active, setActive] = useState('dashboard');
  const [theme, setTheme] = useState<Theme>(getInitialTheme);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.classList.toggle('light', theme === 'light');
    try {
      window.localStorage.setItem(THEME_KEY, theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  const Page = pages[active] ?? DashboardPage;

  return (
    <AppLayout
      active={active}
      onNavigate={setActive}
      theme={theme}
      onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
    >
      <Page />
    </AppLayout>
  );
}

export default App;
