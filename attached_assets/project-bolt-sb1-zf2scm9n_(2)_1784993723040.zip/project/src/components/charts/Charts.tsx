import { useId } from 'react';
import { toneRgb, toneRgbSoft, type Tone } from '@/lib/theme';
import { cn } from '@/lib/utils';

// ---- Shared helpers ----
function buildPath(data: number[], w: number, h: number, pad = 6): string {
  if (data.length === 0) return '';
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const stepX = (w - pad * 2) / Math.max(1, data.length - 1);
  return data
    .map((d, i) => {
      const x = pad + i * stepX;
      const y = pad + (h - pad * 2) * (1 - (d - min) / range);
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(' ');
}

function buildArea(data: number[], w: number, h: number, pad = 6): string {
  const line = buildPath(data, w, h, pad);
  if (!line) return '';
  const stepX = (w - pad * 2) / Math.max(1, data.length - 1);
  const baseY = h - pad;
  const startX = pad;
  const endX = pad + (data.length - 1) * stepX;
  return `${line} L ${endX.toFixed(2)} ${baseY} L ${startX.toFixed(2)} ${baseY} Z`;
}

interface BaseProps {
  width?: number;
  height?: number;
  className?: string;
}

// ---- Area / Line chart with gradient fill and animated draw ----
interface AreaChartProps extends BaseProps {
  data: number[];
  tone?: Tone;
  labels?: string[];
  showAxis?: boolean;
  height?: number;
}

export function AreaChart({ data, tone = 'primary', labels, showAxis = true, height = 220, className }: AreaChartProps) {
  const uid = useId().replace(/:/g, '');
  const w = 640;
  const h = height;
  const linePath = buildPath(data, w, h, 16);
  const areaPath = buildArea(data, w, h, 16);
  const max = Math.max(...data);
  const min = Math.min(...data);

  return (
    <div className={cn('w-full', className)}>
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full" preserveAspectRatio="none" style={{ height }}>
        <defs>
          <linearGradient id={`area-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={toneRgbSoft(tone, 0.45)} />
            <stop offset="100%" stopColor={toneRgbSoft(tone, 0)} />
          </linearGradient>
          <linearGradient id={`line-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor={toneRgb(tone)} />
            <stop offset="100%" stopColor={toneRgb('accent')} />
          </linearGradient>
        </defs>
        {showAxis &&
          [0.25, 0.5, 0.75].map((p) => (
            <line key={p} x1="16" x2={w - 16} y1={16 + (h - 32) * p} y2={16 + (h - 32) * p} stroke="rgb(var(--color-border))" strokeDasharray="3 5" strokeWidth="1" opacity="0.5" />
          ))}
        {areaPath && <path d={areaPath} fill={`url(#area-${uid})`} className="animate-fade-in" />}
        {linePath && (
          <path
            d={linePath}
            fill="none"
            stroke={`url(#line-${uid})`}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{
              strokeDasharray: 2000,
              strokeDashoffset: 2000,
              animation: 'dash 1.4s ease-out forwards',
            }}
          />
        )}
        {/* end dot */}
        {data.length > 0 && (() => {
          const stepX = (w - 32) / Math.max(1, data.length - 1);
          const x = 16 + (data.length - 1) * stepX;
          const y = 16 + (h - 32) * (1 - (data[data.length - 1] - min) / (max - min || 1));
          return <circle cx={x} cy={y} r="4" fill={toneRgb(tone)} className="animate-pulse-soft" />;
        })()}
      </svg>
      {labels && (
        <div className="mt-2 flex justify-between px-1 text-[11px] text-faint">
          {labels.map((l) => (
            <span key={l}>{l}</span>
          ))}
        </div>
      )}
      <style>{`@keyframes dash{to{stroke-dashoffset:0}}`}</style>
    </div>
  );
}

// ---- Sparkline (tiny inline trend) ----
export function Sparkline({ data, tone = 'primary', width = 120, height = 36, className }: BaseProps & { data: number[]; tone?: Tone }) {
  const uid = useId().replace(/:/g, '');
  const linePath = buildPath(data, width, height, 3);
  const areaPath = buildArea(data, width, height, 3);
  const up = data[data.length - 1] >= data[0];
  const color = up ? toneRgb('success') : toneRgb('danger');
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height} className={cn('overflow-visible', className)}>
      <defs>
        <linearGradient id={`sp-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={up ? toneRgbSoft('success', 0.4) : toneRgbSoft('danger', 0.4)} />
          <stop offset="100%" stopColor="transparent" />
        </linearGradient>
      </defs>
      {areaPath && <path d={areaPath} fill={`url(#sp-${uid})`} />}
      {linePath && <path d={linePath} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />}
    </svg>
  );
}

// ---- Bar chart ----
export function BarChart({ data, labels, tone = 'primary', height = 200, className }: BaseProps & { data: number[]; labels?: string[]; tone?: Tone }) {
  const uid = useId().replace(/:/g, '');
  const w = 640;
  const max = Math.max(...data.map((d) => Math.abs(d)), 1);
  const barW = (w - 32) / data.length - 12;
  return (
    <div className={cn('w-full', className)}>
      <svg viewBox={`0 0 ${w} ${height}`} className="w-full" style={{ height }}>
        <defs>
          <linearGradient id={`bar-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={toneRgb(tone)} />
            <stop offset="100%" stopColor={toneRgbSoft(tone, 0.25)} />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((p) => (
          <line key={p} x1="16" x2={w - 16} y1={16 + (height - 32) * p} y2={16 + (height - 32) * p} stroke="rgb(var(--color-border))" strokeDasharray="3 5" strokeWidth="1" opacity="0.5" />
        ))}
        {data.map((d, i) => {
          const barH = (Math.abs(d) / max) * (height - 32);
          const x = 16 + i * (barW + 12);
          const y = height - 16 - barH;
          const positive = d >= 0;
          return (
            <g key={i}>
              <rect x={x} y={y} width={barW} height={barH} rx="6" fill={`url(#bar-${uid})`} opacity={positive ? 1 : 0.6} />
            </g>
          );
        })}
      </svg>
      {labels && (
        <div className="mt-2 flex justify-between px-1 text-[11px] text-faint" style={{ gap: 12 }}>
          {labels.map((l) => (
            <span key={l} className="flex-1 text-center">{l}</span>
          ))}
        </div>
      )}
    </div>
  );
}

// ---- Donut chart ----
export function DonutChart({
  data,
  size = 180,
  thickness = 22,
  className,
}: {
  data: { label: string; value: number; color: Tone }[];
  size?: number;
  thickness?: number;
  className?: string;
}) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className={cn('flex items-center gap-6', className)}>
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgb(var(--color-surface-2))" strokeWidth={thickness} />
          {data.map((d) => {
            const frac = d.value / total;
            const dash = frac * c;
            const gap = c - dash;
            const offset = -acc * c;
            acc += frac;
            return (
              <circle
                key={d.label}
                cx={size / 2}
                cy={size / 2}
                r={r}
                fill="none"
                stroke={toneRgb(d.color)}
                strokeWidth={thickness}
                strokeDasharray={`${dash} ${gap}`}
                strokeDashoffset={offset}
                strokeLinecap="butt"
                style={{ transition: 'stroke-dasharray 0.8s ease-out' }}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 grid place-items-center">
          <div className="text-center">
            <p className="font-display text-lg font-semibold tabular-nums">{total}%</p>
            <p className="text-[11px] text-faint">Total</p>
          </div>
        </div>
      </div>
      <ul className="flex-1 space-y-2">
        {data.map((d) => (
          <li key={d.label} className="flex items-center justify-between gap-3 text-[13px]">
            <span className="flex items-center gap-2 text-muted">
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: toneRgb(d.color) }} />
              {d.label}
            </span>
            <span className="font-medium tabular-nums text-fg">{d.value}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---- Heatmap (risk by asset class) ----
export function Heatmap({ data, className }: { data: [string, number, Tone][]; className?: string }) {
  const max = Math.max(...data.map((d) => d[1]), 1);
  return (
    <div className={cn('grid grid-cols-2 gap-2 sm:grid-cols-3', className)}>
      {data.map(([label, value, tone]) => {
        const intensity = value / max;
        return (
          <div
            key={label}
            className="relative overflow-hidden rounded-xl border border-border/60 p-3"
            style={{ background: toneRgbSoft(tone, 0.08 + intensity * 0.18) }}
          >
            <div className="flex items-center justify-between">
              <span className="text-[12px] font-medium text-muted">{label}</span>
              <span className="font-mono text-[13px] font-semibold tabular-nums" style={{ color: toneRgb(tone) }}>
                {value}%
              </span>
            </div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
              <div className="h-full rounded-full" style={{ width: `${intensity * 100}%`, background: toneRgb(tone) }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ---- Activity timeline (vertical) ----
export function Timeline({ items }: { items: { id: string; title: string; detail: string; status: 'done' | 'active' | 'planned'; date: string }[] }) {
  const dotTone = { done: 'success', active: 'primary', planned: 'faint' } as const;
  return (
    <ol className="relative space-y-5 pl-6">
      <span className="absolute left-[7px] top-1 bottom-1 w-px bg-border" />
      {items.map((it) => (
        <li key={it.id} className="relative">
          <span
            className={cn('absolute -left-[22px] top-1 h-3.5 w-3.5 rounded-full ring-4 ring-bg', `bg-${dotTone[it.status]}`)}
            style={{ background: toneRgb(dotTone[it.status]) }}
          />
          <div className="flex items-center justify-between gap-3">
            <p className="text-[13px] font-medium text-fg">{it.title}</p>
            <span className="text-[11px] text-faint">{it.date}</span>
          </div>
          <p className="mt-0.5 text-[12px] text-muted">{it.detail}</p>
        </li>
      ))}
    </ol>
  );
}
