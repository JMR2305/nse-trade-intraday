import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

export function SectionHeading({
  title,
  subtitle,
  action,
  className,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('mb-4 flex items-end justify-between gap-4', className)}>
      <div>
        <h2 className="font-display text-[15px] font-semibold tracking-tight text-fg">{title}</h2>
        {subtitle && <p className="mt-0.5 text-[13px] text-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="relative mb-8 overflow-hidden rounded-3xl border border-border/80 bg-surface shadow-card p-6 lg:p-8">
      <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-primary/8 blur-[100px]" />
      <div className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-highlight/8 blur-[100px]" />
      <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface-2/60 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-muted">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse-soft" />
            {eyebrow}
          </span>
          <h1 className="mt-3 font-display text-2xl font-semibold tracking-tight text-fg lg:text-[28px]">
            {title}
          </h1>
          <p className="mt-2 text-[14px] leading-relaxed text-muted">{description}</p>
        </div>
        {children && <div className="flex shrink-0 flex-wrap items-center gap-2">{children}</div>}
      </div>
    </div>
  );
}
