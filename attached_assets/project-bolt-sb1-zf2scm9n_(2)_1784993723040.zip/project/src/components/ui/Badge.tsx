import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { toneText, toneSoftBg, toneRing, type Tone } from '@/lib/theme';

interface BadgeProps {
  tone?: Tone;
  children: ReactNode;
  dot?: boolean;
  pulse?: boolean;
  className?: string;
}

export function Badge({ tone = 'primary', children, dot = false, pulse = false, className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium ring-1',
        toneSoftBg[tone],
        toneText[tone],
        toneRing[tone],
        className,
      )}
    >
      {dot && (
        <span className={cn('inline-block h-1.5 w-1.5 rounded-full', `bg-current`, pulse && 'animate-pulse-soft')} />
      )}
      {children}
    </span>
  );
}

// Status badges for trading lifecycle
const statusMap: Record<string, { tone: Tone; label: string }> = {
  Running: { tone: 'success', label: 'Running' },
  Frozen: { tone: 'info', label: 'Frozen' },
  Completed: { tone: 'faint', label: 'Completed' },
  Pending: { tone: 'warning', label: 'Pending' },
  'Paper Trading': { tone: 'accent', label: 'Paper Trading' },
  'AI Active': { tone: 'primary', label: 'AI Active' },
  'Live Disabled': { tone: 'danger', label: 'Live Disabled' },
  // orders
  Filled: { tone: 'success', label: 'Filled' },
  Working: { tone: 'primary', label: 'Working' },
  Partial: { tone: 'warning', label: 'Partial' },
  Cancelled: { tone: 'faint', label: 'Cancelled' },
  Rejected: { tone: 'danger', label: 'Rejected' },
  // signals
  Active: { tone: 'success', label: 'Active' },
  Acknowledged: { tone: 'primary', label: 'Acknowledged' },
  Executing: { tone: 'accent', label: 'Executing' },
};

export function StatusBadge({ status, pulse = false }: { status: string; pulse?: boolean }) {
  const cfg = statusMap[status] ?? { tone: 'faint' as Tone, label: status };
  return (
    <Badge tone={cfg.tone} dot pulse={pulse}>
      {cfg.label}
    </Badge>
  );
}
