import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '@/lib/utils';

type Variant = 'primary' | 'secondary' | 'ghost' | 'gradient' | 'danger' | 'outline';
type Size = 'sm' | 'md' | 'lg' | 'icon';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
}

const base =
  'relative inline-flex items-center justify-center gap-2 font-medium rounded-xl transition-all duration-200 select-none disabled:opacity-50 disabled:pointer-events-none focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:ring-offset-2 focus-visible:ring-offset-bg active:scale-[0.98]';

const variants: Record<Variant, string> = {
  primary:
    'bg-primary text-primary-fg shadow-card hover:bg-[rgb(var(--color-primary)/0.92)] hover:shadow-card-hover',
  secondary:
    'bg-surface-2 text-fg border border-border hover:border-border-strong hover:bg-elevated',
  ghost: 'text-muted hover:text-fg hover:bg-surface-2',
  outline: 'border border-border text-fg hover:bg-surface-2 hover:border-border-strong',
  danger:
    'bg-danger text-white shadow-card hover:bg-[rgb(var(--color-danger)/0.92)]',
  gradient:
    'text-white shadow-card hover:shadow-card-hover bg-[linear-gradient(110deg,rgb(var(--color-primary)),rgb(var(--color-secondary))_55%,rgb(var(--color-accent)))] hover:brightness-[1.03]',
};

const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-[13px]',
  md: 'h-10 px-4 text-sm',
  lg: 'h-12 px-6 text-[15px]',
  icon: 'h-9 w-9',
};

export function Button({
  variant = 'primary',
  size = 'md',
  leftIcon,
  rightIcon,
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button className={cn(base, variants[variant], sizes[size], className)} {...props}>
      {leftIcon}
      {children}
      {rightIcon}
    </button>
  );
}
