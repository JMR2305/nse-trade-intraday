import { cn } from '@/lib/utils';

type LogoProps = {
  className?: string;
  showWordmark?: boolean;
  size?: number;
};

/**
 * OmniRoute AI brand mark — a stylized upward routing path through network nodes,
 * communicating AI, trading analytics, precision and trust.
 */
export function Logo({ className, showWordmark = true, size = 28 }: LogoProps) {
  return (
    <div className={cn('flex items-center gap-2.5 select-none', className)}>
      <span className="relative inline-flex" style={{ width: size, height: size }}>
        <svg
          viewBox="0 0 32 32"
          width={size}
          height={size}
          className="drop-shadow-[0_1px_2px_rgb(var(--color-primary)/0.18)]"
          aria-hidden
        >
          <defs>
            <linearGradient id="ora-g" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="rgb(var(--color-primary))" />
              <stop offset="1" stopColor="rgb(var(--color-accent))" />
            </linearGradient>
          </defs>
          <rect width="32" height="32" rx="9" fill="rgb(var(--color-surface))" />
          <rect
            width="32"
            height="32"
            rx="9"
            fill="url(#ora-g)"
            opacity="0.14"
          />
          <path
            d="M6 21 L13 11 L18 17 L22 12 L26 21"
            fill="none"
            stroke="url(#ora-g)"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="13" cy="11" r="1.8" fill="rgb(var(--color-primary))" />
          <circle cx="22" cy="12" r="1.8" fill="rgb(var(--color-accent))" />
          <circle cx="6" cy="21" r="1.4" fill="rgb(var(--color-secondary))" />
          <circle cx="26" cy="21" r="1.4" fill="rgb(var(--color-accent))" />
        </svg>
      </span>
      {showWordmark && (
        <span className="font-display font-semibold tracking-tight text-[15px] leading-none">
          OmniRoute<span className="text-primary"> AI</span>
        </span>
      )}
    </div>
  );
}
