import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Sidebar } from '@/components/layout/Sidebar';
import { TopNav } from '@/components/layout/TopNav';
import { pageMeta } from '@/lib/navigation';
import { cn } from '@/lib/utils';

interface AppLayoutProps {
  active: string;
  onNavigate: (id: string) => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  children: React.ReactNode;
}

export function AppLayout({ active, onNavigate, theme, onToggleTheme, children }: AppLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const meta = pageMeta[active] ?? { title: 'OmniRoute AI', subtitle: '' };

  return (
    <div className="relative flex h-screen overflow-hidden bg-bg">
      {/* Ambient background layers — calm, warm-tinted */}
      <div className="pointer-events-none absolute inset-0 -z-10 bg-mesh" />
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-[0.5] bg-grid-faint [background-size:64px_64px]" />
      <div className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(120%_80%_at_50%_-10%,transparent,rgb(var(--color-bg))_70%)]" />

      {/* Desktop sidebar */}
      <div className="hidden md:block">
        <Sidebar active={active} onNavigate={onNavigate} />
      </div>

      {/* Mobile sidebar drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-fg/30 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 h-full animate-fade-in">
            <Sidebar active={active} onNavigate={(id) => { onNavigate(id); setMobileOpen(false); }} />
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute right-3 top-4 grid h-8 w-8 place-items-center rounded-lg bg-surface-2 text-muted"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={() => setMobileOpen(true)}
            className="m-3 grid h-9 w-9 place-items-center rounded-xl border border-border bg-surface-2 text-muted"
          >
            <Menu className="h-4 w-4" />
          </button>
        </div>
        <TopNav theme={theme} onToggleTheme={onToggleTheme} title={meta.title} subtitle={meta.subtitle} />
        <main className={cn('flex-1 overflow-y-auto px-4 py-6 lg:px-8 lg:py-8')}>
          <div className="mx-auto max-w-[1400px]">{children}</div>
        </main>
      </div>
    </div>
  );
}
