import { useState } from 'react';
import {
  Bell,
  ChevronDown,
  Command,
  Moon,
  Plus,
  Search,
  Sun,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TopNavProps {
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  title: string;
  subtitle: string;
}

export function TopNav({ theme, onToggleTheme, title, subtitle }: TopNavProps) {
  const [marketOpen] = useState(true);

  return (
    <header className="glass-strong sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-border/70 px-4 lg:px-6">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h1 className="truncate font-display text-[17px] font-semibold tracking-tight text-fg">{title}</h1>
          <span className="hidden rounded-full bg-success/12 px-2 py-0.5 text-[10px] font-semibold text-success ring-1 ring-success/30 sm:inline">
            AI ACTIVE
          </span>
        </div>
        <p className="truncate text-[12px] text-muted">{subtitle}</p>
      </div>

      {/* Global search */}
      <div className="relative hidden md:block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <input
          placeholder="Search markets, strategies, orders…"
          className="h-9 w-[280px] rounded-xl border border-border bg-surface-2 pl-9 pr-16 text-[13px] text-fg placeholder:text-faint focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        <kbd className="absolute right-2.5 top-1/2 -translate-y-1/2 hidden items-center gap-0.5 rounded border border-border bg-elevated px-1.5 py-0.5 text-[10px] text-faint lg:flex">
          <Command className="h-3 w-3" />K
        </kbd>
      </div>

      {/* Market status */}
      <div className="hidden items-center gap-2 rounded-xl border border-border bg-surface-2 px-3 py-1.5 lg:flex">
        <span className={cn('h-2 w-2 rounded-full', marketOpen ? 'bg-success animate-pulse-soft' : 'bg-faint')} />
        <span className="text-[11px] font-medium text-muted">NYSE</span>
        <span className="text-[11px] text-faint">·</span>
        <span className={cn('text-[11px] font-semibold', marketOpen ? 'text-success' : 'text-faint')}>
          {marketOpen ? 'OPEN' : 'CLOSED'}
        </span>
      </div>

      {/* AI status */}
      <div className="hidden items-center gap-1.5 rounded-xl border border-primary/25 bg-primary/8 px-3 py-1.5 xl:flex">
        <Zap className="h-3.5 w-3.5 text-primary" />
        <span className="text-[11px] font-medium text-primary">Ensemble v4.2.1</span>
      </div>

      {/* Quick create */}
      <button className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-surface-2 text-muted hover:text-fg hover:border-border-strong">
        <Plus className="h-4 w-4" />
      </button>

      {/* Notifications */}
      <button className="relative grid h-9 w-9 place-items-center rounded-xl border border-border bg-surface-2 text-muted hover:text-fg hover:border-border-strong">
        <Bell className="h-4 w-4" />
        <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-danger ring-2 ring-bg" />
      </button>

      {/* Theme switch */}
      <button
        onClick={onToggleTheme}
        className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-surface-2 text-muted hover:text-fg hover:border-border-strong"
        aria-label="Toggle theme"
      >
        {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </button>

      {/* Profile */}
      <button className="flex items-center gap-2 rounded-xl border border-border bg-surface-2 py-1.5 pl-1.5 pr-2 hover:border-border-strong">
        <span className="grid h-7 w-7 place-items-center rounded-lg bg-primary text-[12px] font-semibold text-primary-fg">
          AR
        </span>
        <span className="hidden text-left sm:block">
          <span className="block text-[12px] font-semibold leading-tight text-fg">Ava Rivera</span>
          <span className="block text-[10px] leading-tight text-faint">Portfolio Manager</span>
        </span>
        <ChevronDown className="hidden h-3.5 w-3.5 text-faint sm:block" />
      </button>
    </header>
  );
}
