import { useState } from 'react';
import { ChevronLeft, Star } from 'lucide-react';
import { Logo } from '@/components/brand/Logo';
import { cn } from '@/lib/utils';
import { navItems, type NavItem } from '@/lib/navigation';

interface SidebarProps {
  active: string;
  onNavigate: (id: string) => void;
}

const groups: NavItem['group'][] = ['Workspace', 'Markets', 'System'];

export function Sidebar({ active, onNavigate }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        'glass-strong relative z-30 flex h-full flex-col border-r border-border/70 transition-[width] duration-300',
        collapsed ? 'w-[76px]' : 'w-[248px]',
      )}
    >
      <div className="flex h-16 items-center justify-between px-4">
        <Logo showWordmark={!collapsed} size={30} />
        <button
          onClick={() => setCollapsed((c) => !c)}
          className={cn(
            'grid h-7 w-7 place-items-center rounded-lg text-faint hover:bg-surface-2 hover:text-fg transition',
            collapsed && 'absolute -right-3 top-5 z-40 grid h-6 w-6 place-items-center rounded-full border border-border bg-elevated shadow-pop',
          )}
          aria-label="Toggle sidebar"
        >
          <ChevronLeft className={cn('h-4 w-4 transition-transform', collapsed && 'rotate-180')} />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {groups.map((group) => {
          const items = navItems.filter((i) => i.group === group);
          if (items.length === 0) return null;
          return (
            <div key={group} className="mb-5">
              {!collapsed && (
                <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-faint">{group}</p>
              )}
              <ul className="space-y-1">
                {items.map((item) => {
                  const isActive = active === item.id;
                  const Icon = item.icon;
                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => onNavigate(item.id)}
                        className={cn(
                          'group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all',
                          isActive ? 'text-fg' : 'text-muted hover:text-fg hover:bg-surface-2/60',
                          collapsed && 'justify-center px-0',
                        )}
                      >
                        {isActive && (
                          <>
                            <span className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-primary" />
                            <span className="absolute inset-0 rounded-xl bg-primary/8 ring-1 ring-primary/20" />
                          </>
                        )}
                        <Icon className={cn('relative h-[18px] w-[18px] shrink-0', isActive && 'text-primary')} />
                        {!collapsed && <span className="relative truncate">{item.label}</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      {!collapsed && (
        <div className="m-3 rounded-2xl border border-border/70 bg-surface p-4 shadow-card">
          <div className="flex items-center gap-2">
            <Star className="h-4 w-4 text-highlight" />
            <p className="text-[12px] font-semibold text-fg">Pro Plan</p>
          </div>
          <p className="mt-1 text-[11px] text-muted">AI ensemble, multi-venue routing and full risk suite.</p>
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
            <div className="h-full w-[72%] rounded-full bg-gradient-to-r from-primary to-accent" />
          </div>
          <p className="mt-1.5 text-[10px] text-faint">72% of monthly execution budget used</p>
        </div>
      )}
    </aside>
  );
}
