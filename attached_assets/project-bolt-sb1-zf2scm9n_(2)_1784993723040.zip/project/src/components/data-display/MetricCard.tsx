import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { cn } from '@/lib/utils';
import type { Trend } from '@/lib/demo-data';

interface MetricCardProps {
  label: string;
  value: string;
  delta: number;
  deltaLabel: string;
  trend: Trend;
  hint?: string;
  icon?: React.ReactNode;
  delay?: number;
}

const trendIcon: Record<Trend, React.ReactNode> = {
  up: <ArrowUpRight className="h-3.5 w-3.5" />,
  down: <ArrowDownRight className="h-3.5 w-3.5" />,
  flat: <Minus className="h-3.5 w-3.5" />,
};

const trendTone: Record<Trend, string> = {
  up: 'text-success bg-success/12',
  down: 'text-danger bg-danger/12',
  flat: 'text-muted bg-surface-2',
};

export function MetricCard({ label, value, delta, deltaLabel, trend, hint, icon, delay = 0 }: MetricCardProps) {
  return (
    <Card hover className="animate-fade-in p-5" style={{ animationDelay: `${delay}ms` }}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[12px] font-medium uppercase tracking-wider text-faint">{label}</p>
          <p className="mt-2 font-display text-[26px] font-semibold tracking-tight text-fg tabular-nums">{value}</p>
        </div>
        {icon && (
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/30">
            {icon}
          </span>
        )}
      </div>
      <div className="mt-3 flex items-center gap-2">
        <span className={cn('inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-[12px] font-semibold tabular-nums', trendTone[trend])}>
          {trendIcon[trend]}
          {delta > 0 ? '+' : ''}
          {delta}%
        </span>
        <span className="text-[12px] text-muted">{deltaLabel}</span>
      </div>
      {hint && <p className="mt-2 text-[11px] text-faint">{hint}</p>}
    </Card>
  );
}
