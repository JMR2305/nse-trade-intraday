import { cn } from '@/lib/utils';
import { toneText } from '@/lib/theme';
import type { Tone } from '@/lib/theme';

interface ProgressGaugeProps {
  value: number; // 0-100
  label?: string;
  tone?: Tone;
  size?: number;
  thickness?: number;
  display?: string;
}

export function ProgressGauge({
  value,
  label,
  tone = 'primary',
  size = 120,
  thickness = 10,
  display,
}: ProgressGaugeProps) {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = c - (clamped / 100) * c;
  const uid = `pg-${tone}-${size}`;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <defs>
            <linearGradient id={uid} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor={`rgb(var(--color-${tone}))`} />
              <stop offset="100%" stopColor={`rgb(var(--color-accent))`} />
            </linearGradient>
          </defs>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgb(var(--color-surface-2))" strokeWidth={thickness} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={`url(#${uid})`}
            strokeWidth={thickness}
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.9s cubic-bezier(0.22,1,0.36,1)' }}
          />
        </svg>
        <div className="absolute inset-0 grid place-items-center">
          <span className={cn('font-display text-xl font-semibold tabular-nums', toneText[tone])}>
            {display ?? `${Math.round(clamped)}%`}
          </span>
        </div>
      </div>
      {label && <p className="text-[12px] text-muted">{label}</p>}
    </div>
  );
}
