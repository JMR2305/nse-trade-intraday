// Realistic, clearly-labeled demo data for OmniRoute AI.
// No fabricated live trading results — these are illustrative figures.

import type { Tone } from '@/lib/theme';

export type Trend = 'up' | 'down' | 'flat';

export interface Metric {
  label: string;
  value: string;
  delta: number;
  deltaLabel: string;
  trend: Trend;
  hint?: string;
}

export interface PortfolioHolding {
  symbol: string;
  name: string;
  sector: string;
  weight: number;
  shares: number;
  avgCost: number;
  last: number;
  changePct: number;
}

export interface Signal {
  id: string;
  symbol: string;
  strategy: string;
  side: 'Long' | 'Short' | 'Neutral';
  confidence: number;
  price: number;
  time: string;
  status: 'Active' | 'Acknowledged' | 'Executing' | 'Rejected';
}

export interface Strategy {
  id: string;
  name: string;
  type: string;
  status: 'Running' | 'Frozen' | 'Completed' | 'Pending' | 'Paper Trading';
  pnl: number;
  pnlPct: number;
  sharpe: number;
  maxDrawdown: number;
  winRate: number;
  trades: number;
  exposure: number;
  aiConfidence: number;
}

export interface Order {
  id: string;
  symbol: string;
  side: 'Buy' | 'Sell';
  type: 'Market' | 'Limit' | 'Stop' | 'Iceberg';
  qty: number;
  price: number;
  status: 'Filled' | 'Working' | 'Partial' | 'Cancelled' | 'Rejected';
  filled: number;
  time: string;
}

export interface ActivityItem {
  id: string;
  kind: 'signal' | 'order' | 'strategy' | 'risk' | 'system' | 'document';
  title: string;
  detail: string;
  time: string;
}

export interface WatchItem {
  symbol: string;
  name: string;
  last: number;
  changePct: number;
  volume: string;
  spark: number[];
}

export interface ReleaseItem {
  version: string;
  name: string;
  date: string;
  tag: 'feature' | 'improvement' | 'fix' | 'security';
  notes: string;
}

export interface TimelineItem {
  id: string;
  title: string;
  detail: string;
  status: 'done' | 'active' | 'planned';
  date: string;
}

export interface DocItem {
  id: string;
  name: string;
  type: 'PDF' | 'Research' | 'Notebook' | 'Report' | 'Spec';
  size: string;
  updated: string;
  author: string;
  tags: string[];
}

// ---- Portfolio snapshot
export const portfolioSummary: Metric[] = [
  { label: 'Net Liquidation', value: '$2,486,920', delta: 1.84, deltaLabel: '+$45,120', trend: 'up', hint: 'Today' },
  { label: 'Unrealized P&L', value: '+$312,540', delta: 2.41, deltaLabel: 'vs. last week', trend: 'up', hint: 'Open positions' },
  { label: 'Cash & Equivalents', value: '$184,200', delta: -0.6, deltaLabel: '-$1,100', trend: 'down', hint: '7.4% of NAV' },
  { label: 'Buying Power', value: '$612,400', delta: 0.9, deltaLabel: 'stable', trend: 'up', hint: 'Margin available' },
];

export const portfolioGrowth: number[] = [
  1980, 2010, 2055, 2038, 2090, 2124, 2160, 2198, 2185, 2240, 2286, 2310, 2298, 2352, 2390, 2412, 2388, 2440, 2486,
];

export const holdings: PortfolioHolding[] = [
  { symbol: 'NVDA', name: 'NVIDIA Corp', sector: 'Semiconductors', weight: 14.2, shares: 820, avgCost: 412.5, last: 624.3, changePct: 1.92 },
  { symbol: 'MSFT', name: 'Microsoft', sector: 'Software', weight: 11.8, shares: 560, avgCost: 380.2, last: 521.4, changePct: 0.64 },
  { symbol: 'AAPL', name: 'Apple Inc', sector: 'Consumer Tech', weight: 9.6, shares: 1120, avgCost: 184.3, last: 212.6, changePct: -0.42 },
  { symbol: 'TSM', name: 'TSMC ADR', sector: 'Semiconductors', weight: 8.4, shares: 980, avgCost: 132.1, last: 172.8, changePct: 1.34 },
  { symbol: 'GOOGL', name: 'Alphabet', sector: 'Internet', weight: 7.9, shares: 460, avgCost: 156.4, last: 198.2, changePct: 0.81 },
  { symbol: 'AMZN', name: 'Amazon', sector: 'E-commerce', weight: 6.5, shares: 380, avgCost: 142.6, last: 186.4, changePct: -1.12 },
  { symbol: 'META', name: 'Meta Platforms', sector: 'Internet', weight: 5.8, shares: 210, avgCost: 421.0, last: 498.2, changePct: 2.16 },
  { symbol: 'BTC', name: 'Bitcoin', sector: 'Digital Assets', weight: 5.2, shares: 4.2, avgCost: 61200, last: 64210, changePct: 3.42 },
];

// ---- AI Insights
export const aiSummary = {
  marketRegime: 'Risk-On',
  confidence: 78,
  sentiment: 64,
  narrative:
    'Equity breadth remains constructive with leadership rotating into semiconductors and large-cap software. Volatility is compressing while funding liquidity stays ample. Our ensemble favors modest gross long exposure with a tactical tilt toward quality momentum.',
  recommendations: [
    { id: 'r1', title: 'Trim 1.5% NVDA into strength', rationale: 'Concentration above 14% breaches portfolio limit.', impact: 'Reduces single-name risk by 18%' },
    { id: 'r2', title: 'Add TSM on pullback to $168', rationale: 'AI-capex demand outlook intact; RSI neutral.', impact: '+0.8% expected risk-adjusted return' },
    { id: 'r3', title: 'Hedge with SPY 590P (30d)', rationale: 'VIX near lows; cheap tail protection.', impact: 'Reduces 1-day 99% VaR by 22%' },
  ],
};

export const aiConfidenceSeries = [62, 64, 61, 67, 70, 69, 72, 74, 73, 76, 75, 78];

// ---- Market intelligence
export const marketStatus = {
  regime: 'Risk-On',
  vix: 13.4,
  vixChange: -0.32,
  breadth: 0.62,
  breadthChange: 0.04,
  tenYear: 4.28,
  tenYearChange: 0.03,
  dollar: 104.2,
  dollarChange: -0.18,
};

export const sectorAllocation = [
  { label: 'Semiconductors', value: 22.6, color: 'primary' },
  { label: 'Software', value: 18.4, color: 'secondary' },
  { label: 'Internet', value: 14.2, color: 'accent' },
  { label: 'Digital Assets', value: 5.2, color: 'warning' },
  { label: 'Consumer Tech', value: 9.6, color: 'success' },
  { label: 'E-commerce', value: 6.5, color: 'info' },
  { label: 'Cash & Other', value: 23.5, color: 'faint' },
] as const;

export const marketBreadth = [0.42, 0.48, 0.51, 0.46, 0.55, 0.59, 0.62];

export const watchList: WatchItem[] = [
  { symbol: 'NVDA', name: 'NVIDIA', last: 624.3, changePct: 1.92, volume: '38.2M', spark: [602, 608, 615, 611, 620, 624, 624] },
  { symbol: 'TSM', name: 'TSMC', last: 172.8, changePct: 1.34, volume: '12.1M', spark: [168, 170, 169, 171, 172, 171, 173] },
  { symbol: 'MSFT', name: 'Microsoft', last: 521.4, changePct: 0.64, volume: '21.4M', spark: [516, 518, 519, 520, 521, 520, 521] },
  { symbol: 'AAPL', name: 'Apple', last: 212.6, changePct: -0.42, volume: '48.0M', spark: [214, 213, 214, 213, 212, 213, 213] },
  { symbol: 'BTC', name: 'Bitcoin', last: 64210, changePct: 3.42, volume: '$18.2B', spark: [62000, 62400, 63100, 62800, 63800, 64100, 64210] },
  { symbol: 'ETH', name: 'Ethereum', last: 3142, changePct: 2.18, volume: '$8.4B', spark: [3060, 3080, 3110, 3090, 3130, 3140, 3142] },
  { symbol: 'GOOGL', name: 'Alphabet', last: 198.2, changePct: 0.81, volume: '19.8M', spark: [195, 196, 197, 196, 198, 197, 198] },
  { symbol: 'AMZN', name: 'Amazon', last: 186.4, changePct: -1.12, volume: '31.2M', spark: [189, 188, 187, 188, 186, 187, 186] },
];

// ---- Signals
export const recentSignals: Signal[] = [
  { id: 's1', symbol: 'TSM', strategy: 'Momentum Cascade', side: 'Long', confidence: 86, price: 172.8, time: '2026-07-25T09:42:00Z', status: 'Active' },
  { id: 's2', symbol: 'NVDA', strategy: 'AI Sector Rotation', side: 'Neutral', confidence: 71, price: 624.3, time: '2026-07-25T09:28:00Z', status: 'Acknowledged' },
  { id: 's3', symbol: 'BTC', strategy: 'Volatility Harvest', side: 'Long', confidence: 79, price: 64210, time: '2026-07-25T08:51:00Z', status: 'Executing' },
  { id: 's4', symbol: 'AMZN', strategy: 'Mean Reversion', side: 'Short', confidence: 64, price: 186.4, time: '2026-07-25T08:12:00Z', status: 'Active' },
  { id: 's5', symbol: 'XLU', strategy: 'Defensive Rotate', side: 'Neutral', confidence: 58, price: 71.2, time: '2026-07-24T16:02:00Z', status: 'Rejected' },
];

// ---- Strategies
export const strategies: Strategy[] = [
  { id: 'st1', name: 'Momentum Cascade', type: 'Trend / Momentum', status: 'Running', pnl: 84200, pnlPct: 12.4, sharpe: 1.92, maxDrawdown: -6.8, winRate: 64, trades: 142, exposure: 38, aiConfidence: 86 },
  { id: 'st2', name: 'AI Sector Rotation', type: 'Rotation', status: 'Running', pnl: 51600, pnlPct: 7.8, sharpe: 1.48, maxDrawdown: -4.2, winRate: 58, trades: 96, exposure: 24, aiConfidence: 78 },
  { id: 'st3', name: 'Volatility Harvest', type: 'Options / Vol', status: 'Paper Trading', pnl: 18420, pnlPct: 4.1, sharpe: 2.24, maxDrawdown: -3.1, winRate: 71, trades: 312, exposure: 12, aiConfidence: 81 },
  { id: 'st4', name: 'Mean Reversion FX', type: 'Stat Arb', status: 'Frozen', pnl: -12480, pnlPct: -2.3, sharpe: 0.86, maxDrawdown: -8.4, winRate: 49, trades: 218, exposure: 0, aiConfidence: 52 },
  { id: 'st5', name: 'Defensive Rotate', type: 'Macro', status: 'Pending', pnl: 0, pnlPct: 0, sharpe: 0, maxDrawdown: 0, winRate: 0, trades: 0, exposure: 0, aiConfidence: 61 },
  { id: 'st6', name: 'Liquidity Provider', type: 'Market Making', status: 'Completed', pnl: 31200, pnlPct: 5.2, sharpe: 2.81, maxDrawdown: -1.9, winRate: 73, trades: 4820, exposure: 0, aiConfidence: 88 },
];

// ---- Orders
export const orders: Order[] = [
  { id: 'O-20481', symbol: 'TSM', side: 'Buy', type: 'Limit', qty: 300, price: 172.8, status: 'Working', filled: 0, time: '2026-07-25T09:42:00Z' },
  { id: 'O-20480', symbol: 'NVDA', side: 'Sell', type: 'Limit', qty: 120, price: 624.3, status: 'Partial', filled: 48, time: '2026-07-25T09:28:00Z' },
  { id: 'O-20479', symbol: 'BTC', side: 'Buy', type: 'Market', qty: 1.2, price: 64210, status: 'Filled', filled: 1.2, time: '2026-07-25T08:51:00Z' },
  { id: 'O-20478', symbol: 'AMZN', side: 'Sell', type: 'Stop', qty: 200, price: 186.4, status: 'Working', filled: 0, time: '2026-07-25T08:12:00Z' },
  { id: 'O-20477', symbol: 'META', side: 'Buy', type: 'Iceberg', qty: 80, price: 498.2, status: 'Partial', filled: 22, time: '2026-07-24T16:02:00Z' },
  { id: 'O-20476', symbol: 'XLU', side: 'Buy', type: 'Limit', qty: 400, price: 71.2, status: 'Cancelled', filled: 0, time: '2026-07-24T15:40:00Z' },
  { id: 'O-20475', symbol: 'GOOGL', side: 'Sell', type: 'Market', qty: 60, price: 198.2, status: 'Filled', filled: 60, time: '2026-07-24T15:10:00Z' },
];

// ---- Risk
export const riskOverview = {
  var95: 38400,
  var99: 62800,
  varChange: -8.2,
  sharpe: 1.84,
  sortino: 2.41,
  maxDrawdown: -8.4,
  beta: 1.12,
  correlation: 0.78,
  concentrationHHI: 0.11,
  grossLeverage: 1.24,
  netLeverage: 0.86,
  riskBudgetUsed: 64,
};

export const riskTrend = [72, 70, 68, 66, 64, 62, 60, 58, 57, 55, 54, 52, 51, 50];

export const riskHeatmap: [string, number, Tone][] = [
  ['Equity', 38, 'primary'],
  ['Crypto', 12, 'warning'],
  ['FX', 8, 'accent'],
  ['Rates', 6, 'info'],
  ['Commodity', 4, 'success'],
  ['Credit', 2, 'secondary'],
];

// ---- Activity feed
export const recentActivity: ActivityItem[] = [
  { id: 'a1', kind: 'signal', title: 'New signal: Long TSM @ 172.80', detail: 'Momentum Cascade · 86% confidence', time: '2026-07-25T09:42:00Z' },
  { id: 'a2', kind: 'order', title: 'Order O-20479 filled', detail: 'Buy 1.2 BTC @ 64,210 (Market)', time: '2026-07-25T08:51:00Z' },
  { id: 'a3', kind: 'strategy', title: 'Volatility Harvest moved to Paper Trading', detail: 'Live trading paused for review', time: '2026-07-25T08:10:00Z' },
  { id: 'a4', kind: 'risk', title: 'VaR (1d, 99%) reduced to $62,800', detail: 'Down 8.2% week-over-week', time: '2026-07-24T18:02:00Z' },
  { id: 'a5', kind: 'document', title: 'Q3 Risk Budget Spec uploaded', detail: 'by A. Mehta · 1.4 MB', time: '2026-07-24T16:30:00Z' },
  { id: 'a6', kind: 'system', title: 'AI model ensemble retrained', detail: 'v4.2.1 · Sharpe improved 0.04', time: '2026-07-24T02:00:00Z' },
];

// ---- Timeline / projects
export const projectTimeline: TimelineItem[] = [
  { id: 't1', title: 'Multi-asset risk engine v2', detail: 'Real-time VaR across all desks', status: 'done', date: '2026-06-28' },
  { id: 't2', title: 'AI ensemble v4.2', detail: 'Transformer + gradient boosting fusion', status: 'active', date: '2026-07-25' },
  { id: 't3', title: 'Options vol surface builder', detail: 'Live IV surface with skew analytics', status: 'active', date: '2026-08-02' },
  { id: 't4', title: 'Cross-venue execution router', detail: 'Smart order routing across 7 venues', status: 'planned', date: '2026-08-20' },
  { id: 't5', title: 'Compliance reporting suite', detail: 'MiFID II + SEC 13F automation', status: 'planned', date: '2026-09-10' },
];

// ---- Documents
export const documents: DocItem[] = [
  { id: 'd1', name: 'Q3 Risk Budget Specification', type: 'Spec', size: '1.4 MB', updated: '2026-07-24T16:30:00Z', author: 'A. Mehta', tags: ['risk', 'governance'] },
  { id: 'd2', name: 'AI Ensemble Model Card', type: 'Research', size: '880 KB', updated: '2026-07-24T02:00:00Z', author: 'R. Chen', tags: ['ai', 'models'] },
  { id: 'd3', name: 'Sector Rotation Backtest', type: 'Notebook', size: '3.2 MB', updated: '2026-07-22T11:14:00Z', author: 'L. Park', tags: ['strategy', 'backtest'] },
  { id: 'd4', name: 'Monthly Performance Report — June', type: 'Report', size: '2.1 MB', updated: '2026-07-01T09:00:00Z', author: 'Finance', tags: ['performance', 'monthly'] },
  { id: 'd5', name: 'Execution Quality Analysis', type: 'PDF', size: '640 KB', updated: '2026-06-29T14:20:00Z', author: 'J. Ortiz', tags: ['execution', 'slippage'] },
  { id: 'd6', name: 'Volatility Regime Study', type: 'Research', size: '1.1 MB', updated: '2026-06-26T10:48:00Z', author: 'R. Chen', tags: ['vol', 'regime'] },
];

// ---- Releases
export const releases: ReleaseItem[] = [
  { version: 'v4.2.1', name: 'Ensemble retrain + risk budget tuning', date: '2026-07-24', tag: 'feature', notes: 'Transformer gradient fusion, 22% lower VaR, new risk budget guardrails.' },
  { version: 'v4.2.0', name: 'Options analytics suite', date: '2026-07-18', tag: 'feature', notes: 'Live IV surfaces, Greeks dashboard, skew alerts.' },
  { version: 'v4.1.4', name: 'Execution router latency', date: '2026-07-12', tag: 'improvement', notes: 'Median round-trip down to 1.8ms across venues.' },
  { version: 'v4.1.3', name: 'Order state machine hardening', date: '2026-07-05', tag: 'fix', notes: 'Resolves rare partial-fill race in Iceberg orders.' },
  { version: 'v4.1.2', name: 'API key rotation policy', date: '2026-06-28', tag: 'security', notes: 'Mandatory 90-day key rotation and scoped tokens.' },
];

// ---- Quick actions
export const quickActions = [
  { id: 'qa1', label: 'New Order', hint: 'Place a trade', icon: 'Plus' },
  { id: 'qa2', label: 'Run Strategy', hint: 'Start or schedule', icon: 'Play' },
  { id: 'qa3', label: 'Risk Check', hint: 'Pre-trade review', icon: 'Shield' },
  { id: 'qa4', label: 'AI Ask', hint: 'Query the assistant', icon: 'Sparkles' },
  { id: 'qa5', label: 'Report', hint: 'Export snapshot', icon: 'FileText' },
] as const;

// ---- Strategy health sparklines
export const strategyHealthSeries: Record<string, number[]> = {
  st1: [40, 44, 48, 52, 58, 62, 70, 78, 84],
  st2: [30, 33, 36, 40, 44, 50, 55, 60, 64],
  st3: [20, 24, 28, 34, 40, 46, 52, 58, 62],
  st4: [60, 58, 55, 52, 50, 48, 46, 44, 42],
};

export const strategyPerformance = [10, 14, 12, 18, 22, 19, 26, 31, 28, 34, 38, 42];

// ---- Capital allocation
export const capitalAllocation = [
  { label: 'Deployed', value: 64, color: 'primary' },
  { label: 'Reserve', value: 22, color: 'accent' },
  { label: 'Hedges', value: 9, color: 'secondary' },
  { label: 'Cash', value: 5, color: 'faint' },
] as const;

export const pnlContribution = [
  { label: 'Mon', value: 4200 },
  { label: 'Tue', value: -1800 },
  { label: 'Wed', value: 6400 },
  { label: 'Thu', value: 3100 },
  { label: 'Fri', value: 12800 },
  { label: 'Sat', value: 600 },
  { label: 'Sun', value: 2400 },
];
