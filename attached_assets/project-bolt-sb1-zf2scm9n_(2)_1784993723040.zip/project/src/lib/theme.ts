// Maps semantic color tokens (used in demo data) to Tailwind class fragments.

export type Tone = 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'faint';

export const toneText: Record<Tone, string> = {
  primary: 'text-primary',
  secondary: 'text-secondary',
  accent: 'text-accent',
  success: 'text-success',
  warning: 'text-warning',
  danger: 'text-danger',
  info: 'text-info',
  faint: 'text-faint',
};

export const toneBg: Record<Tone, string> = {
  primary: 'bg-primary',
  secondary: 'bg-secondary',
  accent: 'bg-accent',
  success: 'bg-success',
  warning: 'bg-warning',
  danger: 'bg-danger',
  info: 'bg-info',
  faint: 'bg-faint',
};

export const toneSoftBg: Record<Tone, string> = {
  primary: 'bg-primary/12',
  secondary: 'bg-secondary/15',
  accent: 'bg-accent/12',
  success: 'bg-success/12',
  warning: 'bg-warning/12',
  danger: 'bg-danger/12',
  info: 'bg-info/12',
  faint: 'bg-faint/12',
};

export const toneRing: Record<Tone, string> = {
  primary: 'ring-primary/40',
  secondary: 'ring-secondary/40',
  accent: 'ring-accent/40',
  success: 'ring-success/40',
  warning: 'ring-warning/40',
  danger: 'ring-danger/40',
  info: 'ring-info/40',
  faint: 'ring-faint/40',
};

// Resolve a color token to an rgb() string usable inside SVG / charts.
export function toneRgb(tone: Tone): string {
  const map: Record<Tone, string> = {
    primary: 'rgb(var(--color-primary))',
    secondary: 'rgb(var(--color-secondary))',
    accent: 'rgb(var(--color-accent))',
    success: 'rgb(var(--color-success))',
    warning: 'rgb(var(--color-warning))',
    danger: 'rgb(var(--color-danger))',
    info: 'rgb(var(--color-info))',
    faint: 'rgb(var(--color-faint))',
  };
  return map[tone];
}

export function toneRgbSoft(tone: Tone, alpha = 0.18): string {
  const map: Record<Tone, string> = {
    primary: `rgb(var(--color-primary) / ${alpha})`,
    secondary: `rgb(var(--color-secondary) / ${alpha})`,
    accent: `rgb(var(--color-accent) / ${alpha})`,
    success: `rgb(var(--color-success) / ${alpha})`,
    warning: `rgb(var(--color-warning) / ${alpha})`,
    danger: `rgb(var(--color-danger) / ${alpha})`,
    info: `rgb(var(--color-info) / ${alpha})`,
    faint: `rgb(var(--color-faint) / ${alpha})`,
  };
  return map[tone];
}
