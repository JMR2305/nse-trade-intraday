import {
  LayoutDashboard,
  Brain,
  Wallet,
  LineChart,
  Target,
  ShoppingCart,
  ShieldAlert,
  FileText,
  Settings,
  UserCircle,
} from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon: typeof LayoutDashboard;
  group: 'Workspace' | 'Markets' | 'System';
}

export const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, group: 'Workspace' },
  { id: 'ai-insights', label: 'AI Insights', icon: Brain, group: 'Workspace' },
  { id: 'portfolio', label: 'Portfolio', icon: Wallet, group: 'Workspace' },
  { id: 'strategies', label: 'Strategies', icon: Target, group: 'Workspace' },
  { id: 'orders', label: 'Orders', icon: ShoppingCart, group: 'Workspace' },
  { id: 'market-watch', label: 'Market Watch', icon: LineChart, group: 'Markets' },
  { id: 'trading', label: 'Trading', icon: LineChart, group: 'Markets' },
  { id: 'risk-center', label: 'Risk Center', icon: ShieldAlert, group: 'Markets' },
  { id: 'documents', label: 'Documents', icon: FileText, group: 'System' },
  { id: 'settings', label: 'Settings', icon: Settings, group: 'System' },
  { id: 'profile', label: 'Profile', icon: UserCircle, group: 'System' },
];

export const pageMeta: Record<string, { title: string; subtitle: string }> = {
  dashboard: { title: 'Command Center', subtitle: 'Real-time portfolio, signals and market intelligence' },
  'ai-insights': { title: 'AI Insights', subtitle: 'Ensemble intelligence, regime detection and recommendations' },
  portfolio: { title: 'Portfolio', subtitle: 'Holdings, allocation and performance attribution' },
  strategies: { title: 'Strategies', subtitle: 'Strategy health, performance and deployment' },
  orders: { title: 'Orders', subtitle: 'Live blotter, fills and execution analytics' },
  'market-watch': { title: 'Market Watch', subtitle: 'Live watchlist, breadth and cross-asset monitors' },
  trading: { title: 'Trading', subtitle: 'Order ticket, positions and execution routing' },
  'risk-center': { title: 'Risk Center', subtitle: 'Value at risk, exposures and limits' },
  documents: { title: 'Documents', subtitle: 'Research, specs, reports and notebooks' },
  settings: { title: 'Settings', subtitle: 'Workspace, connectivity and preferences' },
  profile: { title: 'Profile', subtitle: 'Account, team and API access' },
};
