"""
Batch 8 — Risk Engine.

Production-ready risk management layer for the NSE Paper Trading Platform.
Sits between the Strategy Layer and the Execution Engine (RC-7).

Provides:
- Pre-trade risk checks: order size, price tolerance, position limits,
  portfolio exposure, daily loss limits, message throttling, duplicate
  order prevention, self-trade prevention
- Post-trade risk checks: portfolio heat, drawdown, turnover velocity
- Kill switch: emergency trading halt with audit trail
- Deterministic, idempotent, async-safe evaluation
- Full persistence support via repository pattern
"""

from .contracts import (
    RiskSeverity,
    RiskCheckType,
    RiskViolation,
    RiskResult,
    RiskRequest,
    RiskContext,
    RiskConfiguration,
    OrderQuantityLimit,
    OrderValueLimit,
    TickSizeLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    InstrumentExposureLimit,
    NetExposureLimit,
    ConcentrationLimit,
    CashAvailabilityLimit,
    BuyingPowerLimit,
    PortfolioExposureLimit,
    MarginAvailabilityLimit,
    DailyLossLimit,
    DailyProfitTargetLock,
    MaxTradesPerDayLimit,
    MaxOrdersPerMinuteLimit,
    KillSwitchLimit,
    EmergencyHaltLimit,
    CircuitBreakerLimit,
    DuplicateOrderLimit,
    SelfTradeLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
    RiskStateSnapshot,
    RiskAudit,
)

from .rules import (
    RiskRule,
    OrderQuantityRule,
    OrderValueRule,
    TickSizeRule,
    PriceBandRule,
    MaxPositionSizeRule,
    InstrumentExposureRule,
    NetExposureRule,
    ConcentrationRule,
    CashAvailabilityRule,
    BuyingPowerRule,
    PortfolioExposureRule,
    MarginAvailabilityRule,
    DailyLossLimitRule,
    DailyProfitTargetLockRule,
    MaxTradesPerDayRule,
    MaxOrdersPerMinuteRule,
    KillSwitchRule,
    EmergencyHaltRule,
    CircuitBreakerRule,
    DuplicateOrderRule,
    SelfTradeRule,
    DrawdownRule,
    TurnoverVelocityRule,
    RULE_REGISTRY,
)

from .state import RiskState
from .kill_switch import KillSwitch, KillSwitchEvent
from .engine import RiskEngine
try:
    from .persistence import RiskEnginePersistenceAdapter
except ImportError:
    # Persistence adapter not available in this context;
    # the project retains its own implementation.
    RiskEnginePersistenceAdapter = None  # type: ignore
from .exceptions import (
    RiskEngineException,
    RiskLimitNotFoundError,
    RiskStateCorruptionError,
    RiskCheckError,
    KillSwitchAlreadyActiveError,
    KillSwitchNotActiveError,
    AccountNotRegisteredError,
    FillDeliveryError,
)

__all__ = [
    # Contracts
    "RiskSeverity",
    "RiskCheckType",
    "RiskViolation",
    "RiskResult",
    "RiskRequest",
    "RiskContext",
    "RiskConfiguration",
    "OrderQuantityLimit",
    "OrderValueLimit",
    "TickSizeLimit",
    "PriceBandLimit",
    "MaxPositionSizeLimit",
    "InstrumentExposureLimit",
    "NetExposureLimit",
    "ConcentrationLimit",
    "CashAvailabilityLimit",
    "BuyingPowerLimit",
    "PortfolioExposureLimit",
    "MarginAvailabilityLimit",
    "DailyLossLimit",
    "DailyProfitTargetLock",
    "MaxTradesPerDayLimit",
    "MaxOrdersPerMinuteLimit",
    "KillSwitchLimit",
    "EmergencyHaltLimit",
    "CircuitBreakerLimit",
    "DuplicateOrderLimit",
    "SelfTradeLimit",
    "DrawdownLimit",
    "TurnoverVelocityLimit",
    "RiskStateSnapshot",
    "RiskAudit",
    # Rules
    "RiskRule",
    "OrderQuantityRule",
    "OrderValueRule",
    "TickSizeRule",
    "PriceBandRule",
    "MaxPositionSizeRule",
    "InstrumentExposureRule",
    "NetExposureRule",
    "ConcentrationRule",
    "CashAvailabilityRule",
    "BuyingPowerRule",
    "PortfolioExposureRule",
    "MarginAvailabilityRule",
    "DailyLossLimitRule",
    "DailyProfitTargetLockRule",
    "MaxTradesPerDayRule",
    "MaxOrdersPerMinuteRule",
    "KillSwitchRule",
    "EmergencyHaltRule",
    "CircuitBreakerRule",
    "DuplicateOrderRule",
    "SelfTradeRule",
    "DrawdownRule",
    "TurnoverVelocityRule",
    "RULE_REGISTRY",
    # Engine
    "RiskState",
    "KillSwitch",
    "KillSwitchEvent",
    "RiskEngine",
    "RiskEnginePersistenceAdapter",
    "FillDeliveryError",
    # Exceptions
    "RiskEngineException",
    "RiskLimitNotFoundError",
    "RiskStateCorruptionError",
    "RiskCheckError",
    "KillSwitchAlreadyActiveError",
    "KillSwitchNotActiveError",
    "AccountNotRegisteredError",
    "FillDeliveryError",
]
