"""
Risk Engine — main orchestrator for pre-trade and post-trade risk checks.

The RiskEngine sits between the Strategy Layer and the Execution Engine.
It evaluates orders before they reach execution (pre-trade) and monitors
portfolio state after fills (post-trade).

The engine is:
- Deterministic: same inputs always produce same outputs
- Idempotent: re-checking the same order yields same result
- Async-safe: per-account locking
- Stateless in evaluation: all mutable state lives in RiskState
"""

from __future__ import annotations

from decimal import Decimal
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import asyncio
import logging
import uuid

from .contracts import (
    RiskResult,
    RiskViolation,
    RiskCheckType,
    RiskSeverity,
    RiskConfiguration,
    RiskStateSnapshot,
    RiskRequest,
    RiskContext,
    MaxOrdersPerMinuteLimit,
    KillSwitchLimit,
    EmergencyHaltLimit,
    CircuitBreakerLimit,
)
from .rules import RULE_REGISTRY, DuplicateOrderRule
from .state import RiskState
from .kill_switch import KillSwitch

logger = logging.getLogger(__name__)


class RiskEngine:
    """Central risk evaluation engine.

    The RiskEngine maintains a RiskState per account and evaluates all
    configured risk rules on every order submission (pre-trade) and
    portfolio update (post-trade).

    Attributes:
        _states: Dict of account_id -> RiskState.
        _kill_switches: Dict of account_id -> KillSwitch.
        _limits: Dict of account_id -> List[RiskConfiguration].
        _pre_trade_types: Set of RiskCheckType evaluated pre-trade.
        _post_trade_types: Set of RiskCheckType evaluated post-trade.
        _lock: Global lock for state mutations (per-account locks inside RiskState).
    """

    PRE_TRADE_CHECKS = {
        RiskCheckType.ORDER_QUANTITY,
        RiskCheckType.ORDER_VALUE,
        RiskCheckType.TICK_SIZE,
        RiskCheckType.PRICE_BAND,
        RiskCheckType.MAX_POSITION_SIZE,
        RiskCheckType.INSTRUMENT_EXPOSURE,
        RiskCheckType.NET_EXPOSURE,
        RiskCheckType.CONCENTRATION_LIMIT,
        RiskCheckType.CASH_AVAILABILITY,
        RiskCheckType.BUYING_POWER,
        RiskCheckType.PORTFOLIO_EXPOSURE,
        RiskCheckType.MARGIN_AVAILABILITY,
        RiskCheckType.DAILY_LOSS_LIMIT,
        RiskCheckType.DAILY_PROFIT_TARGET_LOCK,
        RiskCheckType.MAX_TRADES_PER_DAY,
        RiskCheckType.MAX_ORDERS_PER_MINUTE,
        RiskCheckType.KILL_SWITCH,
        RiskCheckType.EMERGENCY_HALT,
        RiskCheckType.CIRCUIT_BREAKER,
        RiskCheckType.DUPLICATE_ORDER,
        RiskCheckType.SELF_TRADE,
    }

    POST_TRADE_CHECKS = {
        RiskCheckType.CONCENTRATION_LIMIT,
        RiskCheckType.PORTFOLIO_EXPOSURE,
        RiskCheckType.DRAWDOWN,
        RiskCheckType.TURNOVER_VELOCITY,
    }

    def __init__(
        self,
        limits: Optional[Dict[str, List[RiskConfiguration]]] = None,
        allow_risk_reducing_on_kill: bool = False,
    ):
        self._states: Dict[str, RiskState] = {}
        self._kill_switches: Dict[str, KillSwitch] = {}
        self._limits: Dict[str, List[RiskConfiguration]] = limits or {}
        self._allow_risk_reducing_on_kill: bool = allow_risk_reducing_on_kill
        self._lock: asyncio.Lock = asyncio.Lock()
        # Per-engine rule instances to avoid shared mutable state across tests/engine instances
        self._rule_instances: Dict[RiskCheckType, Any] = dict(RULE_REGISTRY)
        self._seen_fill_ids: Dict[str, set] = {}
        self._rule_instances[RiskCheckType.DUPLICATE_ORDER] = DuplicateOrderRule()

    async def register_account(
        self,
        account_id: str,
        initial_equity: Decimal = Decimal("0"),
        limits: Optional[List[RiskConfiguration]] = None,
    ) -> None:
        """Register a new account with the risk engine.

        Args:
            account_id: Unique account identifier.
            initial_equity: Starting equity for the account.
            limits: Risk limits for this account (optional, can be set later).
        """
        async with self._lock:
            if account_id not in self._states:
                self._states[account_id] = RiskState(account_id, initial_equity)
                self._kill_switches[account_id] = KillSwitch(
                    account_id,
                    allow_risk_reducing=self._allow_risk_reducing_on_kill,
                )
                logger.info(f"Registered account {account_id} with equity {initial_equity}")
            if limits is not None:
                self._limits[account_id] = limits

    async def set_limits(self, account_id: str, limits: List[RiskConfiguration]) -> None:
        """Set or update risk limits for an account."""
        async with self._lock:
            self._limits[account_id] = limits
            logger.info(f"Updated limits for account {account_id}: {len(limits)} rules")

    async def pre_trade_check(
        self,
        account_id: str,
        order: Any,
        portfolio_snapshot: Optional[Any] = None,
        position_snapshots: Optional[Dict[str, Any]] = None,
        market_prices: Optional[Dict[str, Decimal]] = None,
        open_orders: Optional[List[Any]] = None,
        check_timestamp: Optional[datetime] = None,
    ) -> RiskResult:
        """Evaluate pre-trade risk checks for an order.

        This is the primary entry point for order validation before
        submission to the execution engine.

        Args:
            account_id: Account submitting the order.
            order: The order to evaluate.
            portfolio_snapshot: Current PortfolioSnapshot (optional).
            position_snapshots: Dict of instrument -> PositionSnapshot (optional).
            market_prices: Dict of instrument_token -> LTP (optional).
            open_orders: List of currently open orders (optional).
            check_timestamp: Timestamp for this check (default: utcnow).

        Returns:
            RiskResult with approval status and any violations.
        """
        if check_timestamp is None:
            check_timestamp = datetime.now(timezone.utc)

        # Ensure account is registered
        if account_id not in self._states:
            await self.register_account(account_id)

        state = self._states[account_id]
        kill_switch = self._kill_switches[account_id]
        limits = self._limits.get(account_id, [])

        # Build request and context
        request = RiskRequest(
            account_id=account_id,
            order=order,
            check_timestamp=check_timestamp,
        )
        context = RiskContext(
            account_id=account_id,
            portfolio_snapshot=portfolio_snapshot,
            position_snapshots=position_snapshots or {},
            market_prices=market_prices or {},
            open_orders=open_orders or [],
            order=order,
        )

        # Get snapshot under lock
        state_snapshot = await state.to_snapshot_locked(check_timestamp)

        violations: List[RiskViolation] = []

        # 1. Kill switch is evaluated exclusively through KillSwitchRule in the
        #    rule loop below (avoids duplicate KILL_SWITCH violations).
        #    The KillSwitch object is still used for manual activation/deactivation
        #    and audit history, but the rule handles the pre-trade block.

        # 2. Evaluate all pre-trade rules
        # (throttle counter is recorded AFTER evaluation so a limit of N
        # orders/minute permits exactly N orders; the rule compares the
        # count of PRIOR orders in the window against the limit)
        for config in limits:
            check_type = config.check_type
            if check_type not in self.PRE_TRADE_CHECKS:
                continue

            rule = self._rule_instances.get(check_type)
            if rule is None:
                continue

            # Re-fetch state snapshot after throttle recording
            state_snapshot = state.to_snapshot(check_timestamp)

            try:
                violation = rule.evaluate(request, context, config, state_snapshot)
                if violation is not None:
                    violations.append(violation)
                    logger.info(f"Pre-trade violation: {violation.check_type} - {violation.message}")
            except Exception as e:
                logger.error(f"Rule {check_type} evaluation error: {e}", exc_info=True)
                violations.append(RiskViolation(
                    check_type=check_type,
                    severity=RiskSeverity.FATAL,
                    message=f"Risk check internal error: {e}",
                    rule_id=config.rule_id,
                    metadata={"error": str(e)},
                ))

        # Record this order in the throttle window after evaluation
        await self._record_message_throttle(state, context, limits, check_timestamp)

        # 4. Determine approval based on violations
        approved = not any(
            v.severity in (RiskSeverity.CRITICAL, RiskSeverity.FATAL)
            for v in violations
        )

        # 5. Auto-activate kill switch on FATAL violations
        if any(v.severity == RiskSeverity.FATAL for v in violations) and not kill_switch.is_active:
            fatal_reasons = [v.message for v in violations if v.severity == RiskSeverity.FATAL]
            reason = "; ".join(fatal_reasons) if fatal_reasons else "Risk limit breached"
            kill_switch.activate(reason, actor="risk_engine", timestamp=check_timestamp)
            await state.activate_kill_switch(reason)
            logger.critical(f"Auto-activated kill switch for {account_id}: {reason}")

        result = RiskResult(
            approved=approved,
            violations=violations,
            check_timestamp=check_timestamp,
            order_id=self._get_order_id(order),
            account_id=account_id,
        )

        logger.info(f"Pre-trade check for {account_id}: approved={approved}, violations={len(violations)}")
        return result

    async def post_trade_check(
        self,
        account_id: str,
        portfolio_snapshot: Any,
        position_snapshots: Dict[str, Any],
        check_timestamp: Optional[datetime] = None,
    ) -> RiskResult:
        """Evaluate post-trade risk checks after fills.

        Args:
            account_id: Account to evaluate.
            portfolio_snapshot: Current PortfolioSnapshot.
            position_snapshots: Dict of instrument -> PositionSnapshot.
            check_timestamp: Timestamp for this check.

        Returns:
            RiskResult with any post-trade violations (typically WARN-level).
        """
        if check_timestamp is None:
            check_timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            await self.register_account(account_id)

        state = self._states[account_id]
        limits = self._limits.get(account_id, [])

        request = RiskRequest(
            account_id=account_id,
            order=None,
            check_timestamp=check_timestamp,
        )
        context = RiskContext(
            account_id=account_id,
            portfolio_snapshot=portfolio_snapshot,
            position_snapshots=position_snapshots,
            market_prices={},
            open_orders=[],
            order=None,
        )

        state_snapshot = await state.to_snapshot_locked(check_timestamp)

        violations: List[RiskViolation] = []

        for config in limits:
            check_type = config.check_type
            if check_type not in self.POST_TRADE_CHECKS:
                continue

            rule = self._rule_instances.get(check_type)
            if rule is None:
                continue

            try:
                violation = rule.evaluate(request, context, config, state_snapshot)
                if violation is not None:
                    # Post-trade: downgrade CRITICAL/FATAL to WARNING for monitoring only
                    if violation.severity in (RiskSeverity.CRITICAL, RiskSeverity.FATAL):
                        violation = RiskViolation(
                            check_type=violation.check_type,
                            severity=RiskSeverity.WARNING,
                            message=f"[POST-TRADE] {violation.message}",
                            rule_id=violation.rule_id,
                            limit_value=violation.limit_value,
                            actual_value=violation.actual_value,
                            metadata=violation.metadata,
                        )
                    violations.append(violation)
                    logger.info(f"Post-trade violation: {violation.check_type} - {violation.message}")
            except Exception as e:
                logger.error(f"Post-trade rule {check_type} evaluation error: {e}", exc_info=True)

        # Post-trade checks never block — the fill already happened
        approved = True

        result = RiskResult(
            approved=approved,
            violations=violations,
            check_timestamp=check_timestamp,
            order_id=None,
            account_id=account_id,
        )

        logger.info(f"Post-trade check for {account_id}: violations={len(violations)}")
        return result

    async def record_fill(
        self,
        account_id: str,
        fill_id: str,
        realized_pnl: Decimal,
        turnover: Decimal,
        current_equity: Decimal,
        fill_timestamp: Optional[datetime] = None,
    ) -> None:
        """Record a fill event to update risk state.

        Must be called after every fill to keep risk state synchronized
        with the execution engine. Idempotent: duplicate fill_ids are
        silently ignored to support exactly-once delivery.

        Args:
            account_id: Account that received the fill.
            fill_id: Unique identifier for this fill event.
            realized_pnl: Realized P&L from the fill.
            turnover: Turnover value of the fill.
            current_equity: Current portfolio equity after the fill.
            fill_timestamp: When the fill occurred.
        """
        if fill_timestamp is None:
            fill_timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            await self.register_account(account_id)

        # Idempotency: deduplicate by fill_id
        if account_id not in self._seen_fill_ids:
            self._seen_fill_ids[account_id] = set()
        if fill_id in self._seen_fill_ids[account_id]:
            logger.warning(f"Duplicate fill_id {fill_id} ignored for {account_id}")
            return
        self._seen_fill_ids[account_id].add(fill_id)

        state = self._states[account_id]
        await state.record_fill(realized_pnl, turnover, current_equity, fill_timestamp)
        logger.info(f"Recorded fill for {account_id}: PnL={realized_pnl}, Turnover={turnover}, fill_id={fill_id}")
    async def activate_kill_switch(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Manually activate the kill switch for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._kill_switches:
            await self.register_account(account_id)

        kill_switch = self._kill_switches[account_id]
        state = self._states[account_id]

        try:
            kill_switch.activate(reason, actor=actor, timestamp=timestamp)
        except Exception:
            pass  # Already active
        await state.activate_kill_switch(reason)
        logger.critical(f"Kill switch activated for {account_id} by {actor}: {reason}")

    async def deactivate_kill_switch(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Manually deactivate the kill switch for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._kill_switches:
            return

        kill_switch = self._kill_switches[account_id]
        state = self._states[account_id]

        try:
            kill_switch.deactivate(reason, actor=actor, timestamp=timestamp)
        except Exception:
            pass  # Not active
        await state.deactivate_kill_switch()
        logger.info(f"Kill switch deactivated for {account_id} by {actor}: {reason}")

    async def activate_emergency_halt(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Manually activate emergency halt for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            await self.register_account(account_id)

        state = self._states[account_id]
        await state.activate_emergency_halt(reason)
        logger.critical(f"Emergency halt activated for {account_id} by {actor}: {reason}")

    async def deactivate_emergency_halt(
        self,
        account_id: str,
        reason: str,
        actor: str = "manual",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Manually deactivate emergency halt for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            return

        state = self._states[account_id]
        await state.deactivate_emergency_halt()
        logger.info(f"Emergency halt deactivated for {account_id} by {actor}: {reason}")

    async def trigger_circuit_breaker(
        self,
        account_id: str,
        reason: str = "Portfolio decline threshold breached",
        actor: str = "system",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Manually trigger circuit breaker for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            await self.register_account(account_id)

        state = self._states[account_id]
        await state.trigger_circuit_breaker()
        logger.critical(f"Circuit breaker triggered for {account_id} by {actor}: {reason}")

    async def reset_circuit_breaker(
        self,
        account_id: str,
        reason: str = "Start of new trading day",
        actor: str = "system",
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Reset circuit breaker for an account."""
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)

        if account_id not in self._states:
            return

        state = self._states[account_id]
        await state.reset_circuit_breaker()
        logger.info(f"Circuit breaker reset for {account_id} by {actor}: {reason}")

    async def get_state_snapshot(self, account_id: str) -> RiskStateSnapshot:
        """Get current risk state snapshot for an account."""
        if account_id not in self._states:
            await self.register_account(account_id)

        state = self._states[account_id]
        return await state.to_snapshot_locked(datetime.now(timezone.utc))

    async def reset_account(self, account_id: str, initial_equity: Decimal = Decimal("0")) -> None:
        """Reset daily counters for an account (e.g., start of new trading day)."""
        if account_id in self._states:
            await self._states[account_id].reset_daily(initial_equity)
            logger.info(f"Reset daily counters for {account_id}")

    def get_kill_switch_history(self, account_id: str) -> List[Any]:
        """Get kill switch activation history for an account."""
        if account_id not in self._kill_switches:
            return []
        return self._kill_switches[account_id].get_history()

    def is_kill_switch_active(self, account_id: str) -> bool:
        """Check if kill switch is active for an account."""
        if account_id not in self._kill_switches:
            return False
        return self._kill_switches[account_id].is_active

    def is_emergency_halt_active(self, account_id: str) -> bool:
        """Check if emergency halt is active for an account."""
        if account_id not in self._states:
            return False
        return self._states[account_id].emergency_halt_active

    def is_circuit_breaker_triggered(self, account_id: str) -> bool:
        """Check if circuit breaker is triggered for an account."""
        if account_id not in self._states:
            return False
        return self._states[account_id].circuit_breaker_triggered

    def reset(self) -> None:
        """Reset all engine state — used for deterministic replay testing."""
        self._states.clear()
        self._kill_switches.clear()
        # Reset per-engine rule instances with mutable state
        dup_rule = self._rule_instances.get(RiskCheckType.DUPLICATE_ORDER)
        if dup_rule is not None:
            dup_rule.reset()
        self._seen_fill_ids.clear()
        logger.info("RiskEngine state reset")

    # --- Private helpers ---

    async def _record_message_throttle(
        self,
        state: RiskState,
        context: RiskContext,
        limits: List[RiskConfiguration],
        now: datetime,
    ) -> None:
        """Record message count for throttle limits before evaluation."""
        from .rules import MaxOrdersPerMinuteRule

        for config in limits:
            if isinstance(config, MaxOrdersPerMinuteLimit) and config.enabled:
                rule = MaxOrdersPerMinuteRule()
                key = rule._build_throttle_key(context, config)
                if key is not None:
                    await state.record_message(key, config.window_seconds, now)

    @staticmethod
    def _get_order_side(order: Any) -> str:
        if isinstance(order, dict):
            return (order.get("side") or "BUY").upper()
        side = getattr(order, "side", "BUY")
        return str(side).upper()

    @staticmethod
    def _get_order_id(order: Any) -> Optional[str]:
        if isinstance(order, dict):
            return order.get("order_id") or order.get("client_order_id")
        return getattr(order, "order_id", None) or getattr(order, "client_order_id", None)

    @staticmethod
    def _get_current_direction(order: Any, positions: Optional[Dict[str, Any]]) -> str:
        if positions is None:
            return "FLAT"

        instrument = None
        if isinstance(order, dict):
            instrument = order.get("instrument_token")
        else:
            instrument = getattr(order, "instrument_token", None)

        if instrument is None:
            return "FLAT"

        pos = positions.get(instrument)
        if pos is None:
            return "FLAT"

        if isinstance(pos, dict):
            return (pos.get("direction") or "FLAT").upper()
        return str(getattr(pos, "direction", "FLAT")).upper()