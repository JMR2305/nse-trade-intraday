"""
Fill Event Bus — decouples Execution Engine from Risk Engine.

The Execution Engine publishes fill events; the Risk Engine subscribes.
This avoids circular dependencies between the two engines.

Usage:
    bus = FillEventBus()

    # Risk Engine subscribes
    bus.subscribe(risk_integration.on_fill_event)

    # Execution Engine publishes (after every fill)
    await bus.publish(account_id, fill_id, realized_pnl, turnover, current_equity)
"""

from __future__ import annotations

from decimal import Decimal
from typing import List, Callable, Optional, Any
from datetime import datetime, timezone
import asyncio
import logging

logger = logging.getLogger(__name__)


FillEventCallback = Callable[..., Any]


class FillEventBus:
    """Simple async event bus for fill notifications.

    Guarantees exactly-once delivery semantics:
    - Publishers must provide a unique fill_id per fill event.
    - Subscribers are responsible for deduplication via fill_id.
    - Subscriber failures are propagated (not swallowed) so callers can retry.
    """

    def __init__(self):
        self._subscribers: List[FillEventCallback] = []
        self._lock: asyncio.Lock = asyncio.Lock()

    def subscribe(self, callback: FillEventCallback) -> None:
        """Subscribe to fill events."""
        self._subscribers.append(callback)
        logger.info(f"Fill event subscriber registered: {callback.__name__}")

    def unsubscribe(self, callback: FillEventCallback) -> None:
        """Unsubscribe from fill events."""
        if callback in self._subscribers:
            self._subscribers.remove(callback)
            logger.info(f"Fill event subscriber removed: {callback.__name__}")

    async def publish(
        self,
        account_id: str,
        fill_id: str,
        realized_pnl: Decimal,
        turnover: Decimal,
        current_equity: Decimal,
        fill_timestamp: Optional[datetime] = None,
        **kwargs,
    ) -> None:
        """Publish a fill event to all subscribers.

        Args:
            account_id: Account that received the fill.
            fill_id: Unique identifier for this fill event (for exactly-once dedup).
            realized_pnl: Realized P&L from the fill.
            turnover: Turnover value of the fill.
            current_equity: Current portfolio equity after the fill.
            fill_timestamp: When the fill occurred (default: now).
            **kwargs: Additional data passed through to subscribers.

        Raises:
            FillDeliveryError: If any subscriber fails to process the event.
        """
        if fill_timestamp is None:
            fill_timestamp = datetime.now(timezone.utc)

        async with self._lock:
            subscribers = list(self._subscribers)

        failed_subscribers = []
        for callback in subscribers:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(
                        account_id=account_id,
                        fill_id=fill_id,
                        realized_pnl=realized_pnl,
                        turnover=turnover,
                        current_equity=current_equity,
                        fill_timestamp=fill_timestamp,
                        **kwargs,
                    )
                else:
                    callback(
                        account_id=account_id,
                        fill_id=fill_id,
                        realized_pnl=realized_pnl,
                        turnover=turnover,
                        current_equity=current_equity,
                        fill_timestamp=fill_timestamp,
                        **kwargs,
                    )
            except Exception as e:
                logger.error(f"Fill event subscriber {callback.__name__} failed: {e}", exc_info=True)
                failed_subscribers.append((callback.__name__, str(e)))

        if failed_subscribers:
            from .exceptions import FillDeliveryError
            raise FillDeliveryError(
                f"Fill delivery failed for {len(failed_subscribers)} subscriber(s): "
                + "; ".join(f"{name}: {err}" for name, err in failed_subscribers)
            )
