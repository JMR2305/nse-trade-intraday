# RC-8B Risk Engine — Fixed Package

## Files Included

### Production Code (risk/)
- `engine.py` — Fixed throttle regression + fill_id dedup + removed duplicate kill-switch check
- `integration_layer.py` — Fixed imports + fill_id propagation + error surfacing
- `fill_event_bus.py` — Exactly-once semantics with fill_id + FillDeliveryError
- `exceptions.py` — Added FillDeliveryError
- `contracts.py`, `rules.py`, `state.py`, `kill_switch.py` — Unchanged from RC-8B
- `__init__.py` — Added FillDeliveryError to exports

### NOT Included (retain from project)
- `persistence.py` — The project's existing RiskEnginePersistenceAdapter must be retained.
  Do NOT overwrite with a stub.

### Tests (tests/)
- `test_engine.py` — Unit tests (fill_id added to record_fill calls)
- `test_risk_integration.py` — Integration tests (fixed imports, max_orders=25, new throttle boundary tests, fill idempotency tests)
- `mocks/execution_engine.py` — Mock execution engine

### Config
- `pytest.ini` — asyncio_mode = auto
- `conftest.py` — pytest-asyncio support

## Fixes Applied (All 4 from RC8B_VERIFICATION_REPORT.md + 5 additional)

1. **Throttle regression** — Counter recorded AFTER evaluation (rev 3 restored)
2. **Test imports** — Flat → package-relative paths
3. **Concurrency tests** — max_orders raised to 25; added dedicated throttle boundary tests
4. **Fill delivery** — Exactly-once via fill_id dedup + FillDeliveryError propagation
5. **Bare imports** → Relative imports in integration_layer.py and fill_event_bus.py
6. **FillDeliveryError export** — Added to __init__.py
7. **Duplicate kill-switch** — Removed redundant kill_switch.evaluate_order() call
8. **Persistence stub** — Removed; project's existing file must be retained
