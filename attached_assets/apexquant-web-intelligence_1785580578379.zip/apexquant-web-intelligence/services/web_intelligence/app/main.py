"""FastAPI application entry point."""
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api import health, intelligence, sources, collection_runs, snapshots
from app.config import settings
from app.logging import configure_logging, get_logger
from app.repositories.database import init_db

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    configure_logging()
    logger.info("web_intelligence_service_starting", host=settings.service_host, port=settings.service_port)
    await init_db()
    yield
    logger.info("web_intelligence_service_stopping")


app = FastAPI(
    title="ApexQuant Web Intelligence Collector",
    description="Isolated intelligence collection service. Read-only API. No trading integration.",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(health.router, tags=["Health"])
app.include_router(sources.router, prefix="/api/v1", tags=["Sources"])
app.include_router(collection_runs.router, prefix="/api/v1", tags=["Collection Runs"])
app.include_router(intelligence.router, prefix="/api/v1", tags=["Intelligence"])
app.include_router(snapshots.router, prefix="/api/v1", tags=["Snapshots"])


@app.get("/")
async def root() -> dict[str, str]:
    return {
        "service": "ApexQuant Web Intelligence Collector",
        "version": "0.1.0",
        "status": "isolated_read_only_service",
    }
