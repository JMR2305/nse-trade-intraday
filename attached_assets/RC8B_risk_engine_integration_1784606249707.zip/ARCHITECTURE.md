# RC-8B Risk Engine Integration — Architecture Document

## Overview

The Risk Engine Integration Layer (RC-8B) connects the RC-8A Risk Engine to the
RC-7 Execution Engine. Every order submitted by the Strategy Layer passes through
the Risk Engine for validation before reaching execution.

## Design Principles

1. **Pure Gate** — The Risk Engine does not modify execution state. It only
evaluates and returns approve/reject.

2. **No Changes to RC-7** — The Execution Engine is frozen. Integration is via
a thin adapter layer.

3. **Event-Driven Decoupling** — Fill notifications use an event bus to avoid
circular dependencies.

4. **Fail-Safe** — Any error in the risk check results in rejection.

5. **Backward Compatible** — Can be disabled via feature flag.

## Sequence Diagram

```
Strategy Layer
      |
      v
+-------------------------------+
| RiskIntegrationLayer          |
| +---------------------------+ |
| | 1. Adapt Execution State  | |
| |    -> RiskContext         | |
| | 2. Call risk_engine.check | |
| | 3. If approved -> delegate| |
| | 4. If rejected -> return  | |
| +---------------------------+ |
+-------------------------------+
      | approved              | rejected
      v                       v
Execution Engine         Rejection Handler
      |                       |
      v                       v
Matching Engine        Audit Log + Response
      |
      v
Fill Event ------------------------------> risk_engine.record_fill()
```

## Integration Points

### 1. Pre-Trade Check (Synchronous, Blocking)

Before every `submit_order()` call:

1. Gather execution state (portfolio, positions, prices, open orders)
2. Call `risk_engine.pre_trade_check()`
3. If `approved == False`: reject, audit log, return
4. If `approved == True`: delegate to execution engine

### 2. Fill Notification (Asynchronous, Non-Blocking)

After every fill in the Execution Engine:

1. Execution Engine publishes `FillEvent` to `FillEventBus`
2. Risk Engine subscriber receives event
3. Calls `risk_engine.record_fill()` to update state

### 3. State Recovery

On system restart:

1. Risk Engine loads latest snapshot from PostgreSQL
2. Execution Engine recovers independently
3. Risk Engine catches up via replay of fill events from message log

## Files

| File | Purpose |
|------|---------|
| `risk_integration_layer.py` | Main integration wrapper |
| `risk_fill_event_bus.py` | Decoupled fill notifications |
| `mock_execution_engine.py` | Test double for RC-7 |
| `test_integration.py` | 22 integration tests |

## Backward Compatibility

When `enabled=False`, the integration layer passes orders directly to the
Execution Engine without risk checking. A synthetic `RiskResult(approved=True)`
is returned for API consistency.

## Execution Engine Contract

The RC-7 Execution Engine must expose these methods:

```python
async def get_portfolio_snapshot(account_id: str) -> Optional[PortfolioSnapshot]
async def get_position_snapshots(account_id: str) -> Dict[str, PositionSnapshot]
async def get_open_orders(account_id: str) -> List[Order]
async def get_market_price(instrument_token: str) -> Optional[Decimal]
async def submit_order(account_id: str, order: Order) -> OrderResult
```

These are defined as a Protocol (`ExecutionEnginePort`) — no inheritance
required, just duck typing.
