"""
Unit tests for risk/contracts.py.
"""

import pytest
from decimal import Decimal
from datetime import datetime, timezone
from pydantic import ValidationError

from risk.contracts import (
    RiskSeverity,
    RiskCheckType,
    RiskViolation,
    RiskResult,
    OrderQuantityLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    PortfolioExposureLimit,
    DailyLossLimit,
    MaxOrdersPerMinuteLimit,
    RiskStateSnapshot,
    RiskContext,
    DuplicateOrderLimit,
    SelfTradeLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
)


class TestRiskSeverity:
    def test_enum_values(self):
        assert RiskSeverity.INFO == "INFO"
        assert RiskSeverity.WARNING == "WARNING"
        assert RiskSeverity.CRITICAL == "CRITICAL"
        assert RiskSeverity.FATAL == "FATAL"


class TestRiskViolation:
    def test_create_basic(self):
        v = RiskViolation(
            check_type=RiskCheckType.ORDER_QUANTITY,
            severity=RiskSeverity.CRITICAL,
            message="Quantity too large",
            rule_id="rule_001",
            limit_value=Decimal("100"),
            actual_value=Decimal("150"),
        )
        assert v.check_type == RiskCheckType.ORDER_QUANTITY
        assert v.severity == RiskSeverity.CRITICAL
        assert v.limit_value == Decimal("100")
        assert v.actual_value == Decimal("150")

    def test_decimal_conversion_from_string(self):
        v = RiskViolation(
            check_type=RiskCheckType.ORDER_QUANTITY,
            severity=RiskSeverity.CRITICAL,
            message="Test",
            rule_id="rule_001",
            limit_value="100.50",
            actual_value="200.75",
        )
        assert isinstance(v.limit_value, Decimal)
        assert v.limit_value == Decimal("100.50")
        assert v.actual_value == Decimal("200.75")

    def test_decimal_conversion_from_int(self):
        v = RiskViolation(
            check_type=RiskCheckType.ORDER_QUANTITY,
            severity=RiskSeverity.CRITICAL,
            message="Test",
            rule_id="rule_001",
            limit_value=100,
            actual_value=200,
        )
        assert isinstance(v.limit_value, Decimal)
        assert v.limit_value == Decimal("100")

    def test_none_values(self):
        v = RiskViolation(
            check_type=RiskCheckType.ORDER_QUANTITY,
            severity=RiskSeverity.CRITICAL,
            message="Test",
            rule_id="rule_001",
        )
        assert v.limit_value is None
        assert v.actual_value is None


class TestRiskResult:
    def test_allow_no_violations(self):
        d = RiskResult(
            approved=True,
            check_timestamp=datetime.now(timezone.utc),
            account_id="ACC001",
        )
        assert d.is_allowed is True
        assert d.is_blocked is False
        assert d.has_critical is False
        assert d.action == "ALLOW"

    def test_block_with_critical(self):
        v = RiskViolation(
            check_type=RiskCheckType.ORDER_QUANTITY,
            severity=RiskSeverity.CRITICAL,
            message="Too big",
            rule_id="rule_001",
        )
        d = RiskResult(
            approved=False,
            violations=[v],
            check_timestamp=datetime.now(timezone.utc),
            account_id="ACC001",
        )
        assert d.is_allowed is False
        assert d.is_blocked is True
        assert d.has_critical is True
        assert d.action == "BLOCK"

    def test_kill_switch_with_fatal(self):
        v = RiskViolation(
            check_type=RiskCheckType.DAILY_LOSS_LIMIT,
            severity=RiskSeverity.FATAL,
            message="Loss limit reached",
            rule_id="rule_002",
        )
        d = RiskResult(
            approved=False,
            violations=[v],
            check_timestamp=datetime.now(timezone.utc),
            account_id="ACC001",
        )
        assert d.is_allowed is False
        assert d.is_blocked is True
        assert d.has_critical is True
        assert d.action == "KILL_SWITCH"

    def test_warn_with_warning_only(self):
        v = RiskViolation(
            check_type=RiskCheckType.DAILY_LOSS_LIMIT,
            severity=RiskSeverity.WARNING,
            message="Near limit",
            rule_id="rule_003",
        )
        d = RiskResult(
            approved=True,
            violations=[v],
            check_timestamp=datetime.now(timezone.utc),
            account_id="ACC001",
        )
        assert d.is_allowed is True
        assert d.is_blocked is False
        assert d.has_critical is False
        assert d.action == "WARN"


class TestOrderQuantityLimit:
    def test_valid(self):
        limit = OrderQuantityLimit(
            rule_id="max_qty_001",
            max_quantity=Decimal("500"),
        )
        assert limit.max_quantity == Decimal("500")
        assert limit.enabled is True

    def test_string_conversion(self):
        limit = OrderQuantityLimit(
            rule_id="max_qty_001",
            max_quantity="500",
        )
        assert isinstance(limit.max_quantity, Decimal)
        assert limit.max_quantity == Decimal("500")

    def test_invalid_zero(self):
        with pytest.raises(ValidationError):
            OrderQuantityLimit(
                rule_id="max_qty_001",
                max_quantity=Decimal("0"),
            )

    def test_invalid_negative(self):
        with pytest.raises(ValidationError):
            OrderQuantityLimit(
                rule_id="max_qty_001",
                max_quantity=Decimal("-1"),
            )


class TestPriceBandLimit:
    def test_valid(self):
        limit = PriceBandLimit(
            rule_id="price_tol_001",
            max_deviation_percent=Decimal("5.0"),
        )
        assert limit.max_deviation_percent == Decimal("5.0")

    def test_invalid_zero(self):
        with pytest.raises(ValidationError):
            PriceBandLimit(
                rule_id="price_tol_001",
                max_deviation_percent=Decimal("0"),
            )


class TestMaxPositionSizeLimit:
    def test_valid(self):
        limit = MaxPositionSizeLimit(
            rule_id="pos_limit_001",
            max_long_quantity=Decimal("1000"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        )
        assert limit.max_long_quantity == Decimal("1000")
        assert limit.max_short_quantity == Decimal("500")

    def test_invalid_negative(self):
        with pytest.raises(ValidationError):
            MaxPositionSizeLimit(
                rule_id="pos_limit_001",
                max_long_quantity=Decimal("-1"),
                max_short_quantity=Decimal("500"),
                instrument_token="INFY",
            )


class TestPortfolioExposureLimit:
    def test_valid(self):
        limit = PortfolioExposureLimit(
            rule_id="exp_001",
            max_exposure_percent=Decimal("80.0"),
        )
        assert limit.max_exposure_percent == Decimal("80.0")

    def test_invalid_over_100(self):
        with pytest.raises(ValidationError):
            PortfolioExposureLimit(
                rule_id="exp_001",
                max_exposure_percent=Decimal("101.0"),
            )


class TestDailyLossLimit:
    def test_valid(self):
        limit = DailyLossLimit(
            rule_id="loss_001",
            max_daily_loss=Decimal("10000"),
        )
        assert limit.max_daily_loss == Decimal("10000")
        assert limit.warning_threshold_percent == Decimal("80.0")

    def test_custom_warning(self):
        limit = DailyLossLimit(
            rule_id="loss_001",
            max_daily_loss=Decimal("10000"),
            warning_threshold_percent=Decimal("50.0"),
        )
        assert limit.warning_threshold_percent == Decimal("50.0")


class TestMaxOrdersPerMinuteLimit:
    def test_valid(self):
        limit = MaxOrdersPerMinuteLimit(
            rule_id="throttle_001",
            max_orders=10,
            window_seconds=60,
        )
        assert limit.max_orders == 10
        assert limit.window_seconds == 60


class TestRiskStateSnapshot:
    def test_create(self):
        snapshot = RiskStateSnapshot(
            account_id="ACC001",
            snapshot_timestamp=datetime.now(timezone.utc),
            daily_realized_pnl=Decimal("-500"),
            daily_turnover=Decimal("10000"),
            peak_equity=Decimal("100000"),
        )
        assert snapshot.daily_realized_pnl == Decimal("-500")
        assert snapshot.kill_switch_active is False
        assert snapshot.emergency_halt_active is False
        assert snapshot.circuit_breaker_triggered is False

    def test_decimal_conversion(self):
        snapshot = RiskStateSnapshot(
            account_id="ACC001",
            snapshot_timestamp=datetime.now(timezone.utc),
            daily_realized_pnl="-500",
            daily_turnover="10000",
            peak_equity="100000",
        )
        assert isinstance(snapshot.daily_realized_pnl, Decimal)


class TestRiskContext:
    def test_create(self):
        ctx = RiskContext(
            account_id="ACC001",
            market_prices={"INFY": Decimal("1500.50")},
        )
        assert ctx.market_prices["INFY"] == Decimal("1500.50")

    def test_price_decimal_conversion(self):
        ctx = RiskContext(
            account_id="ACC001",
            market_prices={"INFY": "1500.50"},
        )
        assert isinstance(ctx.market_prices["INFY"], Decimal)
        assert ctx.market_prices["INFY"] == Decimal("1500.50")


class TestAdditionalLimits:
    def test_duplicate_order_limit(self):
        limit = DuplicateOrderLimit(rule_id="dup_001", window_seconds=5)
        assert limit.window_seconds == 5
        assert limit.check_type == RiskCheckType.DUPLICATE_ORDER

    def test_self_trade_limit(self):
        limit = SelfTradeLimit(rule_id="st_001")
        assert limit.check_type == RiskCheckType.SELF_TRADE

    def test_drawdown_limit(self):
        limit = DrawdownLimit(rule_id="dd_001", max_drawdown_percent=Decimal("10"))
        assert limit.max_drawdown_percent == Decimal("10")

    def test_turnover_velocity_limit(self):
        limit = TurnoverVelocityLimit(rule_id="tv_001", max_velocity=Decimal("5"))
        assert limit.max_velocity == Decimal("5")
