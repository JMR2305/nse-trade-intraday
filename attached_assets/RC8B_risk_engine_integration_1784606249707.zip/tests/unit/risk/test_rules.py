"""
Unit tests for risk/rules.py.
"""

import pytest
from decimal import Decimal
from datetime import datetime, timezone

from risk.contracts import (
    RiskContext,
    RiskStateSnapshot,
    OrderQuantityLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    PortfolioExposureLimit,
    DailyLossLimit,
    MaxOrdersPerMinuteLimit,
    DuplicateOrderLimit,
    SelfTradeLimit,
    ConcentrationLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
    RiskSeverity,
    RiskCheckType,
)
from risk.rules import (
    OrderQuantityRule,
    PriceBandRule,
    MaxPositionSizeRule,
    PortfolioExposureRule,
    DailyLossLimitRule,
    MaxOrdersPerMinuteRule,
    DuplicateOrderRule,
    SelfTradeRule,
    ConcentrationRule,
    DrawdownRule,
    TurnoverVelocityRule,
)


@pytest.fixture
def base_context():
    return RiskContext(
        account_id="ACC001",
    )


@pytest.fixture
def base_state():
    return RiskStateSnapshot(
        account_id="ACC001",
        snapshot_timestamp=datetime.now(timezone.utc),
    )


class TestOrderQuantityRule:
    def test_pass(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100"))
        order = {"instrument_token": "INFY", "quantity": Decimal("50")}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100"))
        order = {"instrument_token": "INFY", "quantity": Decimal("150")}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.ORDER_QUANTITY
        assert result.actual_value == Decimal("150")

    def test_instrument_specific_match(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(
            rule_id="os_001",
            max_quantity=Decimal("100"),
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150")}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is not None

    def test_instrument_specific_no_match(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(
            rule_id="os_001",
            max_quantity=Decimal("100"),
            instrument_token="TCS",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150")}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_disabled(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(
            rule_id="os_001",
            max_quantity=Decimal("100"),
            enabled=False,
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150")}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_no_order(self, base_context, base_state):
        rule = OrderQuantityRule()
        limit = OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100"))
        request = type('obj', (object,), {'order': None})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None


class TestPriceBandRule:
    def test_pass(self, base_context, base_state):
        rule = PriceBandRule()
        limit = PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5"))
        order = {
            "instrument_token": "INFY",
            "price": Decimal("1575"),
            "order_type": "LIMIT",
        }
        request = type('obj', (object,), {'order': order})()
        ctx = base_context.copy(update={
            "market_prices": {"INFY": Decimal("1500")},
        })

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = PriceBandRule()
        limit = PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5"))
        order = {
            "instrument_token": "INFY",
            "price": Decimal("1700"),
            "order_type": "LIMIT",
        }
        request = type('obj', (object,), {'order': order})()
        ctx = base_context.copy(update={
            "market_prices": {"INFY": Decimal("1500")},
        })

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.PRICE_BAND

    def test_market_order_skipped(self, base_context, base_state):
        rule = PriceBandRule()
        limit = PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5"))
        order = {
            "instrument_token": "INFY",
            "price": Decimal("1000000"),
            "order_type": "MARKET",
        }
        request = type('obj', (object,), {'order': order})()
        ctx = base_context.copy(update={
            "market_prices": {"INFY": Decimal("1500")},
        })

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is None

    def test_no_ltp(self, base_context, base_state):
        rule = PriceBandRule()
        limit = PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5"))
        order = {
            "instrument_token": "INFY",
            "price": Decimal("1700"),
            "order_type": "LIMIT",
        }
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None


class TestMaxPositionSizeRule:
    def test_pass_within_limit(self, base_context, base_state):
        rule = MaxPositionSizeRule()
        limit = MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("1000"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("100"), "side": "BUY"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_fail_long_limit(self, base_context, base_state):
        rule = MaxPositionSizeRule()
        limit = MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("100"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150"), "side": "BUY"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.MAX_POSITION_SIZE

    def test_fail_short_limit(self, base_context, base_state):
        rule = MaxPositionSizeRule()
        limit = MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("1000"),
            max_short_quantity=Decimal("100"),
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150"), "side": "SELL"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.MAX_POSITION_SIZE

    def test_with_existing_position(self, base_context, base_state):
        rule = MaxPositionSizeRule()
        limit = MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("100"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("50"), "side": "BUY"}
        request = type('obj', (object,), {'order': order})()
        positions = {
            "INFY": {"net_quantity": Decimal("60"), "direction": "LONG"}
        }
        ctx = base_context.copy(update={
            "position_snapshots": positions,
        })

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is not None

    def test_wrong_instrument(self, base_context, base_state):
        rule = MaxPositionSizeRule()
        limit = MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("100"),
            max_short_quantity=Decimal("500"),
            instrument_token="TCS",
        )
        order = {"instrument_token": "INFY", "quantity": Decimal("150"), "side": "BUY"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None


class TestPortfolioExposureRule:
    def test_pass(self, base_context, base_state):
        rule = PortfolioExposureRule()
        limit = PortfolioExposureLimit(rule_id="pe_001", max_exposure_percent=Decimal("100"))
        portfolio = {"equity": Decimal("100000"), "total_market_value": Decimal("80000")}
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, base_state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = PortfolioExposureRule()
        limit = PortfolioExposureLimit(rule_id="pe_001", max_exposure_percent=Decimal("50"))
        portfolio = {"equity": Decimal("100000"), "total_market_value": Decimal("80000")}
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.PORTFOLIO_EXPOSURE

    def test_zero_equity(self, base_context, base_state):
        rule = PortfolioExposureRule()
        limit = PortfolioExposureLimit(rule_id="pe_001", max_exposure_percent=Decimal("100"))
        portfolio = {"equity": Decimal("0"), "total_market_value": Decimal("80000")}
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, base_state)
        assert result is None


class TestDailyLossLimitRule:
    def test_no_loss(self, base_context, base_state):
        rule = DailyLossLimitRule()
        limit = DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000"))
        state = base_state.copy(update={"daily_realized_pnl": Decimal("500")})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is None

    def test_warning_threshold(self, base_context, base_state):
        rule = DailyLossLimitRule()
        limit = DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000"))
        state = base_state.copy(update={"daily_realized_pnl": Decimal("-8500")})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is not None
        assert result.severity.value == "WARNING"

    def test_fatal_threshold(self, base_context, base_state):
        rule = DailyLossLimitRule()
        limit = DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000"))
        state = base_state.copy(update={"daily_realized_pnl": Decimal("-10000")})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is not None
        assert result.severity.value == "FATAL"

    def test_exceeds_limit(self, base_context, base_state):
        rule = DailyLossLimitRule()
        limit = DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000"))
        state = base_state.copy(update={"daily_realized_pnl": Decimal("-15000")})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is not None
        assert result.severity.value == "FATAL"


class TestMaxOrdersPerMinuteRule:
    def test_pass(self, base_context, base_state):
        rule = MaxOrdersPerMinuteRule()
        limit = MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=10, window_seconds=60)
        state = base_state.copy(update={"message_counts": {"account:ACC001": 5}})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = MaxOrdersPerMinuteRule()
        limit = MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=10, window_seconds=60)
        state = base_state.copy(update={"message_counts": {"account:ACC001": 10}})

        result = rule.evaluate(None, base_context, limit, state)
        assert result is not None
        assert result.check_type == RiskCheckType.MAX_ORDERS_PER_MINUTE

    def test_instrument_scope(self, base_context, base_state):
        rule = MaxOrdersPerMinuteRule()
        limit = MaxOrdersPerMinuteLimit(
            rule_id="mt_001",
            max_orders=5,
            window_seconds=60,
            scope="instrument",
            instrument_token="INFY",
        )
        order = {"instrument_token": "INFY"}
        ctx = base_context.copy(update={"order": order})
        state = base_state.copy(update={"message_counts": {"instrument:INFY": 5}})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is not None


class TestDuplicateOrderRule:
    def test_no_duplicate(self, base_context, base_state):
        rule = DuplicateOrderRule()
        limit = DuplicateOrderLimit(rule_id="dup_001", window_seconds=5)
        order = {"instrument_token": "INFY", "side": "BUY", "quantity": "100", "price": "1500"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_duplicate_detected(self, base_context, base_state):
        rule = DuplicateOrderRule()
        rule.reset()
        limit = DuplicateOrderLimit(rule_id="dup_001", window_seconds=5)
        order = {"instrument_token": "INFY", "side": "BUY", "quantity": "100", "price": "1500"}
        request = type('obj', (object,), {'order': order})()

        state1 = base_state.copy(update={"snapshot_timestamp": datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)})
        result1 = rule.evaluate(request, base_context, limit, state1)
        assert result1 is None

        state2 = base_state.copy(update={"snapshot_timestamp": datetime(2024, 1, 1, 12, 0, 2, tzinfo=timezone.utc)})
        result2 = rule.evaluate(request, base_context, limit, state2)
        assert result2 is not None
        assert result2.check_type == RiskCheckType.DUPLICATE_ORDER

    def test_duplicate_after_window(self, base_context, base_state):
        rule = DuplicateOrderRule()
        rule.reset()
        limit = DuplicateOrderLimit(rule_id="dup_001", window_seconds=5)
        order = {"instrument_token": "INFY", "side": "BUY", "quantity": "100", "price": "1500"}
        request = type('obj', (object,), {'order': order})()

        state1 = base_state.copy(update={"snapshot_timestamp": datetime(2024, 1, 1, 12, 0, 0, tzinfo=timezone.utc)})
        result1 = rule.evaluate(request, base_context, limit, state1)
        assert result1 is None

        state2 = base_state.copy(update={"snapshot_timestamp": datetime(2024, 1, 1, 12, 0, 6, tzinfo=timezone.utc)})
        result2 = rule.evaluate(request, base_context, limit, state2)
        assert result2 is None

    def test_reset(self, base_context, base_state):
        rule = DuplicateOrderRule()
        limit = DuplicateOrderLimit(rule_id="dup_001", window_seconds=5)
        order = {"instrument_token": "INFY", "side": "BUY", "quantity": "100", "price": "1500"}
        request = type('obj', (object,), {'order': order})()

        rule.evaluate(request, base_context, limit, base_state)
        rule.reset()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None


class TestSelfTradeRule:
    def test_no_open_orders(self, base_context, base_state):
        rule = SelfTradeRule()
        limit = SelfTradeLimit(rule_id="st_001")
        order = {"instrument_token": "INFY", "side": "BUY", "price": "1500"}
        request = type('obj', (object,), {'order': order})()

        result = rule.evaluate(request, base_context, limit, base_state)
        assert result is None

    def test_no_cross(self, base_context, base_state):
        rule = SelfTradeRule()
        limit = SelfTradeLimit(rule_id="st_001")
        order = {"instrument_token": "INFY", "side": "BUY", "price": "1500"}
        request = type('obj', (object,), {'order': order})()
        open_orders = [{"instrument_token": "INFY", "side": "SELL", "price": "1600"}]
        ctx = base_context.copy(update={"open_orders": open_orders})

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is None

    def test_cross_detected(self, base_context, base_state):
        rule = SelfTradeRule()
        limit = SelfTradeLimit(rule_id="st_001")
        order = {"instrument_token": "INFY", "side": "BUY", "price": "1500"}
        request = type('obj', (object,), {'order': order})()
        open_orders = [{"instrument_token": "INFY", "side": "SELL", "price": "1490"}]
        ctx = base_context.copy(update={"open_orders": open_orders})

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.SELF_TRADE

    def test_same_side_no_cross(self, base_context, base_state):
        rule = SelfTradeRule()
        limit = SelfTradeLimit(rule_id="st_001")
        order = {"instrument_token": "INFY", "side": "BUY", "price": "1500"}
        request = type('obj', (object,), {'order': order})()
        open_orders = [{"instrument_token": "INFY", "side": "BUY", "price": "1490"}]
        ctx = base_context.copy(update={"open_orders": open_orders})

        result = rule.evaluate(request, ctx, limit, base_state)
        assert result is None


class TestConcentrationRule:
    def test_pass(self, base_context, base_state):
        rule = ConcentrationRule()
        limit = ConcentrationLimit(rule_id="ph_001", max_concentration_percent=Decimal("50"))
        portfolio = {"equity": Decimal("100000")}
        positions = {
            "INFY": {"market_value": Decimal("40000")},
        }
        ctx = base_context.copy(update={
            "portfolio_snapshot": portfolio,
            "position_snapshots": positions,
        })

        result = rule.evaluate(None, ctx, limit, base_state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = ConcentrationRule()
        limit = ConcentrationLimit(rule_id="ph_001", max_concentration_percent=Decimal("30"))
        portfolio = {"equity": Decimal("100000")}
        positions = {
            "INFY": {"market_value": Decimal("40000")},
        }
        ctx = base_context.copy(update={
            "portfolio_snapshot": portfolio,
            "position_snapshots": positions,
        })

        result = rule.evaluate(None, ctx, limit, base_state)
        assert result is not None
        assert result.check_type == RiskCheckType.CONCENTRATION_LIMIT


class TestDrawdownRule:
    def test_no_drawdown(self, base_context, base_state):
        rule = DrawdownRule()
        limit = DrawdownLimit(rule_id="dd_001", max_drawdown_percent=Decimal("10"))
        portfolio = {"equity": Decimal("100000")}
        state = base_state.copy(update={"peak_equity": Decimal("100000")})
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is None

    def test_warning(self, base_context, base_state):
        rule = DrawdownRule()
        limit = DrawdownLimit(rule_id="dd_001", max_drawdown_percent=Decimal("10"))
        # Warning band is 80% of limit = 8% drawdown
        portfolio = {"equity": Decimal("92000")}  # 8% drawdown exactly
        state = base_state.copy(update={"peak_equity": Decimal("100000")})
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is not None
        assert result.severity.value == "WARNING"

    def test_fatal(self, base_context, base_state):
        rule = DrawdownRule()
        limit = DrawdownLimit(rule_id="dd_001", max_drawdown_percent=Decimal("10"))
        portfolio = {"equity": Decimal("90000")}
        state = base_state.copy(update={"peak_equity": Decimal("100000")})
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is not None
        assert result.severity.value == "FATAL"


class TestTurnoverVelocityRule:
    def test_pass(self, base_context, base_state):
        rule = TurnoverVelocityRule()
        limit = TurnoverVelocityLimit(rule_id="tv_001", max_velocity=Decimal("5"))
        portfolio = {"equity": Decimal("100000")}
        state = base_state.copy(update={"daily_turnover": Decimal("300000")})
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is None

    def test_fail(self, base_context, base_state):
        rule = TurnoverVelocityRule()
        limit = TurnoverVelocityLimit(rule_id="tv_001", max_velocity=Decimal("5"))
        portfolio = {"equity": Decimal("100000")}
        state = base_state.copy(update={"daily_turnover": Decimal("600000")})
        ctx = base_context.copy(update={"portfolio_snapshot": portfolio})

        result = rule.evaluate(None, ctx, limit, state)
        assert result is not None
        assert result.check_type == RiskCheckType.TURNOVER_VELOCITY
