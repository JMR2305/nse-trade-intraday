"""
Unit tests for risk/engine.py.
"""

import pytest
import asyncio
from decimal import Decimal
from datetime import datetime, timezone

from risk.engine import RiskEngine
from risk.contracts import (
    RiskSeverity,
    OrderQuantityLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    PortfolioExposureLimit,
    DailyLossLimit,
    MaxOrdersPerMinuteLimit,
    DuplicateOrderLimit,
    SelfTradeLimit,
    ConcentrationLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
    KillSwitchLimit,
    EmergencyHaltLimit,
    CircuitBreakerLimit,
)


@pytest.fixture
def engine():
    return RiskEngine()


@pytest.fixture
def sample_limits():
    return [
        OrderQuantityLimit(rule_id="os_001", max_quantity=Decimal("100")),
        PriceBandLimit(rule_id="pt_001", max_deviation_percent=Decimal("5")),
        MaxPositionSizeLimit(
            rule_id="pl_001",
            max_long_quantity=Decimal("1000"),
            max_short_quantity=Decimal("500"),
            instrument_token="INFY",
        ),
        PortfolioExposureLimit(rule_id="pe_001", max_exposure_percent=Decimal("90")),
        DailyLossLimit(rule_id="dl_001", max_daily_loss=Decimal("10000")),
        MaxOrdersPerMinuteLimit(rule_id="mt_001", max_orders=10, window_seconds=60),
        DuplicateOrderLimit(rule_id="dup_001", window_seconds=5),
        SelfTradeLimit(rule_id="st_001"),
        ConcentrationLimit(rule_id="ph_001", max_concentration_percent=Decimal("50")),
        DrawdownLimit(rule_id="dd_001", max_drawdown_percent=Decimal("10")),
        TurnoverVelocityLimit(rule_id="tv_001", max_velocity=Decimal("10")),
        KillSwitchLimit(rule_id="ks_001"),
        EmergencyHaltLimit(rule_id="eh_001"),
        CircuitBreakerLimit(rule_id="cb_001", max_decline_percent=Decimal("10")),
    ]


class TestRiskEngineRegistration:
    @pytest.mark.asyncio
    async def test_register_account(self, engine):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        snapshot = await engine.get_state_snapshot("ACC001")
        assert snapshot.account_id == "ACC001"
        assert snapshot.peak_equity == Decimal("100000")

    @pytest.mark.asyncio
    async def test_set_limits(self, engine, sample_limits):
        await engine.register_account("ACC001")
        await engine.set_limits("ACC001", sample_limits)


class TestRiskEnginePreTrade:
    @pytest.mark.asyncio
    async def test_allow_clean_order(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("50"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is True
        assert result.violations == []

    @pytest.mark.asyncio
    async def test_block_order_size(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("150"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "ORDER_QUANTITY" for v in result.violations)

    @pytest.mark.asyncio
    async def test_block_price_tolerance(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("50"),
            "side": "BUY",
            "price": Decimal("1700"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "PRICE_BAND" for v in result.violations)

    @pytest.mark.asyncio
    async def test_block_position_limit(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        positions = {
            "INFY": {"net_quantity": Decimal("950"), "direction": "LONG"}
        }
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("100"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            position_snapshots=positions,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "MAX_POSITION_SIZE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_warn_daily_loss(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("-8500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("91500"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is True
        assert any(v.check_type.value == "DAILY_LOSS_LIMIT" for v in result.violations)

    @pytest.mark.asyncio
    async def test_kill_switch_daily_loss_fatal(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("-10000"),
            turnover=Decimal("10000"),
            current_equity=Decimal("90000"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.severity == RiskSeverity.FATAL for v in result.violations)
        assert engine.is_kill_switch_active("ACC001")

    @pytest.mark.asyncio
    async def test_throttle(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        market_prices = {"INFY": Decimal("1500")}

        # Vary order params per iteration to avoid DuplicateOrderRule firing first
        for i in range(10):
            order = {
                "instrument_token": "INFY",
                "quantity": Decimal(f"{10 + i}"),  # 10, 11, 12, ...
                "side": "BUY",
                "price": Decimal(f"{1500 + i}"),   # 1500, 1501, 1502, ...
                "order_type": "LIMIT",
            }
            result = await engine.pre_trade_check(
                account_id="ACC001",
                order=order,
                market_prices=market_prices,
            )
            assert result.approved is True, f"Order {i} should be allowed: {result.violations}"

        # 11th identical order should hit throttle
        final_order = {
            "instrument_token": "INFY",
            "quantity": Decimal("20"),
            "side": "BUY",
            "price": Decimal("1510"),
            "order_type": "LIMIT",
        }
        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=final_order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "MAX_ORDERS_PER_MINUTE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_duplicate_order(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is True

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "DUPLICATE_ORDER" for v in result.violations)

    @pytest.mark.asyncio
    async def test_self_trade(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        open_orders = [
            {"instrument_token": "INFY", "side": "SELL", "price": Decimal("1490")}
        ]
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            open_orders=open_orders,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "SELF_TRADE" for v in result.violations)

    @pytest.mark.asyncio
    async def test_kill_switch_blocks_all(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.activate_kill_switch("ACC001", "Manual halt")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert result.is_blocked is True

    @pytest.mark.asyncio
    async def test_deactivate_kill_switch(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.activate_kill_switch("ACC001", "Test")
        assert engine.is_kill_switch_active("ACC001")

        await engine.deactivate_kill_switch("ACC001", "Resolved")
        assert not engine.is_kill_switch_active("ACC001")

    @pytest.mark.asyncio
    async def test_auto_register(self, engine):
        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("50"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC002",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is True

    @pytest.mark.asyncio
    async def test_multiple_violations(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("150"),
            "side": "BUY",
            "price": Decimal("1700"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert len(result.violations) >= 2
        check_types = {v.check_type.value for v in result.violations}
        assert "ORDER_QUANTITY" in check_types
        assert "PRICE_BAND" in check_types

    @pytest.mark.asyncio
    async def test_emergency_halt(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.activate_emergency_halt("ACC001", "System emergency")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "EMERGENCY_HALT" for v in result.violations)
        assert engine.is_emergency_halt_active("ACC001")

    @pytest.mark.asyncio
    async def test_circuit_breaker(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.trigger_circuit_breaker("ACC001")

        order = {
            "instrument_token": "INFY",
            "quantity": Decimal("10"),
            "side": "BUY",
            "price": Decimal("1500"),
            "order_type": "LIMIT",
        }
        market_prices = {"INFY": Decimal("1500")}

        result = await engine.pre_trade_check(
            account_id="ACC001",
            order=order,
            market_prices=market_prices,
        )
        assert result.approved is False
        assert any(v.check_type.value == "CIRCUIT_BREAKER" for v in result.violations)
        assert engine.is_circuit_breaker_triggered("ACC001")


class TestRiskEnginePostTrade:
    @pytest.mark.asyncio
    async def test_portfolio_heat(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        portfolio = {"equity": Decimal("100000")}
        positions = {
            "INFY": {"market_value": Decimal("60000")},
        }

        result = await engine.post_trade_check(
            account_id="ACC001",
            portfolio_snapshot=portfolio,
            position_snapshots=positions,
        )
        assert result.approved is True
        assert any(v.check_type.value == "CONCENTRATION_LIMIT" for v in result.violations)

    @pytest.mark.asyncio
    async def test_drawdown_warning(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        # Warning band is 80% of max_drawdown_percent (10% * 0.8 = 8%)
        # So we need >= 8% drawdown to trigger warning: equity <= 92,000
        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("-8200"),
            turnover=Decimal("10000"),
            current_equity=Decimal("91800"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        portfolio = {"equity": Decimal("91800")}
        positions = {}

        result = await engine.post_trade_check(
            account_id="ACC001",
            portfolio_snapshot=portfolio,
            position_snapshots=positions,
        )
        assert result.approved is True
        assert any(v.check_type.value == "DRAWDOWN" for v in result.violations)

    @pytest.mark.asyncio
    async def test_turnover_velocity(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("0"),
            turnover=Decimal("500000"),
            current_equity=Decimal("100000"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        portfolio = {"equity": Decimal("100000")}
        positions = {}

        result = await engine.post_trade_check(
            account_id="ACC001",
            portfolio_snapshot=portfolio,
            position_snapshots=positions,
        )
        assert result.approved is True
        assert not any(v.check_type.value == "TURNOVER_VELOCITY" for v in result.violations)

    @pytest.mark.asyncio
    async def test_turnover_velocity_exceeded(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("0"),
            turnover=Decimal("1500000"),
            current_equity=Decimal("100000"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        portfolio = {"equity": Decimal("100000")}
        positions = {}

        result = await engine.post_trade_check(
            account_id="ACC001",
            portfolio_snapshot=portfolio,
            position_snapshots=positions,
        )
        assert result.approved is True
        assert any(v.check_type.value == "TURNOVER_VELOCITY" for v in result.violations)


class TestRiskEngineRecordFill:
    @pytest.mark.asyncio
    async def test_record_fill_updates_state(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        snapshot = await engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("500")
        assert snapshot.daily_turnover == Decimal("10000")
        assert snapshot.peak_equity == Decimal("100500")
        assert snapshot.trade_count == 1


class TestRiskEngineReset:
    @pytest.mark.asyncio
    async def test_reset_account(self, engine, sample_limits):
        await engine.register_account("ACC001", initial_equity=Decimal("100000"))
        await engine.set_limits("ACC001", sample_limits)

        await engine.record_fill(
            account_id="ACC001",
            realized_pnl=Decimal("500"),
            turnover=Decimal("10000"),
            current_equity=Decimal("100500"),
            fill_timestamp=datetime.now(timezone.utc),
        )

        await engine.reset_account("ACC001", initial_equity=Decimal("100000"))

        snapshot = await engine.get_state_snapshot("ACC001")
        assert snapshot.daily_realized_pnl == Decimal("0")
        assert snapshot.daily_turnover == Decimal("0")
        assert snapshot.peak_equity == Decimal("100000")

    def test_reset_engine(self, engine, sample_limits):
        engine.reset()
        assert len(engine._states) == 0
        assert len(engine._kill_switches) == 0


class TestRiskEngineKillSwitchHistory:
    @pytest.mark.asyncio
    async def test_kill_switch_history(self, engine):
        await engine.register_account("ACC001")

        await engine.activate_kill_switch("ACC001", "First activation", actor="admin")
        await engine.deactivate_kill_switch("ACC001", "Resolved", actor="admin")
        await engine.activate_kill_switch("ACC001", "Second activation", actor="system")

        history = engine.get_kill_switch_history("ACC001")
        assert len(history) == 3
        assert history[0].action == "ACTIVATED"
        assert history[0].actor == "admin"
        assert history[1].action == "DEACTIVATED"
        assert history[2].action == "ACTIVATED"
        assert history[2].actor == "system"


class TestRiskEngineSafetyMechanisms:
    @pytest.mark.asyncio
    async def test_emergency_halt_lifecycle(self, engine):
        await engine.register_account("ACC001")

        await engine.activate_emergency_halt("ACC001", "Test halt")
        assert engine.is_emergency_halt_active("ACC001")

        await engine.deactivate_emergency_halt("ACC001", "Resolved")
        assert not engine.is_emergency_halt_active("ACC001")

    @pytest.mark.asyncio
    async def test_circuit_breaker_lifecycle(self, engine):
        await engine.register_account("ACC001")

        await engine.trigger_circuit_breaker("ACC001")
        assert engine.is_circuit_breaker_triggered("ACC001")

        await engine.reset_circuit_breaker("ACC001")
        assert not engine.is_circuit_breaker_triggered("ACC001")
