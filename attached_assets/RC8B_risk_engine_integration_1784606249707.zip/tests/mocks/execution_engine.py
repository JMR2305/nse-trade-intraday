"""
Mock Execution Engine for integration testing.

Simulates the RC-7 Execution Engine's interface without any real execution logic.
Used to verify the Risk Integration Layer behaves correctly.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone
import asyncio


class MockPortfolioSnapshot:
    """Simulates Execution Engine portfolio state."""
    def __init__(
        self,
        equity: Decimal = Decimal("100000"),
        cash: Decimal = Decimal("100000"),
        buying_power: Decimal = Decimal("100000"),
        available_margin: Decimal = Decimal("100000"),
        total_market_value: Decimal = Decimal("0"),
        total_long_exposure: Decimal = Decimal("0"),
        total_short_exposure: Decimal = Decimal("0"),
    ):
        self.equity = equity
        self.cash = cash
        self.buying_power = buying_power
        self.available_margin = available_margin
        self.total_market_value = total_market_value
        self.total_long_exposure = total_long_exposure
        self.total_short_exposure = total_short_exposure


class MockPositionSnapshot:
    """Simulates Execution Engine position state."""
    def __init__(
        self,
        instrument_token: str,
        net_quantity: Decimal = Decimal("0"),
        direction: str = "FLAT",
        market_value: Decimal = Decimal("0"),
    ):
        self.instrument_token = instrument_token
        self.net_quantity = net_quantity
        self.direction = direction
        self.market_value = market_value


class MockOrderResult:
    """Simulates Execution Engine order result."""
    def __init__(
        self,
        order_id: str,
        status: str,
        filled_quantity: Decimal = Decimal("0"),
        average_price: Optional[Decimal] = None,
    ):
        self.order_id = order_id
        self.status = status
        self.filled_quantity = filled_quantity
        self.average_price = average_price


class MockExecutionEngine:
    """Mock of the RC-7 Execution Engine for testing.

    Maintains internal state (portfolio, positions, orders, market prices)
    and exposes the ExecutionEnginePort interface.
    """

    def __init__(self):
        self._portfolios: Dict[str, MockPortfolioSnapshot] = {}
        self._positions: Dict[str, Dict[str, MockPositionSnapshot]] = {}
        self._open_orders: Dict[str, List[Any]] = {}
        self._market_prices: Dict[str, Decimal] = {}
        self._order_counter: int = 0
        self._lock: asyncio.Lock = asyncio.Lock()

    async def set_portfolio(self, account_id: str, portfolio: MockPortfolioSnapshot) -> None:
        self._portfolios[account_id] = portfolio

    async def set_position(self, account_id: str, position: MockPositionSnapshot) -> None:
        if account_id not in self._positions:
            self._positions[account_id] = {}
        self._positions[account_id][position.instrument_token] = position

    async def set_market_price(self, instrument_token: str, price: Decimal) -> None:
        self._market_prices[instrument_token] = price

    async def add_open_order(self, account_id: str, order: Any) -> None:
        if account_id not in self._open_orders:
            self._open_orders[account_id] = []
        self._open_orders[account_id].append(order)

    async def clear_open_orders(self, account_id: str) -> None:
        self._open_orders[account_id] = []

    # --- ExecutionEnginePort implementation ---

    async def get_portfolio_snapshot(self, account_id: str) -> Optional[Any]:
        return self._portfolios.get(account_id)

    async def get_position_snapshots(self, account_id: str) -> Dict[str, Any]:
        return self._positions.get(account_id, {})

    async def get_open_orders(self, account_id: str) -> List[Any]:
        return self._open_orders.get(account_id, [])

    async def get_market_price(self, instrument_token: str) -> Optional[Decimal]:
        return self._market_prices.get(instrument_token)

    async def submit_order(self, account_id: str, order: Any) -> MockOrderResult:
        async with self._lock:
            self._order_counter += 1
            order_id = f"MOCK-{self._order_counter}"
            return MockOrderResult(
                order_id=order_id,
                status="ACCEPTED",
            )
