"""
Risk Engine domain contracts.

All domain types are immutable Pydantic models with frozen=True.
Decimal is used for all monetary quantities.

This module defines the canonical contracts for the Batch 8 Risk Engine:
- RiskRequest: the input to a risk check
- RiskResult: the output of a risk check (approved + violations)
- RiskContext: the evaluation context (market data, portfolio state)
- RiskConfiguration: limit and rule configurations
- RiskViolation: a single breached limit
- RiskAudit: immutable audit record of every risk decision
"""

from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Optional, Dict, List, Any
from datetime import datetime, timezone
from pydantic import BaseModel, Field, validator


class RiskSeverity(str, Enum):
    """Severity classification for risk violations."""
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    FATAL = "FATAL"


class RiskCheckType(str, Enum):
    """Types of risk checks performed by the Risk Engine."""
    # Pre-trade Risk
    ORDER_QUANTITY = "ORDER_QUANTITY"
    ORDER_VALUE = "ORDER_VALUE"
    TICK_SIZE = "TICK_SIZE"
    PRICE_BAND = "PRICE_BAND"

    # Position Risk
    MAX_POSITION_SIZE = "MAX_POSITION_SIZE"
    INSTRUMENT_EXPOSURE = "INSTRUMENT_EXPOSURE"
    NET_EXPOSURE = "NET_EXPOSURE"
    CONCENTRATION_LIMIT = "CONCENTRATION_LIMIT"

    # Portfolio Risk
    CASH_AVAILABILITY = "CASH_AVAILABILITY"
    BUYING_POWER = "BUYING_POWER"
    PORTFOLIO_EXPOSURE = "PORTFOLIO_EXPOSURE"
    MARGIN_AVAILABILITY = "MARGIN_AVAILABILITY"

    # Daily Controls
    DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
    DAILY_PROFIT_TARGET_LOCK = "DAILY_PROFIT_TARGET_LOCK"
    MAX_TRADES_PER_DAY = "MAX_TRADES_PER_DAY"
    MAX_ORDERS_PER_MINUTE = "MAX_ORDERS_PER_MINUTE"

    # Safety
    KILL_SWITCH = "KILL_SWITCH"
    EMERGENCY_HALT = "EMERGENCY_HALT"
    CIRCUIT_BREAKER = "CIRCUIT_BREAKER"

    # Additional checks (for backward compatibility with test expectations)
    DUPLICATE_ORDER = "DUPLICATE_ORDER"
    SELF_TRADE = "SELF_TRADE"
    DRAWDOWN = "DRAWDOWN"
    TURNOVER_VELOCITY = "TURNOVER_VELOCITY"


class RiskViolation(BaseModel, frozen=True):
    """Immutable record of a single risk rule violation."""

    check_type: RiskCheckType = Field(..., description="Type of risk check that failed")
    severity: RiskSeverity = Field(..., description="Severity of the violation")
    message: str = Field(..., description="Human-readable violation description")
    rule_id: str = Field(..., description="Identifier of the rule that was violated")
    limit_value: Optional[Decimal] = Field(None, description="The limit threshold that was breached")
    actual_value: Optional[Decimal] = Field(None, description="The actual value that breached the limit")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional context")

    @validator("limit_value", "actual_value", pre=True, always=True)
    def _decimal_precision(cls, v):
        if v is not None and not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class RiskResult(BaseModel, frozen=True):
    """Immutable result of a risk check.

    The Risk Engine returns this for every order evaluation.
    approved=True means the order may proceed to the Execution Engine.
    approved=False means the order is rejected; violations explain why.
    """

    approved: bool = Field(..., description="True if the order passes all risk checks")
    violations: List[RiskViolation] = Field(default_factory=list, description="All violations found")
    check_timestamp: datetime = Field(..., description="Timestamp when the check was performed")
    order_id: Optional[str] = Field(None, description="Order identifier if applicable")
    account_id: str = Field(..., description="Account being evaluated")

    @property
    def is_allowed(self) -> bool:
        """True if approved (no blocking violations)."""
        return self.approved

    @property
    def is_blocked(self) -> bool:
        """True if not approved (blocking violations exist)."""
        return not self.approved

    @property
    def has_critical(self) -> bool:
        """True if any CRITICAL or FATAL violation exists."""
        return any(
            v.severity in (RiskSeverity.CRITICAL, RiskSeverity.FATAL)
            for v in self.violations
        )

    @property
    def action(self) -> str:
        """Determine action string from violations (backward compatibility)."""
        if not self.violations:
            return "ALLOW"
        if any(v.severity == RiskSeverity.FATAL for v in self.violations):
            return "KILL_SWITCH"
        if any(v.severity == RiskSeverity.CRITICAL for v in self.violations):
            return "BLOCK"
        return "WARN"


class RiskRequest(BaseModel, frozen=True):
    """A request to evaluate an order for risk.

    This is the primary input to RiskEngine.evaluate().
    """

    account_id: str = Field(..., description="Account submitting the order")
    order: Any = Field(..., description="The order to evaluate (ExecutionOrder or dict)")
    check_timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Timestamp for this check")

    @validator("check_timestamp", pre=True, always=True)
    def _ensure_datetime(cls, v):
        if v is None:
            return datetime.now(timezone.utc)
        return v


class RiskContext(BaseModel, frozen=True):
    """Contextual market and portfolio state for risk evaluation.

    Passed to risk rules containing current market snapshot,
    portfolio state, and open orders.
    """

    account_id: str = Field(..., description="Account being evaluated")
    portfolio_snapshot: Optional[Any] = Field(None, description="Current PortfolioSnapshot")
    position_snapshots: Dict[str, Any] = Field(default_factory=dict, description="PositionSnapshot by instrument_token")
    market_prices: Dict[str, Decimal] = Field(default_factory=dict, description="LTP by instrument_token")
    open_orders: List[Any] = Field(default_factory=list, description="List of currently open orders")
    order: Optional[Any] = Field(None, description="The order being evaluated (for pre-trade checks)")

    @validator("market_prices", pre=True, always=True)
    def _decimal_prices(cls, v):
        result = {}
        for k, val in v.items():
            if val is not None and not isinstance(val, Decimal):
                result[k] = Decimal(str(val))
            else:
                result[k] = val
        return result


class RiskConfiguration(BaseModel, frozen=True):
    """Configuration for a single risk rule.

    All concrete limit types inherit from this base.
    """

    rule_id: str = Field(..., description="Unique rule identifier")
    enabled: bool = Field(default=True, description="Whether this rule is active")
    severity: RiskSeverity = Field(default=RiskSeverity.CRITICAL, description="Severity when violated")
    check_type: RiskCheckType = Field(..., description="The type of check this rule performs")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Rule-specific config")


# ── Pre-trade Risk Configurations ──

class OrderQuantityLimit(RiskConfiguration, frozen=True):
    """Maximum quantity allowed per single order."""

    max_quantity: Decimal = Field(..., gt=0, description="Maximum order quantity")
    instrument_token: Optional[str] = Field(None, description="Apply to specific instrument only")
    check_type: RiskCheckType = Field(default=RiskCheckType.ORDER_QUANTITY, const=True)

    @validator("max_quantity", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class OrderValueLimit(RiskConfiguration, frozen=True):
    """Maximum notional value allowed per single order."""

    max_value: Decimal = Field(..., gt=0, description="Maximum order notional value")
    instrument_token: Optional[str] = Field(None, description="Apply to specific instrument only")
    check_type: RiskCheckType = Field(default=RiskCheckType.ORDER_VALUE, const=True)

    @validator("max_value", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class TickSizeLimit(RiskConfiguration, frozen=True):
    """Order price must be a multiple of the instrument's tick size."""

    tick_size: Decimal = Field(..., gt=0, description="Minimum price increment")
    instrument_token: Optional[str] = Field(None, description="Apply to specific instrument only")
    check_type: RiskCheckType = Field(default=RiskCheckType.TICK_SIZE, const=True)

    @validator("tick_size", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class PriceBandLimit(RiskConfiguration, frozen=True):
    """Order price must be within a percentage band of the reference price."""

    max_deviation_percent: Decimal = Field(..., gt=0, description="Max % deviation from reference")
    instrument_token: Optional[str] = Field(None, description="Apply to specific instrument only")
    check_type: RiskCheckType = Field(default=RiskCheckType.PRICE_BAND, const=True)

    @validator("max_deviation_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


# ── Position Risk Configurations ──

class MaxPositionSizeLimit(RiskConfiguration, frozen=True):
    """Maximum absolute position size per instrument."""

    max_long_quantity: Decimal = Field(..., ge=0, description="Max long position")
    max_short_quantity: Decimal = Field(..., ge=0, description="Max short position")
    instrument_token: str = Field(..., description="Instrument identifier")
    check_type: RiskCheckType = Field(default=RiskCheckType.MAX_POSITION_SIZE, const=True)

    @validator("max_long_quantity", "max_short_quantity", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class InstrumentExposureLimit(RiskConfiguration, frozen=True):
    """Maximum notional exposure per instrument."""

    max_exposure: Decimal = Field(..., gt=0, description="Max notional exposure")
    instrument_token: str = Field(..., description="Instrument identifier")
    check_type: RiskCheckType = Field(default=RiskCheckType.INSTRUMENT_EXPOSURE, const=True)

    @validator("max_exposure", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class NetExposureLimit(RiskConfiguration, frozen=True):
    """Maximum net long/short exposure across all instruments."""

    max_net_long: Decimal = Field(..., ge=0, description="Max net long exposure")
    max_net_short: Decimal = Field(..., ge=0, description="Max net short exposure")
    check_type: RiskCheckType = Field(default=RiskCheckType.NET_EXPOSURE, const=True)

    @validator("max_net_long", "max_net_short", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class ConcentrationLimit(RiskConfiguration, frozen=True):
    """Maximum portfolio concentration in a single instrument."""

    max_concentration_percent: Decimal = Field(..., gt=0, le=100, description="Max % of portfolio in one instrument")
    check_type: RiskCheckType = Field(default=RiskCheckType.CONCENTRATION_LIMIT, const=True)

    @validator("max_concentration_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


# ── Portfolio Risk Configurations ──

class CashAvailabilityLimit(RiskConfiguration, frozen=True):
    """Sufficient cash must be available to cover the order."""

    check_type: RiskCheckType = Field(default=RiskCheckType.CASH_AVAILABILITY, const=True)


class BuyingPowerLimit(RiskConfiguration, frozen=True):
    """Order must not exceed available buying power."""

    check_type: RiskCheckType = Field(default=RiskCheckType.BUYING_POWER, const=True)


class PortfolioExposureLimit(RiskConfiguration, frozen=True):
    """Maximum total portfolio exposure as percentage of equity."""

    max_exposure_percent: Decimal = Field(..., gt=0, le=100, description="Max % of equity")
    check_type: RiskCheckType = Field(default=RiskCheckType.PORTFOLIO_EXPOSURE, const=True)

    @validator("max_exposure_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class MarginAvailabilityLimit(RiskConfiguration, frozen=True):
    """Sufficient margin must be available for the order."""

    check_type: RiskCheckType = Field(default=RiskCheckType.MARGIN_AVAILABILITY, const=True)


# ── Daily Control Configurations ──

class DailyLossLimit(RiskConfiguration, frozen=True):
    """Maximum realized loss allowed in a trading day."""

    max_daily_loss: Decimal = Field(..., gt=0, description="Max daily loss amount")
    warning_threshold_percent: Decimal = Field(
        default=Decimal("80.0"), 
        description="Warning at % of max loss"
    )
    check_type: RiskCheckType = Field(default=RiskCheckType.DAILY_LOSS_LIMIT, const=True)

    @validator("max_daily_loss", "warning_threshold_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class DailyProfitTargetLock(RiskConfiguration, frozen=True):
    """Lock trading after reaching daily profit target."""

    profit_target: Decimal = Field(..., gt=0, description="Daily profit target")
    check_type: RiskCheckType = Field(default=RiskCheckType.DAILY_PROFIT_TARGET_LOCK, const=True)

    @validator("profit_target", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class MaxTradesPerDayLimit(RiskConfiguration, frozen=True):
    """Maximum number of trades per day."""

    max_trades: int = Field(..., gt=0, description="Max trades per day")
    check_type: RiskCheckType = Field(default=RiskCheckType.MAX_TRADES_PER_DAY, const=True)


class MaxOrdersPerMinuteLimit(RiskConfiguration, frozen=True):
    """Maximum number of orders per minute."""

    max_orders: int = Field(..., gt=0, description="Max orders per minute")
    window_seconds: int = Field(default=60, gt=0, description="Throttle window in seconds")
    scope: str = Field(default="account", description="Scope: 'account' or 'instrument'")
    instrument_token: Optional[str] = Field(None, description="Instrument for instrument scope")
    check_type: RiskCheckType = Field(default=RiskCheckType.MAX_ORDERS_PER_MINUTE, const=True)


# ── Safety Configurations ──

class KillSwitchLimit(RiskConfiguration, frozen=True):
    """Emergency kill switch — when active, blocks all new orders."""

    allow_risk_reducing: bool = Field(default=False, description="Allow closing orders when active")
    check_type: RiskCheckType = Field(default=RiskCheckType.KILL_SWITCH, const=True)


class EmergencyHaltLimit(RiskConfiguration, frozen=True):
    """Emergency halt — immediate stop to all trading activity."""

    check_type: RiskCheckType = Field(default=RiskCheckType.EMERGENCY_HALT, const=True)


class CircuitBreakerLimit(RiskConfiguration, frozen=True):
    """Circuit breaker — halt trading after rapid portfolio decline."""

    max_decline_percent: Decimal = Field(..., gt=0, le=100, description="Max portfolio decline % to trigger")
    lookback_seconds: int = Field(default=300, gt=0, description="Lookback window in seconds")
    check_type: RiskCheckType = Field(default=RiskCheckType.CIRCUIT_BREAKER, const=True)

    @validator("max_decline_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


# ── Additional Configurations (for test compatibility) ──

class DuplicateOrderLimit(RiskConfiguration, frozen=True):
    """Prevent duplicate orders within a time window."""

    window_seconds: int = Field(default=5, gt=0, description="Duplicate detection window")
    check_type: RiskCheckType = Field(default=RiskCheckType.DUPLICATE_ORDER, const=True)


class SelfTradeLimit(RiskConfiguration, frozen=True):
    """Prevent self-trading (crossing own orders)."""

    check_type: RiskCheckType = Field(default=RiskCheckType.SELF_TRADE, const=True)


class DrawdownLimit(RiskConfiguration, frozen=True):
    """Monitor portfolio drawdown from peak equity."""

    max_drawdown_percent: Decimal = Field(..., gt=0, le=100, description="Max drawdown %")
    check_type: RiskCheckType = Field(default=RiskCheckType.DRAWDOWN, const=True)

    @validator("max_drawdown_percent", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


class TurnoverVelocityLimit(RiskConfiguration, frozen=True):
    """Monitor turnover velocity relative to equity."""

    max_velocity: Decimal = Field(..., gt=0, description="Max turnover/equity ratio")
    check_type: RiskCheckType = Field(default=RiskCheckType.TURNOVER_VELOCITY, const=True)

    @validator("max_velocity", pre=True)
    def _to_decimal(cls, v):
        if not isinstance(v, Decimal):
            return Decimal(str(v))
        return v


# ── Audit ──

class RiskAudit(BaseModel, frozen=True):
    """Immutable audit record of a risk engine decision.

    Every risk check produces an audit record for compliance and replay.
    """

    audit_id: str = Field(..., description="Unique audit record identifier")
    account_id: str = Field(..., description="Account being evaluated")
    order_id: Optional[str] = Field(None, description="Order identifier if applicable")
    approved: bool = Field(..., description="Whether the order was approved")
    violations: List[RiskViolation] = Field(default_factory=list, description="All violations")
    check_timestamp: datetime = Field(..., description="When the check was performed")
    context_snapshot: Dict[str, Any] = Field(default_factory=dict, description="Snapshot of evaluation context")


# ── State Snapshot ──

class RiskStateSnapshot(BaseModel, frozen=True):
    """Point-in-time snapshot of risk engine state for an account."""

    account_id: str = Field(..., description="Account identifier")
    snapshot_timestamp: datetime = Field(..., description="When this snapshot was taken")
    daily_realized_pnl: Decimal = Field(default=Decimal("0"), description="Cumulative realized P&L today")
    daily_turnover: Decimal = Field(default=Decimal("0"), description="Cumulative turnover today")
    trade_count: int = Field(default=0, description="Number of trades today")
    order_count: int = Field(default=0, description="Number of orders today")
    peak_equity: Decimal = Field(default=Decimal("0"), description="Highest equity seen today")
    message_counts: Dict[str, int] = Field(default_factory=dict, description="Message counts by throttle key")
    kill_switch_active: bool = Field(default=False, description="Whether kill switch is engaged")
    kill_switch_reason: Optional[str] = Field(None, description="Reason for kill switch activation")
    emergency_halt_active: bool = Field(default=False, description="Whether emergency halt is engaged")
    circuit_breaker_triggered: bool = Field(default=False, description="Whether circuit breaker fired")

    @validator("daily_realized_pnl", "daily_turnover", "peak_equity", pre=True)
    def _to_decimal(cls, v):
        if v is not None and not isinstance(v, Decimal):
            return Decimal(str(v))
        return v
