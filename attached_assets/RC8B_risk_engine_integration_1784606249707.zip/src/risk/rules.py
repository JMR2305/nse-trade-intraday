"""
Risk rule protocols and concrete implementations.

All risk rules implement the RiskRule Protocol. Rules are stateless evaluators
that receive a RiskRequest, RiskContext, RiskConfiguration, and RiskStateSnapshot,
and return a RiskViolation if the limit is breached, or None if the check passes.

Rules are deterministic and idempotent.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Protocol, Optional, Dict, Any, List
from datetime import datetime, timedelta
import hashlib
import json
import logging

from .contracts import (
    RiskViolation,
    RiskContext,
    RiskCheckType,
    RiskSeverity,
    RiskConfiguration,
    OrderQuantityLimit,
    OrderValueLimit,
    TickSizeLimit,
    PriceBandLimit,
    MaxPositionSizeLimit,
    InstrumentExposureLimit,
    NetExposureLimit,
    ConcentrationLimit,
    CashAvailabilityLimit,
    BuyingPowerLimit,
    PortfolioExposureLimit,
    MarginAvailabilityLimit,
    DailyLossLimit,
    DailyProfitTargetLock,
    MaxTradesPerDayLimit,
    MaxOrdersPerMinuteLimit,
    KillSwitchLimit,
    EmergencyHaltLimit,
    CircuitBreakerLimit,
    DuplicateOrderLimit,
    SelfTradeLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
    RiskStateSnapshot,
)

logger = logging.getLogger(__name__)


class RiskRule(Protocol):
    """Protocol for all risk check rules.

    Implementations must be stateless and deterministic.
    """

    def evaluate(
        self,
        request: Any,
        context: RiskContext,
        config: RiskConfiguration,
        state: RiskStateSnapshot,
    ) -> Optional[RiskViolation]:
        """Evaluate the risk rule against the given request, context, and state.

        Returns:
            RiskViolation if the limit is breached, None otherwise.
        """
        ...


# ── Pre-trade Risk Rules ──

class OrderQuantityRule:
    """Pre-trade: validates order quantity does not exceed max limit."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, OrderQuantityLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        quantity = self._get_quantity(order)
        instrument = self._get_instrument(order)
        if quantity is None:
            return None
        if config.instrument_token is not None and config.instrument_token != instrument:
            return None
        if quantity > config.max_quantity:
            logger.warning(f"Order quantity violation: {quantity} > {config.max_quantity} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.ORDER_QUANTITY,
                severity=config.severity,
                message=f"Order quantity {quantity} exceeds max {config.max_quantity}",
                rule_id=config.rule_id,
                limit_value=config.max_quantity,
                actual_value=quantity,
                metadata={"instrument_token": instrument},
            )
        return None

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)


class OrderValueRule:
    """Pre-trade: validates order notional value does not exceed limit."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, OrderValueLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        quantity = self._get_quantity(order)
        price = self._get_price(order)
        instrument = self._get_instrument(order)
        if quantity is None or price is None:
            return None
        if config.instrument_token is not None and config.instrument_token != instrument:
            return None
        notional = quantity * price
        if notional > config.max_value:
            logger.warning(f"Order value violation: {notional} > {config.max_value} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.ORDER_VALUE,
                severity=config.severity,
                message=f"Order value {notional} exceeds max {config.max_value}",
                rule_id=config.rule_id,
                limit_value=config.max_value,
                actual_value=notional,
                metadata={"instrument_token": instrument, "quantity": quantity, "price": price},
            )
        return None

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)


class TickSizeRule:
    """Pre-trade: validates order price is a multiple of tick size."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, TickSizeLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        price = self._get_price(order)
        instrument = self._get_instrument(order)
        order_type = self._get_order_type(order)
        if price is None or order_type in ("MARKET", "SL_M"):
            return None
        if config.instrument_token is not None and config.instrument_token != instrument:
            return None
        remainder = price % config.tick_size
        if remainder != Decimal("0"):
            logger.warning(f"Tick size violation: price={price}, tick={config.tick_size} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.TICK_SIZE,
                severity=config.severity,
                message=f"Price {price} is not a multiple of tick size {config.tick_size}",
                rule_id=config.rule_id,
                limit_value=config.tick_size,
                actual_value=remainder,
                metadata={"instrument_token": instrument, "price": price},
            )
        return None

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _get_order_type(order):
        if isinstance(order, dict):
            return order.get("order_type")
        ot = getattr(order, "order_type", None)
        if ot is not None:
            return str(ot)
        return None


class PriceBandRule:
    """Pre-trade: validates order price is within a band of the reference price."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, PriceBandLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        instrument = self._get_instrument(order)
        price = self._get_price(order)
        order_type = self._get_order_type(order)
        if price is None or order_type in ("MARKET", "SL_M"):
            return None
        if config.instrument_token is not None and config.instrument_token != instrument:
            return None
        ltp = context.market_prices.get(instrument)
        if ltp is None or ltp == 0:
            return None
        deviation_percent = (abs(price - ltp) / ltp) * Decimal("100")
        if deviation_percent > config.max_deviation_percent:
            logger.warning(f"Price band violation: {deviation_percent:.2f}% > {config.max_deviation_percent}% for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.PRICE_BAND,
                severity=config.severity,
                message=f"Price {price} deviates {deviation_percent:.2f}% from reference {ltp}, max allowed {config.max_deviation_percent}%",
                rule_id=config.rule_id,
                limit_value=config.max_deviation_percent,
                actual_value=deviation_percent,
                metadata={"instrument_token": instrument, "ltp": ltp, "price": price},
            )
        return None

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p

    @staticmethod
    def _get_order_type(order):
        if isinstance(order, dict):
            return order.get("order_type")
        ot = getattr(order, "order_type", None)
        if ot is not None:
            return str(ot)
        return None


# ── Position Risk Rules ──

class MaxPositionSizeRule:
    """Pre-trade: validates new order won't exceed position size limits."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, MaxPositionSizeLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        instrument = self._get_instrument(order)
        quantity = self._get_quantity(order)
        side = self._get_side(order)
        if instrument is None or quantity is None or side is None:
            return None
        if config.instrument_token != instrument:
            return None
        current_pos = context.position_snapshots.get(instrument)
        current_qty = Decimal("0")
        current_direction = "FLAT"
        if current_pos is not None:
            if isinstance(current_pos, dict):
                current_qty = current_pos.get("net_quantity", Decimal("0"))
                current_direction = current_pos.get("direction", "FLAT")
            else:
                current_qty = getattr(current_pos, "net_quantity", Decimal("0"))
                current_direction = getattr(current_pos, "direction", "FLAT")
            if not isinstance(current_qty, Decimal):
                current_qty = Decimal(str(current_qty))
        side_multiplier = Decimal("1") if side.upper() == "BUY" else Decimal("-1")
        projected_qty = current_qty + (quantity * side_multiplier)
        if projected_qty > config.max_long_quantity:
            logger.warning(f"Position limit violation: long {projected_qty} > {config.max_long_quantity} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.MAX_POSITION_SIZE,
                severity=config.severity,
                message=f"Projected long position {projected_qty} exceeds limit {config.max_long_quantity} for {instrument}",
                rule_id=config.rule_id,
                limit_value=config.max_long_quantity,
                actual_value=projected_qty,
                metadata={"instrument_token": instrument, "current_quantity": current_qty, "projected_quantity": projected_qty},
            )
        if projected_qty < -config.max_short_quantity:
            logger.warning(f"Position limit violation: short {abs(projected_qty)} > {config.max_short_quantity} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.MAX_POSITION_SIZE,
                severity=config.severity,
                message=f"Projected short position {abs(projected_qty)} exceeds limit {config.max_short_quantity} for {instrument}",
                rule_id=config.rule_id,
                limit_value=config.max_short_quantity,
                actual_value=abs(projected_qty),
                metadata={"instrument_token": instrument, "current_quantity": current_qty, "projected_quantity": projected_qty},
            )
        return None

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_side(order):
        if isinstance(order, dict):
            return order.get("side")
        side = getattr(order, "side", None)
        if side is not None:
            return str(side).upper()
        return None


class InstrumentExposureRule:
    """Pre-trade: validates instrument exposure doesn't exceed limit."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, InstrumentExposureLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        instrument = self._get_instrument(order)
        quantity = self._get_quantity(order)
        price = self._get_price(order)
        if instrument is None or quantity is None or price is None:
            return None
        if config.instrument_token != instrument:
            return None
        notional = quantity * price
        current_pos = context.position_snapshots.get(instrument)
        current_exposure = Decimal("0")
        if current_pos is not None:
            if isinstance(current_pos, dict):
                current_exposure = current_pos.get("market_value", Decimal("0"))
            else:
                current_exposure = getattr(current_pos, "market_value", Decimal("0"))
            if not isinstance(current_exposure, Decimal):
                current_exposure = Decimal(str(current_exposure))
        projected_exposure = current_exposure + notional
        if projected_exposure > config.max_exposure:
            logger.warning(f"Instrument exposure violation: {projected_exposure} > {config.max_exposure} for {instrument}")
            return RiskViolation(
                check_type=RiskCheckType.INSTRUMENT_EXPOSURE,
                severity=config.severity,
                message=f"Projected exposure {projected_exposure} for {instrument} exceeds limit {config.max_exposure}",
                rule_id=config.rule_id,
                limit_value=config.max_exposure,
                actual_value=projected_exposure,
                metadata={"instrument_token": instrument, "current_exposure": current_exposure, "order_notional": notional},
            )
        return None

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p


class NetExposureRule:
    """Pre-trade: validates total net exposure doesn't exceed limits."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, NetExposureLimit) or not config.enabled:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            total_long = portfolio.get("total_long_exposure", Decimal("0"))
            total_short = portfolio.get("total_short_exposure", Decimal("0"))
        else:
            total_long = getattr(portfolio, "total_long_exposure", Decimal("0"))
            total_short = getattr(portfolio, "total_short_exposure", Decimal("0"))
        if not isinstance(total_long, Decimal):
            total_long = Decimal(str(total_long))
        if not isinstance(total_short, Decimal):
            total_short = Decimal(str(total_short))
        if total_long > config.max_net_long:
            logger.warning(f"Net exposure violation: long {total_long} > {config.max_net_long}")
            return RiskViolation(
                check_type=RiskCheckType.NET_EXPOSURE,
                severity=config.severity,
                message=f"Net long exposure {total_long} exceeds limit {config.max_net_long}",
                rule_id=config.rule_id,
                limit_value=config.max_net_long,
                actual_value=total_long,
                metadata={"exposure_type": "long"},
            )
        if total_short > config.max_net_short:
            logger.warning(f"Net exposure violation: short {total_short} > {config.max_net_short}")
            return RiskViolation(
                check_type=RiskCheckType.NET_EXPOSURE,
                severity=config.severity,
                message=f"Net short exposure {total_short} exceeds limit {config.max_net_short}",
                rule_id=config.rule_id,
                limit_value=config.max_net_short,
                actual_value=total_short,
                metadata={"exposure_type": "short"},
            )
        return None


class ConcentrationRule:
    """Pre-trade: validates portfolio concentration per instrument."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, ConcentrationLimit) or not config.enabled:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            equity = portfolio.get("equity", Decimal("0"))
        else:
            equity = getattr(portfolio, "equity", Decimal("0"))
        if not isinstance(equity, Decimal):
            equity = Decimal(str(equity))
        if equity <= 0:
            return None
        for instrument, position in context.position_snapshots.items():
            if isinstance(position, dict):
                market_value = position.get("market_value", Decimal("0"))
            else:
                market_value = getattr(position, "market_value", Decimal("0"))
            if not isinstance(market_value, Decimal):
                market_value = Decimal(str(market_value))
            concentration = (market_value / equity) * Decimal("100")
            if concentration > config.max_concentration_percent:
                logger.warning(f"Concentration violation: {instrument} {concentration:.2f}% > {config.max_concentration_percent}%")
                return RiskViolation(
                    check_type=RiskCheckType.CONCENTRATION_LIMIT,
                    severity=config.severity,
                    message=f"Concentration in {instrument} {concentration:.2f}% exceeds limit {config.max_concentration_percent}%",
                    rule_id=config.rule_id,
                    limit_value=config.max_concentration_percent,
                    actual_value=concentration,
                    metadata={"instrument_token": instrument, "equity": equity},
                )
        return None


# ── Portfolio Risk Rules ──

class CashAvailabilityRule:
    """Pre-trade: validates sufficient cash is available."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, CashAvailabilityLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        side = self._get_side(order)
        if side != "BUY":
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            cash = portfolio.get("cash", Decimal("0"))
        else:
            cash = getattr(portfolio, "cash", Decimal("0"))
        if not isinstance(cash, Decimal):
            cash = Decimal(str(cash))
        quantity = self._get_quantity(order)
        price = self._get_price(order)
        if quantity is None or price is None:
            return None
        required = quantity * price
        if required > cash:
            logger.warning(f"Cash availability violation: required {required} > available {cash}")
            return RiskViolation(
                check_type=RiskCheckType.CASH_AVAILABILITY,
                severity=config.severity,
                message=f"Insufficient cash: required {required}, available {cash}",
                rule_id=config.rule_id,
                limit_value=cash,
                actual_value=required,
                metadata={"required": required, "available": cash},
            )
        return None

    @staticmethod
    def _get_side(order):
        if isinstance(order, dict):
            return order.get("side")
        side = getattr(order, "side", None)
        if side is not None:
            return str(side).upper()
        return None

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p


class BuyingPowerRule:
    """Pre-trade: validates order doesn't exceed available buying power."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, BuyingPowerLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        side = self._get_side(order)
        if side != "BUY":
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            buying_power = portfolio.get("buying_power", Decimal("0"))
        else:
            buying_power = getattr(portfolio, "buying_power", Decimal("0"))
        if not isinstance(buying_power, Decimal):
            buying_power = Decimal(str(buying_power))
        quantity = self._get_quantity(order)
        price = self._get_price(order)
        if quantity is None or price is None:
            return None
        required = quantity * price
        if required > buying_power:
            logger.warning(f"Buying power violation: required {required} > available {buying_power}")
            return RiskViolation(
                check_type=RiskCheckType.BUYING_POWER,
                severity=config.severity,
                message=f"Insufficient buying power: required {required}, available {buying_power}",
                rule_id=config.rule_id,
                limit_value=buying_power,
                actual_value=required,
                metadata={"required": required, "available": buying_power},
            )
        return None

    @staticmethod
    def _get_side(order):
        if isinstance(order, dict):
            return order.get("side")
        side = getattr(order, "side", None)
        if side is not None:
            return str(side).upper()
        return None

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p


class PortfolioExposureRule:
    """Pre-trade: validates total portfolio exposure doesn't exceed equity %."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, PortfolioExposureLimit) or not config.enabled:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            equity = portfolio.get("equity", Decimal("0"))
            total_market_value = portfolio.get("total_market_value", Decimal("0"))
        else:
            equity = getattr(portfolio, "equity", Decimal("0"))
            total_market_value = getattr(portfolio, "total_market_value", Decimal("0"))
        if not isinstance(equity, Decimal):
            equity = Decimal(str(equity))
        if not isinstance(total_market_value, Decimal):
            total_market_value = Decimal(str(total_market_value))
        if equity <= 0:
            return None
        exposure_percent = (total_market_value / equity) * Decimal("100")
        if exposure_percent > config.max_exposure_percent:
            logger.warning(f"Portfolio exposure violation: {exposure_percent:.2f}% > {config.max_exposure_percent}%")
            return RiskViolation(
                check_type=RiskCheckType.PORTFOLIO_EXPOSURE,
                severity=config.severity,
                message=f"Portfolio exposure {exposure_percent:.2f}% exceeds limit {config.max_exposure_percent}%",
                rule_id=config.rule_id,
                limit_value=config.max_exposure_percent,
                actual_value=exposure_percent,
                metadata={"equity": equity, "market_value": total_market_value},
            )
        return None


class MarginAvailabilityRule:
    """Pre-trade: validates sufficient margin is available."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, MarginAvailabilityLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            available_margin = portfolio.get("available_margin", Decimal("0"))
        else:
            available_margin = getattr(portfolio, "available_margin", Decimal("0"))
        if not isinstance(available_margin, Decimal):
            available_margin = Decimal(str(available_margin))
        quantity = self._get_quantity(order)
        price = self._get_price(order)
        if quantity is None or price is None:
            return None
        required_margin = quantity * price * Decimal("0.2")
        if required_margin > available_margin:
            logger.warning(f"Margin availability violation: required {required_margin} > available {available_margin}")
            return RiskViolation(
                check_type=RiskCheckType.MARGIN_AVAILABILITY,
                severity=config.severity,
                message=f"Insufficient margin: required {required_margin}, available {available_margin}",
                rule_id=config.rule_id,
                limit_value=available_margin,
                actual_value=required_margin,
                metadata={"required": required_margin, "available": available_margin},
            )
        return None

    @staticmethod
    def _get_quantity(order):
        if isinstance(order, dict):
            qty = order.get("quantity")
        else:
            qty = getattr(order, "quantity", None)
        if qty is not None and not isinstance(qty, Decimal):
            return Decimal(str(qty))
        return qty

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p


# ── Daily Control Rules ──

class DailyLossLimitRule:
    """Pre-trade: blocks new orders if daily loss limit is breached."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, DailyLossLimit) or not config.enabled:
            return None
        daily_pnl = state.daily_realized_pnl
        if daily_pnl >= 0:
            return None
        loss_amount = abs(daily_pnl)
        if loss_amount >= config.max_daily_loss:
            logger.critical(f"Daily loss limit FATAL: {loss_amount} >= {config.max_daily_loss}")
            return RiskViolation(
                check_type=RiskCheckType.DAILY_LOSS_LIMIT,
                severity=RiskSeverity.FATAL,
                message=f"Daily loss {loss_amount} has reached limit {config.max_daily_loss}. Trading halted.",
                rule_id=config.rule_id,
                limit_value=config.max_daily_loss,
                actual_value=loss_amount,
                metadata={"daily_pnl": daily_pnl},
            )
        warning_threshold = config.max_daily_loss * (config.warning_threshold_percent / Decimal("100"))
        if loss_amount >= warning_threshold:
            logger.warning(f"Daily loss warning: {loss_amount} >= {warning_threshold}")
            return RiskViolation(
                check_type=RiskCheckType.DAILY_LOSS_LIMIT,
                severity=RiskSeverity.WARNING,
                message=f"Daily loss {loss_amount} at {config.warning_threshold_percent}% of limit {config.max_daily_loss}",
                rule_id=config.rule_id,
                limit_value=warning_threshold,
                actual_value=loss_amount,
                metadata={"daily_pnl": daily_pnl, "threshold": warning_threshold},
            )
        return None


class DailyProfitTargetLockRule:
    """Pre-trade: locks trading after reaching daily profit target."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, DailyProfitTargetLock) or not config.enabled:
            return None
        daily_pnl = state.daily_realized_pnl
        if daily_pnl <= 0:
            return None
        if daily_pnl >= config.profit_target:
            logger.warning(f"Profit target lock: {daily_pnl} >= {config.profit_target}")
            return RiskViolation(
                check_type=RiskCheckType.DAILY_PROFIT_TARGET_LOCK,
                severity=RiskSeverity.CRITICAL,
                message=f"Daily profit target reached: {daily_pnl} >= {config.profit_target}. Trading locked for the day.",
                rule_id=config.rule_id,
                limit_value=config.profit_target,
                actual_value=daily_pnl,
                metadata={"daily_pnl": daily_pnl},
            )
        return None


class MaxTradesPerDayRule:
    """Pre-trade: blocks new orders if max trades per day exceeded."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, MaxTradesPerDayLimit) or not config.enabled:
            return None
        if state.trade_count >= config.max_trades:
            logger.warning(f"Max trades per day: {state.trade_count} >= {config.max_trades}")
            return RiskViolation(
                check_type=RiskCheckType.MAX_TRADES_PER_DAY,
                severity=config.severity,
                message=f"Trade count {state.trade_count} exceeds daily limit {config.max_trades}",
                rule_id=config.rule_id,
                limit_value=Decimal(config.max_trades),
                actual_value=Decimal(state.trade_count),
                metadata={"trade_count": state.trade_count},
            )
        return None


class MaxOrdersPerMinuteRule:
    """Pre-trade: throttles order rate per minute."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, MaxOrdersPerMinuteLimit) or not config.enabled:
            return None
        key = self._build_throttle_key(context, config)
        if key is None:
            return None
        count = state.message_counts.get(key, 0)
        if count >= config.max_orders:
            logger.warning(f"Order throttled: {count}/min >= {config.max_orders}/min for key {key}")
            return RiskViolation(
                check_type=RiskCheckType.MAX_ORDERS_PER_MINUTE,
                severity=config.severity,
                message=f"Order rate {count}/min exceeds limit {config.max_orders}/min",
                rule_id=config.rule_id,
                limit_value=Decimal(config.max_orders),
                actual_value=Decimal(count),
                metadata={"orders_per_minute": count, "throttle_key": key},
            )
        return None

    @staticmethod
    def _build_throttle_key(context, config):
        if config.scope == "instrument":
            order = context.order
            if order is None:
                return None
            instrument = None
            if isinstance(order, dict):
                instrument = order.get("instrument_token")
            else:
                instrument = getattr(order, "instrument_token", None)
            if instrument is None:
                return None
            return f"instrument:{instrument}"
        return f"account:{context.account_id}"


# ── Safety Rules ──

class KillSwitchRule:
    """Pre-trade: emergency kill switch blocks all new orders."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, KillSwitchLimit) or not config.enabled:
            return None
        if not state.kill_switch_active:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        side = self._get_side(order) if order else "BUY"
        if config.allow_risk_reducing:
            current_direction = self._get_current_direction(order, context.position_snapshots)
            if self._is_risk_reducing(side, current_direction):
                return None
        logger.critical(f"Kill switch active for {context.account_id}: {state.kill_switch_reason}")
        return RiskViolation(
            check_type=RiskCheckType.KILL_SWITCH,
            severity=RiskSeverity.FATAL,
            message=f"Kill switch active: {state.kill_switch_reason}. All new orders blocked.",
            rule_id=config.rule_id,
            metadata={"reason": state.kill_switch_reason, "allow_risk_reducing": config.allow_risk_reducing},
        )

    @staticmethod
    def _get_side(order):
        if isinstance(order, dict):
            return (order.get("side") or "BUY").upper()
        side = getattr(order, "side", "BUY")
        return str(side).upper()

    @staticmethod
    def _get_current_direction(order, positions):
        if positions is None or order is None:
            return "FLAT"
        instrument = None
        if isinstance(order, dict):
            instrument = order.get("instrument_token")
        else:
            instrument = getattr(order, "instrument_token", None)
        if instrument is None:
            return "FLAT"
        pos = positions.get(instrument)
        if pos is None:
            return "FLAT"
        if isinstance(pos, dict):
            return (pos.get("direction") or "FLAT").upper()
        return str(getattr(pos, "direction", "FLAT")).upper()

    @staticmethod
    def _is_risk_reducing(side, direction):
        side = side.upper()
        direction = direction.upper()
        if direction == "FLAT":
            return False
        elif direction == "LONG":
            return side == "SELL"
        elif direction == "SHORT":
            return side == "BUY"
        return False


class EmergencyHaltRule:
    """Pre-trade: emergency halt blocks all trading activity."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, EmergencyHaltLimit) or not config.enabled:
            return None
        if not state.emergency_halt_active:
            return None
        logger.critical(f"Emergency halt active for {context.account_id}")
        return RiskViolation(
            check_type=RiskCheckType.EMERGENCY_HALT,
            severity=RiskSeverity.FATAL,
            message="Emergency halt is active. All trading suspended.",
            rule_id=config.rule_id,
            metadata={},
        )


class CircuitBreakerRule:
    """Pre-trade: circuit breaker halts trading after rapid portfolio decline."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, CircuitBreakerLimit) or not config.enabled:
            return None
        if not state.circuit_breaker_triggered:
            return None
        logger.critical(f"Circuit breaker triggered for {context.account_id}")
        return RiskViolation(
            check_type=RiskCheckType.CIRCUIT_BREAKER,
            severity=RiskSeverity.FATAL,
            message=f"Circuit breaker triggered. Trading halted due to portfolio decline exceeding {config.max_decline_percent}%",
            rule_id=config.rule_id,
            limit_value=config.max_decline_percent,
            metadata={"lookback_seconds": config.lookback_seconds},
        )


# ── Additional Rules (for test compatibility) ──

class DuplicateOrderRule:
    """Pre-trade: prevents duplicate orders within a time window.

    This rule maintains internal state to track recently seen orders.
    Call reset() between test runs for determinism.
    """

    def __init__(self):
        self._seen_orders: Dict[str, datetime] = {}

    def evaluate(self, request, context, config, state):
        if not isinstance(config, DuplicateOrderLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None

        key = self._build_key(order)
        now = state.snapshot_timestamp if state else datetime.now(timezone.utc)

        # Clean expired entries
        window = timedelta(seconds=config.window_seconds)
        expired = [k for k, ts in self._seen_orders.items() if now - ts > window]
        for k in expired:
            del self._seen_orders[k]

        if key in self._seen_orders:
            logger.warning(f"Duplicate order detected: {key}")
            return RiskViolation(
                check_type=RiskCheckType.DUPLICATE_ORDER,
                severity=config.severity,
                message=f"Duplicate order detected within {config.window_seconds}s window",
                rule_id=config.rule_id,
                metadata={"window_seconds": config.window_seconds},
            )

        self._seen_orders[key] = now
        return None

    @staticmethod
    def _build_key(order):
        if isinstance(order, dict):
            parts = [
                str(order.get("instrument_token", "")),
                str(order.get("side", "")),
                str(order.get("quantity", "")),
                str(order.get("price", "")),
            ]
        else:
            parts = [
                str(getattr(order, "instrument_token", "")),
                str(getattr(order, "side", "")),
                str(getattr(order, "quantity", "")),
                str(getattr(order, "price", "")),
            ]
        return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]

    def reset(self):
        """Clear internal state for deterministic replay testing."""
        self._seen_orders.clear()


class SelfTradeRule:
    """Pre-trade: prevents self-trading (crossing own orders)."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, SelfTradeLimit) or not config.enabled:
            return None
        order = request.order if hasattr(request, "order") else request.get("order") if isinstance(request, dict) else request
        if order is None:
            return None

        instrument = self._get_instrument(order)
        side = self._get_side(order)
        price = self._get_price(order)

        if instrument is None or side is None:
            return None

        for open_order in context.open_orders:
            open_instrument = self._get_instrument(open_order)
            open_side = self._get_side(open_order)
            open_price = self._get_price(open_order)

            if open_instrument != instrument:
                continue
            if open_side == side:
                continue

            # Cross check: BUY order price >= SELL open order price (or vice versa)
            if price is not None and open_price is not None:
                if side == "BUY" and price >= open_price:
                    logger.warning(f"Self-trade detected: {instrument} {side}@{price} crosses {open_side}@{open_price}")
                    return RiskViolation(
                        check_type=RiskCheckType.SELF_TRADE,
                        severity=config.severity,
                        message=f"Self-trade risk: {side} order at {price} crosses existing {open_side} at {open_price}",
                        rule_id=config.rule_id,
                        metadata={"instrument_token": instrument, "order_price": price, "open_price": open_price},
                    )
                elif side == "SELL" and price <= open_price:
                    logger.warning(f"Self-trade detected: {instrument} {side}@{price} crosses {open_side}@{open_price}")
                    return RiskViolation(
                        check_type=RiskCheckType.SELF_TRADE,
                        severity=config.severity,
                        message=f"Self-trade risk: {side} order at {price} crosses existing {open_side} at {open_price}",
                        rule_id=config.rule_id,
                        metadata={"instrument_token": instrument, "order_price": price, "open_price": open_price},
                    )
        return None

    @staticmethod
    def _get_instrument(order):
        if isinstance(order, dict):
            return order.get("instrument_token")
        return getattr(order, "instrument_token", None)

    @staticmethod
    def _get_side(order):
        if isinstance(order, dict):
            side = order.get("side")
        else:
            side = getattr(order, "side", None)
        if side is not None:
            return str(side).upper()
        return None

    @staticmethod
    def _get_price(order):
        if isinstance(order, dict):
            p = order.get("price")
        else:
            p = getattr(order, "price", None)
        if p is not None and not isinstance(p, Decimal):
            return Decimal(str(p))
        return p


class DrawdownRule:
    """Post-trade: monitors portfolio drawdown from peak equity."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, DrawdownLimit) or not config.enabled:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            equity = portfolio.get("equity", Decimal("0"))
        else:
            equity = getattr(portfolio, "equity", Decimal("0"))
        if not isinstance(equity, Decimal):
            equity = Decimal(str(equity))
        if equity <= 0 or state.peak_equity <= 0:
            return None

        drawdown_percent = ((state.peak_equity - equity) / state.peak_equity) * Decimal("100")
        if drawdown_percent >= config.max_drawdown_percent:
            logger.critical(f"Drawdown FATAL: {drawdown_percent:.2f}% >= {config.max_drawdown_percent}%")
            return RiskViolation(
                check_type=RiskCheckType.DRAWDOWN,
                severity=RiskSeverity.FATAL,
                message=f"Portfolio drawdown {drawdown_percent:.2f}% exceeds limit {config.max_drawdown_percent}%",
                rule_id=config.rule_id,
                limit_value=config.max_drawdown_percent,
                actual_value=drawdown_percent,
                metadata={"peak_equity": state.peak_equity, "current_equity": equity},
            )
        elif drawdown_percent >= config.max_drawdown_percent * Decimal("0.8"):
            logger.warning(f"Drawdown warning: {drawdown_percent:.2f}%")
            return RiskViolation(
                check_type=RiskCheckType.DRAWDOWN,
                severity=RiskSeverity.WARNING,
                message=f"Portfolio drawdown {drawdown_percent:.2f}% approaching limit {config.max_drawdown_percent}%",
                rule_id=config.rule_id,
                limit_value=config.max_drawdown_percent,
                actual_value=drawdown_percent,
                metadata={"peak_equity": state.peak_equity, "current_equity": equity},
            )
        return None


class TurnoverVelocityRule:
    """Post-trade: monitors turnover velocity relative to equity."""

    def evaluate(self, request, context, config, state):
        if not isinstance(config, TurnoverVelocityLimit) or not config.enabled:
            return None
        portfolio = context.portfolio_snapshot
        if portfolio is None:
            return None
        if isinstance(portfolio, dict):
            equity = portfolio.get("equity", Decimal("0"))
        else:
            equity = getattr(portfolio, "equity", Decimal("0"))
        if not isinstance(equity, Decimal):
            equity = Decimal(str(equity))
        if equity <= 0:
            return None

        velocity = state.daily_turnover / equity
        if velocity > config.max_velocity:
            logger.warning(f"Turnover velocity: {velocity:.2f}x > {config.max_velocity}x")
            return RiskViolation(
                check_type=RiskCheckType.TURNOVER_VELOCITY,
                severity=config.severity,
                message=f"Turnover velocity {velocity:.2f}x exceeds limit {config.max_velocity}x",
                rule_id=config.rule_id,
                limit_value=config.max_velocity,
                actual_value=velocity,
                metadata={"daily_turnover": state.daily_turnover, "equity": equity},
            )
        return None


# Registry mapping check types to rule implementations
RULE_REGISTRY: Dict[RiskCheckType, RiskRule] = {
    # Pre-trade Risk
    RiskCheckType.ORDER_QUANTITY: OrderQuantityRule(),
    RiskCheckType.ORDER_VALUE: OrderValueRule(),
    RiskCheckType.TICK_SIZE: TickSizeRule(),
    RiskCheckType.PRICE_BAND: PriceBandRule(),
    # Position Risk
    RiskCheckType.MAX_POSITION_SIZE: MaxPositionSizeRule(),
    RiskCheckType.INSTRUMENT_EXPOSURE: InstrumentExposureRule(),
    RiskCheckType.NET_EXPOSURE: NetExposureRule(),
    RiskCheckType.CONCENTRATION_LIMIT: ConcentrationRule(),
    # Portfolio Risk
    RiskCheckType.CASH_AVAILABILITY: CashAvailabilityRule(),
    RiskCheckType.BUYING_POWER: BuyingPowerRule(),
    RiskCheckType.PORTFOLIO_EXPOSURE: PortfolioExposureRule(),
    RiskCheckType.MARGIN_AVAILABILITY: MarginAvailabilityRule(),
    # Daily Controls
    RiskCheckType.DAILY_LOSS_LIMIT: DailyLossLimitRule(),
    RiskCheckType.DAILY_PROFIT_TARGET_LOCK: DailyProfitTargetLockRule(),
    RiskCheckType.MAX_TRADES_PER_DAY: MaxTradesPerDayRule(),
    RiskCheckType.MAX_ORDERS_PER_MINUTE: MaxOrdersPerMinuteRule(),
    # Safety
    RiskCheckType.KILL_SWITCH: KillSwitchRule(),
    RiskCheckType.EMERGENCY_HALT: EmergencyHaltRule(),
    RiskCheckType.CIRCUIT_BREAKER: CircuitBreakerRule(),
    # Additional
    RiskCheckType.DUPLICATE_ORDER: DuplicateOrderRule(),
    RiskCheckType.SELF_TRADE: SelfTradeRule(),
    RiskCheckType.DRAWDOWN: DrawdownRule(),
    RiskCheckType.TURNOVER_VELOCITY: TurnoverVelocityRule(),
}
