"""
Risk State Repository.

Follows the session-injected pattern: caller provides AsyncSession,
repository never commits. Hydration methods reconstruct domain objects
from ORM records without coupling domain to ORM.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional
from datetime import datetime
import logging

from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.risk_state import RiskStateModel
from ...risk.contracts import RiskStateSnapshot

logger = logging.getLogger(__name__)


class RiskStateRepository:
    """Repository for risk state snapshot persistence."""

    async def save(self, snapshot: RiskStateSnapshot, session: AsyncSession) -> RiskStateModel:
        """Save or update a risk state snapshot."""
        # Check for existing snapshot with same account_id and timestamp
        stmt = (
            select(RiskStateModel)
            .where(RiskStateModel.account_id == snapshot.account_id)
            .where(RiskStateModel.snapshot_timestamp == snapshot.snapshot_timestamp)
        )
        result = await session.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing is not None:
            # Update existing
            existing.daily_realized_pnl = snapshot.daily_realized_pnl
            existing.daily_turnover = snapshot.daily_turnover
            existing.peak_equity = snapshot.peak_equity
            existing.trade_count = snapshot.trade_count
            existing.order_count = snapshot.order_count
            existing.kill_switch_active = snapshot.kill_switch_active
            existing.kill_switch_reason = snapshot.kill_switch_reason
            existing.emergency_halt_active = snapshot.emergency_halt_active
            existing.circuit_breaker_triggered = snapshot.circuit_breaker_triggered
            existing.message_counts = dict(snapshot.message_counts)
            logger.debug(f"Updated existing snapshot for {snapshot.account_id}")
            return existing

        # Create new
        model = RiskStateModel(
            account_id=snapshot.account_id,
            snapshot_timestamp=snapshot.snapshot_timestamp,
            daily_realized_pnl=snapshot.daily_realized_pnl,
            daily_turnover=snapshot.daily_turnover,
            peak_equity=snapshot.peak_equity,
            trade_count=snapshot.trade_count,
            order_count=snapshot.order_count,
            kill_switch_active=snapshot.kill_switch_active,
            kill_switch_reason=snapshot.kill_switch_reason,
            emergency_halt_active=snapshot.emergency_halt_active,
            circuit_breaker_triggered=snapshot.circuit_breaker_triggered,
            message_counts=dict(snapshot.message_counts),
        )
        session.add(model)
        logger.debug(f"Created new snapshot for {snapshot.account_id}")
        return model

    async def load_latest(
        self,
        account_id: str,
        session: AsyncSession,
    ) -> Optional[RiskStateSnapshot]:
        """Load the most recent risk state snapshot for an account."""
        stmt = (
            select(RiskStateModel)
            .where(RiskStateModel.account_id == account_id)
            .order_by(desc(RiskStateModel.snapshot_timestamp))
            .limit(1)
        )
        result = await session.execute(stmt)
        model = result.scalar_one_or_none()

        if model is None:
            logger.warning(f"No snapshot found for account {account_id}")
            return None

        return self._hydrate_snapshot(model)

    async def load_all_for_account(
        self,
        account_id: str,
        session: AsyncSession,
        limit: int = 100,
    ) -> list:
        """Load all snapshots for an account, newest first."""
        stmt = (
            select(RiskStateModel)
            .where(RiskStateModel.account_id == account_id)
            .order_by(desc(RiskStateModel.snapshot_timestamp))
            .limit(limit)
        )
        result = await session.execute(stmt)
        models = result.scalars().all()
        return [self._hydrate_snapshot(m) for m in models]

    @staticmethod
    def _hydrate_snapshot(model: RiskStateModel) -> RiskStateSnapshot:
        """Reconstruct RiskStateSnapshot from ORM model.

        FAIL-SAFE: If safety state fields are NULL in the database,
        treat as tripped (True) rather than clear (False). This ensures
        that a corrupted or legacy row never silently clears an active
        emergency halt or circuit breaker.
        """
        # Explicit None check: NULL column yields None, not missing attribute
        _emergency_halt = model.emergency_halt_active
        emergency_halt = True if _emergency_halt is None else bool(_emergency_halt)

        _circuit_breaker = model.circuit_breaker_triggered
        circuit_breaker = True if _circuit_breaker is None else bool(_circuit_breaker)

        # Same pattern for count fields (default to 0 is safe for counts)
        _trade_count = getattr(model, 'trade_count', None)
        trade_count = 0 if _trade_count is None else int(_trade_count)

        _order_count = getattr(model, 'order_count', None)
        order_count = 0 if _order_count is None else int(_order_count)

        snapshot = RiskStateSnapshot(
            account_id=model.account_id,
            snapshot_timestamp=model.snapshot_timestamp,
            daily_realized_pnl=Decimal(str(model.daily_realized_pnl)),
            daily_turnover=Decimal(str(model.daily_turnover)),
            peak_equity=Decimal(str(model.peak_equity)),
            trade_count=trade_count,
            order_count=order_count,
            message_counts=dict(model.message_counts or {}),
            kill_switch_active=bool(model.kill_switch_active),
            kill_switch_reason=model.kill_switch_reason,
            emergency_halt_active=emergency_halt,
            circuit_breaker_triggered=circuit_breaker,
        )
        logger.info(f"Hydrated snapshot for {model.account_id} (halt={emergency_halt}, cb={circuit_breaker})")
        return snapshot
