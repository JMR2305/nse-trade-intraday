"""
Risk State ORM Model.

SQLAlchemy declarative model for persisting risk engine state snapshots.
Inherits from the shared Base in database/models/base.py.

All monetary columns use Numeric(20, 8) for Decimal fidelity.
All timestamps are DateTime(timezone=True).
"""

from __future__ import annotations

from sqlalchemy import Column, String, DateTime, Numeric, Boolean, Text, Index
from sqlalchemy.dialects.postgresql import UUID, JSONB
import uuid

# INTEGRATION NOTE: When merging into the main project, replace the line below with:
#   from database.models.base import Base
# The standalone distribution uses a local Base for self-contained testing only.
# All project ORM models MUST share the same declarative_base() instance.
try:
    from database.models.base import Base
except ImportError:
    from sqlalchemy.orm import declarative_base
    Base = declarative_base()


class RiskStateModel(Base):
    """ORM model for risk_state_snapshots table.

    Stores point-in-time snapshots of RiskState for crash recovery.
    Each row represents one snapshot for one account.
    """

    __tablename__ = "risk_state_snapshots"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    account_id = Column(String(64), nullable=False, index=True)
    snapshot_timestamp = Column(DateTime(timezone=True), nullable=False, index=True)

    # Monetary fields — Decimal precision
    daily_realized_pnl = Column(Numeric(20, 8), nullable=False, default=0)
    daily_turnover = Column(Numeric(20, 8), nullable=False, default=0)
    peak_equity = Column(Numeric(20, 8), nullable=False, default=0)

    # Count fields
    trade_count = Column(Numeric(20, 0), nullable=False, default=0)
    order_count = Column(Numeric(20, 0), nullable=False, default=0)

    # Kill switch state
    kill_switch_active = Column(Boolean, nullable=False, default=False)
    kill_switch_reason = Column(Text, nullable=True)

    # Emergency halt state
    emergency_halt_active = Column(Boolean, nullable=False, default=False)

    # Circuit breaker state
    circuit_breaker_triggered = Column(Boolean, nullable=False, default=False)

    # Message counts stored as JSONB
    message_counts = Column(JSONB, nullable=False, default=dict)

    # Extra metadata for extensibility — renamed from "metadata" to avoid
    # shadowing SQLAlchemy's reserved Table.metadata attribute.
    extra_data = Column(JSONB, nullable=False, default=dict)

    __table_args__ = (
        # Composite index for efficient latest-snapshot lookups per account
        Index("ix_risk_state_account_timestamp", "account_id", "snapshot_timestamp"),
    )
