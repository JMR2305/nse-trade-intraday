"""StrategySignal ORM model — persists signals emitted by strategies."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    Column,
    DateTime,
    String,
    Text,
    Numeric,
    JSON,
    Index,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from database.models.base import Base


class StrategySignalModel(Base):
    """ORM model for the strategy_signals table.

    Stores every signal emitted by a strategy, including its routing status,
    the client_order_id assigned on successful routing, and any rejection reason.
    signal_id is unique per signal so replay is idempotent.
    """

    __tablename__ = "strategy_signals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    signal_id = Column(String(64), nullable=False, unique=True, index=True)
    strategy_id = Column(String(64), nullable=False, index=True)
    account_id = Column(String(64), nullable=False, index=True)
    instrument_token = Column(String(32), nullable=False, index=True)
    action = Column(String(16), nullable=False)
    side = Column(String(8), nullable=False)
    quantity = Column(Numeric(20, 8), nullable=False)
    order_type = Column(String(16), nullable=False)
    limit_price = Column(Numeric(20, 8), nullable=True)
    trigger_price = Column(Numeric(20, 8), nullable=True)
    timestamp = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    routing_status = Column(String(16), nullable=False, default="PENDING")
    routed_client_order_id = Column(String(64), nullable=True, index=True)
    rejection_reason = Column(Text, nullable=True)
    metadata = Column(JSON, nullable=False, default=dict)

    __table_args__ = (
        UniqueConstraint("signal_id", name="uq_strategy_signals_signal_id"),
        Index(
            "ix_strategy_signals_strategy_status",
            "strategy_id",
            "routing_status",
        ),
        Index(
            "ix_strategy_signals_pending",
            "routing_status",
            "timestamp",
        ),
    )
