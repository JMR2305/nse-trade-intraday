"""StrategyState ORM model — persists point-in-time strategy snapshots."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Column,
    DateTime,
    String,
    Numeric,
    JSON,
    Index,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from database.models.base import Base


class StrategyStateModel(Base):
    """ORM model for the strategy_state_snapshots table.

    Stores a point-in-time snapshot of a strategy's runtime counters,
    pending order IDs, and latest signal timestamp.  Used by recovery
    to reconstruct strategy state after a restart.
    """

    __tablename__ = "strategy_state_snapshots"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    strategy_id = Column(String(64), nullable=False, index=True)
    lifecycle_state = Column(String(32), nullable=False)
    pending_order_ids = Column(JSON, nullable=False, default=list)
    latest_signal_timestamp = Column(DateTime(timezone=True), nullable=True)
    emitted_signal_count = Column(Numeric(20, 0), nullable=False, default=0)
    routed_signal_count = Column(Numeric(20, 0), nullable=False, default=0)
    rejected_signal_count = Column(Numeric(20, 0), nullable=False, default=0)
    fill_count = Column(Numeric(20, 0), nullable=False, default=0)
    metadata = Column(JSON, nullable=False, default=dict)
    snapshot_timestamp = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        UniqueConstraint(
            "strategy_id",
            "snapshot_timestamp",
            name="uq_strategy_state_snapshots_strategy_timestamp",
        ),
        Index(
            "ix_strategy_state_snapshots_strategy_latest",
            "strategy_id",
            "snapshot_timestamp",
        ),
    )
