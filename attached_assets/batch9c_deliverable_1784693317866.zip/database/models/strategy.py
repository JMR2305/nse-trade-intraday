"""Strategy ORM model — persists strategy registration and configuration."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List

from sqlalchemy import (
    Column,
    DateTime,
    String,
    Text,
    Boolean,
    JSON,
    Index,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from database.models.base import Base


class StrategyModel(Base):
    """ORM model for the strategies table.

    Stores strategy registration, type, configuration, instrument tokens,
    lifecycle state, and timestamps.  strategy_id is the natural key and
    carries a unique constraint so recovery can rely on it for idempotency.
    """

    __tablename__ = "strategies"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    strategy_id = Column(String(64), nullable=False, unique=True, index=True)
    strategy_type = Column(String(64), nullable=False)
    name = Column(String(255), nullable=False)
    account_id = Column(String(64), nullable=False, index=True)
    configuration = Column(JSON, nullable=False, default=dict)
    instrument_tokens = Column(JSON, nullable=False, default=list)
    lifecycle_state = Column(String(32), nullable=False, index=True)
    enabled = Column(Boolean, nullable=False, default=True)
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        UniqueConstraint("strategy_id", name="uq_strategies_strategy_id"),
        Index("ix_strategies_account_lifecycle", "account_id", "lifecycle_state"),
        Index("ix_strategies_type_state", "strategy_type", "lifecycle_state"),
    )
