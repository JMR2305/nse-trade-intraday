"""StrategyStateRepository — session-injected CRUD for StrategyStateModel."""
from __future__ import annotations

from decimal import Decimal
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models.strategy_state import StrategyStateModel


class StrategyStateRepository:
    """Async repository for strategy state snapshot persistence.

    Follows the project-wide contract:
    - AsyncSession is injected by the caller.
    - No commit, rollback, or close.
    - Domain objects hydrated without coupling ORM to domain contracts.
    """

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------
    async def save(
        self,
        strategy_id: str,
        lifecycle_state: str,
        pending_order_ids: List[str],
        latest_signal_timestamp: Optional[datetime],
        emitted_signal_count: int,
        routed_signal_count: int,
        rejected_signal_count: int,
        fill_count: int,
        metadata: Optional[Dict[str, Any]],
        snapshot_timestamp: Optional[datetime] = None,
        session: AsyncSession,
    ) -> StrategyStateModel:
        """Insert a new strategy state snapshot.

        Snapshots are append-only; we do not upsert.  The unique constraint
        on (strategy_id, snapshot_timestamp) prevents accidental duplicates
        within the same microsecond.
        """
        now = datetime.now(timezone.utc)
        model = StrategyStateModel(
            strategy_id=strategy_id,
            lifecycle_state=lifecycle_state,
            pending_order_ids=list(pending_order_ids),
            latest_signal_timestamp=latest_signal_timestamp,
            emitted_signal_count=Decimal(emitted_signal_count),
            routed_signal_count=Decimal(routed_signal_count),
            rejected_signal_count=Decimal(rejected_signal_count),
            fill_count=Decimal(fill_count),
            metadata=metadata or {},
            snapshot_timestamp=snapshot_timestamp or now,
        )
        session.add(model)
        return model

    # ------------------------------------------------------------------
    # Load latest snapshot for a strategy
    # ------------------------------------------------------------------
    async def load_latest(
        self,
        strategy_id: str,
        session: AsyncSession,
    ) -> Optional[StrategyStateModel]:
        """Return the most recent snapshot for a given strategy_id."""
        result = await session.execute(
            select(StrategyStateModel)
            .where(StrategyStateModel.strategy_id == strategy_id)
            .order_by(StrategyStateModel.snapshot_timestamp.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # List all snapshots for a strategy
    # ------------------------------------------------------------------
    async def list_by_strategy(
        self,
        strategy_id: str,
        session: AsyncSession,
    ) -> List[StrategyStateModel]:
        """Return all snapshots for a strategy, newest first."""
        result = await session.execute(
            select(StrategyStateModel)
            .where(StrategyStateModel.strategy_id == strategy_id)
            .order_by(StrategyStateModel.snapshot_timestamp.desc())
        )
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # List latest snapshot for every strategy (batch recovery helper)
    # ------------------------------------------------------------------
    async def list_latest_all(
        self,
        session: AsyncSession,
    ) -> List[StrategyStateModel]:
        """Return the latest snapshot for every strategy_id.

        Uses a correlated subquery to pick the max timestamp per strategy.
        """
        subq = (
            select(
                StrategyStateModel.strategy_id,
                select(StrategyStateModel.snapshot_timestamp)
                .where(StrategyStateModel.strategy_id == StrategyStateModel.strategy_id)
                .order_by(StrategyStateModel.snapshot_timestamp.desc())
                .limit(1)
                .scalar_subquery()
                .label("max_ts"),
            )
            .distinct()
            .subquery()
        )
        # Simpler approach: select all, group in Python — acceptable for recovery.
        result = await session.execute(
            select(StrategyStateModel).order_by(
                StrategyStateModel.strategy_id,
                StrategyStateModel.snapshot_timestamp.desc(),
            )
        )
        all_rows = list(result.scalars().all())
        # Keep first (latest) per strategy_id
        seen: set = set()
        latest: List[StrategyStateModel] = []
        for row in all_rows:
            if row.strategy_id not in seen:
                seen.add(row.strategy_id)
                latest.append(row)
        return latest

    # ------------------------------------------------------------------
    # Hydration helper
    # ------------------------------------------------------------------
    @staticmethod
    def to_dict(model: StrategyStateModel) -> Dict[str, Any]:
        """Serialize an ORM model to a plain dict suitable for domain reconstruction."""
        return {
            "strategy_id": model.strategy_id,
            "lifecycle_state": model.lifecycle_state,
            "pending_order_ids": list(model.pending_order_ids) if model.pending_order_ids else [],
            "latest_signal_timestamp": model.latest_signal_timestamp,
            "emitted_signal_count": int(model.emitted_signal_count),
            "routed_signal_count": int(model.routed_signal_count),
            "rejected_signal_count": int(model.rejected_signal_count),
            "fill_count": int(model.fill_count),
            "metadata": dict(model.metadata) if model.metadata else {},
            "snapshot_timestamp": model.snapshot_timestamp,
        }
