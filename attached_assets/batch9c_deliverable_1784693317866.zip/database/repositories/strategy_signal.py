"""StrategySignalRepository — session-injected CRUD for StrategySignalModel."""
from __future__ import annotations

from decimal import Decimal
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from database.models.strategy_signal import StrategySignalModel


class StrategySignalRepository:
    """Async repository for strategy signal persistence.

    Follows the project-wide contract:
    - AsyncSession is injected by the caller.
    - No commit, rollback, or close.
    - Domain objects hydrated without coupling ORM to domain contracts.
    """

    # ------------------------------------------------------------------
    # Save / upsert
    # ------------------------------------------------------------------
    async def save(
        self,
        signal_id: str,
        strategy_id: str,
        account_id: str,
        instrument_token: str,
        action: str,
        side: str,
        quantity: Decimal,
        order_type: str,
        limit_price: Optional[Decimal],
        trigger_price: Optional[Decimal],
        timestamp: datetime,
        routing_status: str,
        routed_client_order_id: Optional[str],
        rejection_reason: Optional[str],
        metadata: Optional[Dict[str, Any]],
        session: AsyncSession,
    ) -> StrategySignalModel:
        """Upsert a signal record by signal_id (idempotent save).

        If a record with the same signal_id already exists, update it.
        Returns the persisted ORM instance.
        """
        result = await session.execute(
            select(StrategySignalModel).where(
                StrategySignalModel.signal_id == signal_id
            )
        )
        existing: Optional[StrategySignalModel] = result.scalar_one_or_none()

        if existing is not None:
            existing.strategy_id = strategy_id
            existing.account_id = account_id
            existing.instrument_token = instrument_token
            existing.action = action
            existing.side = side
            existing.quantity = quantity
            existing.order_type = order_type
            existing.limit_price = limit_price
            existing.trigger_price = trigger_price
            existing.timestamp = timestamp
            existing.routing_status = routing_status
            existing.routed_client_order_id = routed_client_order_id
            existing.rejection_reason = rejection_reason
            existing.metadata = metadata or {}
            return existing

        model = StrategySignalModel(
            signal_id=signal_id,
            strategy_id=strategy_id,
            account_id=account_id,
            instrument_token=instrument_token,
            action=action,
            side=side,
            quantity=quantity,
            order_type=order_type,
            limit_price=limit_price,
            trigger_price=trigger_price,
            timestamp=timestamp,
            routing_status=routing_status,
            routed_client_order_id=routed_client_order_id,
            rejection_reason=rejection_reason,
            metadata=metadata or {},
        )
        session.add(model)
        return model

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------
    async def load(
        self,
        signal_id: str,
        session: AsyncSession,
    ) -> Optional[StrategySignalModel]:
        """Load a single signal by its natural key."""
        result = await session.execute(
            select(StrategySignalModel).where(
                StrategySignalModel.signal_id == signal_id
            )
        )
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # List pending signals (for recovery)
    # ------------------------------------------------------------------
    async def list_pending(
        self,
        session: AsyncSession,
        strategy_id: Optional[str] = None,
    ) -> List[StrategySignalModel]:
        """Return signals with routing_status == 'PENDING'.

        Optionally filtered by strategy_id.
        """
        stmt = select(StrategySignalModel).where(
            StrategySignalModel.routing_status == "PENDING"
        )
        if strategy_id is not None:
            stmt = stmt.where(StrategySignalModel.strategy_id == strategy_id)
        stmt = stmt.order_by(StrategySignalModel.timestamp)
        result = await session.execute(stmt)
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # List by strategy
    # ------------------------------------------------------------------
    async def list_by_strategy(
        self,
        strategy_id: str,
        session: AsyncSession,
    ) -> List[StrategySignalModel]:
        """Return all signals for a given strategy, ordered by timestamp."""
        result = await session.execute(
            select(StrategySignalModel)
            .where(StrategySignalModel.strategy_id == strategy_id)
            .order_by(StrategySignalModel.timestamp)
        )
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # Update routing status
    # ------------------------------------------------------------------
    async def update_routing_status(
        self,
        signal_id: str,
        routing_status: str,
        routed_client_order_id: Optional[str] = None,
        rejection_reason: Optional[str] = None,
        session: AsyncSession,
    ) -> bool:
        """Update the routing status of a signal.  Returns True if found."""
        values = {
            "routing_status": routing_status,
        }
        if routed_client_order_id is not None:
            values["routed_client_order_id"] = routed_client_order_id
        if rejection_reason is not None:
            values["rejection_reason"] = rejection_reason

        result = await session.execute(
            update(StrategySignalModel)
            .where(StrategySignalModel.signal_id == signal_id)
            .values(values)
        )
        return result.rowcount > 0

    # ------------------------------------------------------------------
    # Check if routed (dedup helper)
    # ------------------------------------------------------------------
    async def is_routed(
        self,
        signal_id: str,
        session: AsyncSession,
    ) -> bool:
        """Return True if the signal has already been routed (has a client_order_id)."""
        result = await session.execute(
            select(StrategySignalModel.routed_client_order_id).where(
                StrategySignalModel.signal_id == signal_id
            )
        )
        cid = result.scalar_one_or_none()
        return cid is not None

    # ------------------------------------------------------------------
    # Hydration helper
    # ------------------------------------------------------------------
    @staticmethod
    def to_dict(model: StrategySignalModel) -> Dict[str, Any]:
        """Serialize an ORM model to a plain dict suitable for domain reconstruction."""
        return {
            "signal_id": model.signal_id,
            "strategy_id": model.strategy_id,
            "account_id": model.account_id,
            "instrument_token": model.instrument_token,
            "action": model.action,
            "side": model.side,
            "quantity": model.quantity,
            "order_type": model.order_type,
            "limit_price": model.limit_price,
            "trigger_price": model.trigger_price,
            "timestamp": model.timestamp,
            "routing_status": model.routing_status,
            "routed_client_order_id": model.routed_client_order_id,
            "rejection_reason": model.rejection_reason,
            "metadata": dict(model.metadata) if model.metadata else {},
        }
