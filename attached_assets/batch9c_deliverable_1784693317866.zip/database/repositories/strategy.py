"""StrategyRepository — session-injected CRUD for StrategyModel."""
from __future__ import annotations

from decimal import Decimal
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from database.models.strategy import StrategyModel


class StrategyRepository:
    """Async repository for strategy persistence.

    Follows the project-wide contract:
    - AsyncSession is injected by the caller.
    - No commit, rollback, or close — transaction ownership stays with the caller.
    - Domain objects are hydrated without coupling ORM to domain contracts.
    """

    # ------------------------------------------------------------------
    # Save / upsert
    # ------------------------------------------------------------------
    async def save(
        self,
        strategy_id: str,
        strategy_type: str,
        name: str,
        account_id: str,
        configuration: Dict[str, Any],
        instrument_tokens: List[str],
        lifecycle_state: str,
        enabled: bool,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        session: AsyncSession,
    ) -> StrategyModel:
        """Upsert a strategy record by strategy_id.

        If a record with the same strategy_id already exists, update it
        (idempotent save).  Returns the persisted ORM instance.
        """
        now = datetime.now(timezone.utc)
        created_at = created_at or now
        updated_at = updated_at or now

        result = await session.execute(
            select(StrategyModel).where(StrategyModel.strategy_id == strategy_id)
        )
        existing: Optional[StrategyModel] = result.scalar_one_or_none()

        if existing is not None:
            existing.strategy_type = strategy_type
            existing.name = name
            existing.account_id = account_id
            existing.configuration = configuration
            existing.instrument_tokens = instrument_tokens
            existing.lifecycle_state = lifecycle_state
            existing.enabled = enabled
            existing.updated_at = updated_at
            return existing

        model = StrategyModel(
            strategy_id=strategy_id,
            strategy_type=strategy_type,
            name=name,
            account_id=account_id,
            configuration=configuration,
            instrument_tokens=instrument_tokens,
            lifecycle_state=lifecycle_state,
            enabled=enabled,
            created_at=created_at,
            updated_at=updated_at,
        )
        session.add(model)
        return model

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------
    async def load(
        self,
        strategy_id: str,
        session: AsyncSession,
    ) -> Optional[StrategyModel]:
        """Load a single strategy by its natural key."""
        result = await session.execute(
            select(StrategyModel).where(StrategyModel.strategy_id == strategy_id)
        )
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # List non-terminal (for recovery)
    # ------------------------------------------------------------------
    async def list_non_terminal(
        self,
        session: AsyncSession,
        terminal_states: Optional[List[str]] = None,
    ) -> List[StrategyModel]:
        """Return all strategies whose lifecycle_state is not terminal.

        Default terminal states: STOPPED, ERROR.
        """
        terminal_states = terminal_states or ["STOPPED", "ERROR"]
        result = await session.execute(
            select(StrategyModel).where(
                StrategyModel.lifecycle_state.notin_(terminal_states)
            )
        )
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # List all
    # ------------------------------------------------------------------
    async def list_all(
        self,
        session: AsyncSession,
    ) -> List[StrategyModel]:
        """Return every strategy record."""
        result = await session.execute(select(StrategyModel))
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # Update lifecycle state
    # ------------------------------------------------------------------
    async def update_lifecycle_state(
        self,
        strategy_id: str,
        lifecycle_state: str,
        session: AsyncSession,
    ) -> bool:
        """Update the lifecycle_state of a strategy.  Returns True if found."""
        result = await session.execute(
            update(StrategyModel)
            .where(StrategyModel.strategy_id == strategy_id)
            .values(lifecycle_state=lifecycle_state, updated_at=datetime.now(timezone.utc))
        )
        return result.rowcount > 0

    # ------------------------------------------------------------------
    # Hydration helpers (private — decouple ORM from domain)
    # ------------------------------------------------------------------
    @staticmethod
    def to_dict(model: StrategyModel) -> Dict[str, Any]:
        """Serialize an ORM model to a plain dict suitable for domain reconstruction."""
        return {
            "strategy_id": model.strategy_id,
            "strategy_type": model.strategy_type,
            "name": model.name,
            "account_id": model.account_id,
            "configuration": dict(model.configuration) if model.configuration else {},
            "instrument_tokens": list(model.instrument_tokens) if model.instrument_tokens else [],
            "lifecycle_state": model.lifecycle_state,
            "enabled": model.enabled,
            "created_at": model.created_at,
            "updated_at": model.updated_at,
        }
