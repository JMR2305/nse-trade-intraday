"""StrategyRecoveryManager — crash-recovery orchestrator for the Strategy Engine.

On service restart, this component:
1. Loads all non-terminal strategy records from the DB.
2. Reconstructs StrategyConfig and lifecycle state.
3. Re-registers strategy implementations via an injected factory/registry.
4. Restores PAUSED strategies without activating signal generation.
5. Restores ACTIVE strategies through STARTING and re-subscribes to market data.
6. Loads pending signals.
7. Deduplicates already-routed signals (never routes twice).
8. Re-queues genuinely pending and unrouted signals.
9. Returns a structured recovery result.

All errors are collected and reported — never silently swallowed.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Protocol, Set

from sqlalchemy.ext.asyncio import AsyncSession

from strategy.persistence import (
    StrategyConfigRecord,
    StrategyPersistenceAdapter,
    StrategySignalRecord,
    StrategyStateSnapshotRecord,
)

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Protocols for injected dependencies (decoupled from frozen internals)
# ------------------------------------------------------------------

class StrategyFactory(Protocol):
    """Protocol for a strategy factory that can create strategy instances."""

    async def create(
        self,
        strategy_type: str,
        strategy_id: str,
        config: Dict[str, Any],
    ) -> Any:
        """Instantiate a strategy implementation.  Returns a strategy handle."""
        ...


class StrategyRegistry(Protocol):
    """Protocol for a strategy registry that tracks running instances."""

    async def register(
        self,
        strategy_id: str,
        instance: Any,
        lifecycle_state: str,
    ) -> None:
        """Register a strategy instance with a given lifecycle state."""
        ...

    async def transition(
        self,
        strategy_id: str,
        target_state: str,
    ) -> bool:
        """Transition a strategy to a target lifecycle state."""
        ...

    async def subscribe_market_data(
        self,
        strategy_id: str,
        instrument_tokens: List[str],
    ) -> None:
        """Subscribe a strategy to market data for the given instruments."""
        ...

    async def is_registered(self, strategy_id: str) -> bool:
        """Return True if the strategy is already registered."""
        ...


class SignalRouter(Protocol):
    """Protocol for the signal router that queues signals for execution."""

    async def enqueue(self, signal: Any) -> None:
        """Enqueue a signal for routing to execution."""
        ...


# ------------------------------------------------------------------
# Recovery result types
# ------------------------------------------------------------------

@dataclass(frozen=True)
class StrategyRecoveryEntry:
    """Individual result for a single strategy recovery attempt."""
    strategy_id: str
    success: bool
    restored_state: Optional[str] = None
    error: Optional[str] = None


@dataclass(frozen=True)
class SignalRecoveryEntry:
    """Individual result for a single signal recovery attempt."""
    signal_id: str
    strategy_id: str
    requeued: bool
    skipped_already_routed: bool = False
    error: Optional[str] = None


@dataclass(frozen=True)
class StrategyRecoveryResult:
    """Structured result of the full recovery operation."""
    strategies_restored: List[str] = field(default_factory=list)
    strategies_skipped: List[str] = field(default_factory=list)
    signals_restored: int = 0
    signals_requeued: int = 0
    errors: List[str] = field(default_factory=list)
    recovery_timestamp: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    strategy_details: List[StrategyRecoveryEntry] = field(default_factory=list)
    signal_details: List[SignalRecoveryEntry] = field(default_factory=list)


# ------------------------------------------------------------------
# Recovery Manager
# ------------------------------------------------------------------

class StrategyRecoveryManager:
    """Orchestrates crash recovery for the Strategy Engine.

    Usage:
        manager = StrategyRecoveryManager(
            persistence=StrategyPersistenceAdapter(),
            factory=my_factory,
            registry=my_registry,
            signal_router=my_router,
        )
        result = await manager.recover(session)
    """

    # Terminal lifecycle states — strategies in these states are NOT recovered.
    TERMINAL_STATES: Set[str] = {"STOPPED", "ERROR"}

    def __init__(
        self,
        persistence: StrategyPersistenceAdapter,
        factory: StrategyFactory,
        registry: StrategyRegistry,
        signal_router: SignalRouter,
    ) -> None:
        self._persistence = persistence
        self._factory = factory
        self._registry = registry
        self._signal_router = signal_router

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    async def recover(
        self,
        session: AsyncSession,
    ) -> StrategyRecoveryResult:
        """Execute the full recovery pipeline.

        Idempotent — calling recover() twice on the same DB state is safe.
        Already-registered strategies are skipped.  Already-routed signals
        are skipped.  Already-requeued signals are skipped via signal_id
        deduplication in the router.
        """
        result = StrategyRecoveryResult()

        # Step 1: Load all non-terminal strategy records
        strategy_records = await self._persistence.list_non_terminal_strategies(
            session, terminal_states=list(self.TERMINAL_STATES)
        )
        logger.info(
            "Recovery: loaded %d non-terminal strategy record(s)",
            len(strategy_records),
        )

        # Step 2–5: Restore each strategy
        for record in strategy_records:
            entry = await self._recover_strategy(session, record)
            result.strategy_details.append(entry)
            if entry.success:
                result.strategies_restored.append(record.strategy_id)
            else:
                if entry.error:
                    result.errors.append(
                        f"Strategy {record.strategy_id}: {entry.error}"
                    )
                result.strategies_skipped.append(record.strategy_id)

        # Step 6–8: Load and re-queue pending signals
        pending_signals = await self._persistence.list_pending_signals(session)
        result.signals_restored = len(pending_signals)
        logger.info(
            "Recovery: loaded %d pending signal record(s)",
            len(pending_signals),
        )

        for sig in pending_signals:
            sig_entry = await self._recover_signal(session, sig)
            result.signal_details.append(sig_entry)
            if sig_entry.requeued:
                result.signals_requeued += 1
            if sig_entry.error:
                result.errors.append(
                    f"Signal {sig.signal_id}: {sig_entry.error}"
                )

        logger.info(
            "Recovery complete — restored=%d skipped=%d signals_requeued=%d errors=%d",
            len(result.strategies_restored),
            len(result.strategies_skipped),
            result.signals_requeued,
            len(result.errors),
        )
        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    async def _recover_strategy(
        self,
        session: AsyncSession,
        record: StrategyConfigRecord,
    ) -> StrategyRecoveryEntry:
        """Recover a single strategy instance.

        Flow:
        - Skip if already registered (idempotency).
        - Create strategy instance via factory.
        - Register with registry.
        - If PAUSED: restore directly to PAUSED (no market data subscription).
        - If ACTIVE: transition through STARTING, then subscribe to market data.
        - Load latest state snapshot and restore counters if available.
        """
        strategy_id = record.strategy_id

        # Idempotency: skip already-registered strategies
        if await self._registry.is_registered(strategy_id):
            logger.debug("Recovery: strategy %s already registered — skipping", strategy_id)
            return StrategyRecoveryEntry(
                strategy_id=strategy_id,
                success=False,
                error="Already registered",
            )

        try:
            # Reconstruct configuration dict
            config = dict(record.configuration) if record.configuration else {}

            # Create instance via injected factory
            instance = await self._factory.create(
                strategy_type=record.strategy_type,
                strategy_id=strategy_id,
                config=config,
            )

            # Register with lifecycle state from DB
            await self._registry.register(
                strategy_id=strategy_id,
                instance=instance,
                lifecycle_state="REGISTERED",
            )

            # Restore lifecycle state
            target_state = record.lifecycle_state
            if target_state == "PAUSED":
                # PAUSED: restore without activating signal generation
                await self._registry.transition(strategy_id, "STARTING")
                await self._registry.transition(strategy_id, "ACTIVE")
                await self._registry.transition(strategy_id, "PAUSED")
                logger.debug("Recovery: strategy %s restored to PAUSED", strategy_id)

            elif target_state == "ACTIVE":
                # ACTIVE: transition through STARTING, then subscribe
                await self._registry.transition(strategy_id, "STARTING")
                await self._registry.transition(strategy_id, "ACTIVE")
                await self._registry.subscribe_market_data(
                    strategy_id,
                    list(record.instrument_tokens) if record.instrument_tokens else [],
                )
                logger.debug(
                    "Recovery: strategy %s restored to ACTIVE and subscribed to market data",
                    strategy_id,
                )

            elif target_state == "STARTING":
                # STARTING: restore to STARTING (will be activated by caller or event)
                await self._registry.transition(strategy_id, "STARTING")
                logger.debug("Recovery: strategy %s restored to STARTING", strategy_id)

            elif target_state == "REGISTERED":
                # REGISTERED: leave as REGISTERED
                logger.debug("Recovery: strategy %s restored to REGISTERED", strategy_id)

            else:
                # Unknown state — log warning but do not fail
                logger.warning(
                    "Recovery: strategy %s has unknown lifecycle state '%s'",
                    strategy_id,
                    target_state,
                )

            # Load and apply latest state snapshot (counters, pending orders)
            snapshot = await self._persistence.load_latest_state_snapshot(
                session, strategy_id
            )
            if snapshot is not None:
                await self._apply_state_snapshot(strategy_id, snapshot)

            return StrategyRecoveryEntry(
                strategy_id=strategy_id,
                success=True,
                restored_state=target_state,
            )

        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            logger.exception("Recovery: failed to restore strategy %s", strategy_id)
            return StrategyRecoveryEntry(
                strategy_id=strategy_id,
                success=False,
                error=error_msg,
            )

    async def _recover_signal(
        self,
        session: AsyncSession,
        record: StrategySignalRecord,
    ) -> SignalRecoveryEntry:
        """Recover a single pending signal.

        Flow:
        - Skip if already routed (has routed_client_order_id).
        - Skip if router already knows this signal_id (idempotency).
        - Otherwise, reconstruct domain Signal and enqueue.
        """
        signal_id = record.signal_id
        strategy_id = record.strategy_id

        try:
            # Deduplication: never route a signal that already has a client_order_id
            if record.routed_client_order_id is not None:
                logger.debug(
                    "Recovery: signal %s already routed (order_id=%s) — skipping",
                    signal_id,
                    record.routed_client_order_id,
                )
                return SignalRecoveryEntry(
                    signal_id=signal_id,
                    strategy_id=strategy_id,
                    requeued=False,
                    skipped_already_routed=True,
                )

            # Build a lightweight signal envelope for the router.
            # We use a plain dict to avoid coupling to the frozen Signal contract.
            signal_envelope = {
                "signal_id": signal_id,
                "strategy_id": strategy_id,
                "account_id": record.account_id,
                "instrument_token": record.instrument_token,
                "action": record.action,
                "side": record.side,
                "quantity": record.quantity,
                "order_type": record.order_type,
                "limit_price": record.limit_price,
                "trigger_price": record.trigger_price,
                "timestamp": record.timestamp,
                "metadata": dict(record.metadata) if record.metadata else {},
            }

            # Enqueue via the injected signal router
            await self._signal_router.enqueue(signal_envelope)
            logger.debug("Recovery: signal %s re-queued for routing", signal_id)

            return SignalRecoveryEntry(
                signal_id=signal_id,
                strategy_id=strategy_id,
                requeued=True,
            )

        except Exception as exc:
            error_msg = f"{type(exc).__name__}: {exc}"
            logger.exception("Recovery: failed to re-queue signal %s", signal_id)
            return SignalRecoveryEntry(
                signal_id=signal_id,
                strategy_id=strategy_id,
                requeued=False,
                error=error_msg,
            )

    async def _apply_state_snapshot(
        self,
        strategy_id: str,
        snapshot: StrategyStateSnapshotRecord,
    ) -> None:
        """Apply a persisted state snapshot to a recovered strategy instance.

        This is a no-op placeholder because the frozen strategy runtime does
        not expose a public API for counter injection.  In a full integration,
        the registry or runtime would provide a method to restore counters.

        The snapshot is loaded and validated here so that future integration
        hooks have a well-defined entry point.
        """
        logger.debug(
            "Recovery: applying state snapshot for %s (signals=%d routed=%d rejected=%d fills=%d)",
            strategy_id,
            snapshot.emitted_signal_count,
            snapshot.routed_signal_count,
            snapshot.rejected_signal_count,
            snapshot.fill_count,
        )
        # Intentional no-op — frozen runtime internals are not modified.
        # When Batch 9D or a future batch exposes counter restoration APIs,
        # this method becomes the integration point.
