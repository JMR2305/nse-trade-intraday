"""Tests for Batch 9C.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from decimal import Decimal
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pytest
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

from database.models.base import Base
from database.models.strategy import StrategyModel
from database.models.strategy_signal import StrategySignalModel
from database.models.strategy_state import StrategyStateModel
from database.repositories.strategy import StrategyRepository
from database.repositories.strategy_signal import StrategySignalRepository
from database.repositories.strategy_state import StrategyStateRepository
from strategy.persistence import (
    StrategyConfigRecord, StrategySignalRecord, StrategyStateSnapshotRecord,
    StrategyPersistenceAdapter,
)
from strategy.recovery import (
    StrategyRecoveryManager, StrategyRecoveryResult,
)


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def async_engine():
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False, future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest.fixture
async def async_session(async_engine):
    async_session = async_sessionmaker(async_engine, expire_on_commit=False, class_=AsyncSession)
    async with async_session() as session:
        yield session
        await session.rollback()


@pytest.fixture
def strategy_repo():
    return StrategyRepository()


@pytest.fixture
def signal_repo():
    return StrategySignalRepository()


@pytest.fixture
def state_repo():
    return StrategyStateRepository()


@pytest.fixture
def persistence_adapter(strategy_repo, signal_repo, state_repo):
    return StrategyPersistenceAdapter(
        strategy_repo=strategy_repo,
        signal_repo=signal_repo,
        state_repo=state_repo,
    )


# ==================================================================
# 1. ORM Model Construction Tests
# ==================================================================

class TestStrategyModel:
    def test_model_inherits_base(self):
        assert issubclass(StrategyModel, Base)

    def test_table_name(self):
        assert StrategyModel.__tablename__ == "strategies"

    def test_has_uuid_primary_key(self):
        assert hasattr(StrategyModel, "id")

    def test_strategy_id_column(self):
        assert hasattr(StrategyModel, "strategy_id")

    def test_lifecycle_state_column(self):
        assert hasattr(StrategyModel, "lifecycle_state")

    def test_configuration_json_column(self):
        assert hasattr(StrategyModel, "configuration")

    def test_instrument_tokens_json_column(self):
        assert hasattr(StrategyModel, "instrument_tokens")

    def test_created_at_timezone_aware(self):
        col = StrategyModel.__table__.c.created_at
        assert col.type.timezone is True

    def test_updated_at_timezone_aware(self):
        col = StrategyModel.__table__.c.updated_at
        assert col.type.timezone is True

    def test_unique_constraint_on_strategy_id(self):
        constraints = [c.name for c in StrategyModel.__table__.constraints]
        assert "uq_strategies_strategy_id" in constraints

    def test_indexes_exist(self):
        idx_names = {idx.name for idx in StrategyModel.__table__.indexes}
        assert "ix_strategies_account_lifecycle" in idx_names
        assert "ix_strategies_type_state" in idx_names


class TestStrategySignalModel:
    def test_model_inherits_base(self):
        assert issubclass(StrategySignalModel, Base)

    def test_table_name(self):
        assert StrategySignalModel.__tablename__ == "strategy_signals"

    def test_quantity_is_numeric(self):
        col = StrategySignalModel.__table__.c.quantity
        assert str(col.type) == "NUMERIC(20, 8)"

    def test_limit_price_is_numeric(self):
        col = StrategySignalModel.__table__.c.limit_price
        assert str(col.type) == "NUMERIC(20, 8)"

    def test_trigger_price_is_numeric(self):
        col = StrategySignalModel.__table__.c.trigger_price
        assert str(col.type) == "NUMERIC(20, 8)"

    def test_timestamp_timezone_aware(self):
        col = StrategySignalModel.__table__.c.timestamp
        assert col.type.timezone is True

    def test_routing_status_default(self):
        col = StrategySignalModel.__table__.c.routing_status
        assert col.default.arg == "PENDING"

    def test_unique_constraint_on_signal_id(self):
        constraints = [c.name for c in StrategySignalModel.__table__.constraints]
        assert "uq_strategy_signals_signal_id" in constraints

    def test_pending_index_exists(self):
        idx_names = {idx.name for idx in StrategySignalModel.__table__.indexes}
        assert "ix_strategy_signals_pending" in idx_names

    def test_routed_coid_index_exists(self):
        idx_names = {idx.name for idx in StrategySignalModel.__table__.indexes}
        assert "ix_strategy_signals_routed_coid" in idx_names


class TestStrategyStateModel:
    def test_model_inherits_base(self):
        assert issubclass(StrategyStateModel, Base)

    def test_table_name(self):
        assert StrategyStateModel.__tablename__ == "strategy_state_snapshots"

    def test_emitted_signal_count_numeric(self):
        col = StrategyStateModel.__table__.c.emitted_signal_count
        assert str(col.type) == "NUMERIC(20, 0)"

    def test_snapshot_timestamp_timezone_aware(self):
        col = StrategyStateModel.__table__.c.snapshot_timestamp
        assert col.type.timezone is True

    def test_unique_constraint_strategy_timestamp(self):
        constraints = [c.name for c in StrategyStateModel.__table__.constraints]
        assert "uq_strategy_state_snapshots_strategy_timestamp" in constraints

    def test_latest_index_exists(self):
        idx_names = {idx.name for idx in StrategyStateModel.__table__.indexes}
        assert "ix_strategy_state_snapshots_strategy_latest" in idx_names


# ==================================================================
# 2. Repository Save / Load / Update Tests
# ==================================================================

class TestStrategyRepository:
    async def test_save_new_strategy(self, async_session, strategy_repo):
        model = await strategy_repo.save(
            strategy_id="s1", strategy_type="SMA_CROSSOVER", name="Test Strategy",
            account_id="acc1", configuration={"fast": 10, "slow": 20},
            instrument_tokens=["12345"], lifecycle_state="REGISTERED",
            enabled=True, session=async_session,
        )
        assert model.strategy_id == "s1"
        assert model.strategy_type == "SMA_CROSSOVER"

    async def test_save_is_upsert(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s1", strategy_type="SMA_CROSSOVER", name="Test Strategy",
            account_id="acc1", configuration={"fast": 10},
            instrument_tokens=["12345"], lifecycle_state="REGISTERED",
            enabled=True, session=async_session,
        )
        model2 = await strategy_repo.save(
            strategy_id="s1", strategy_type="SMA_CROSSOVER", name="Updated Name",
            account_id="acc1", configuration={"fast": 15},
            instrument_tokens=["12345", "67890"], lifecycle_state="ACTIVE",
            enabled=True, session=async_session,
        )
        assert model2.name == "Updated Name"
        assert model2.lifecycle_state == "ACTIVE"

    async def test_load_existing(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s1", strategy_type="T", name="N", account_id="a",
            configuration={}, instrument_tokens=[], lifecycle_state="R",
            enabled=True, session=async_session,
        )
        loaded = await strategy_repo.load("s1", async_session)
        assert loaded is not None
        assert loaded.strategy_id == "s1"

    async def test_load_missing_returns_none(self, async_session, strategy_repo):
        loaded = await strategy_repo.load("missing", async_session)
        assert loaded is None

    async def test_list_non_terminal_excludes_stopped(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s_active", strategy_type="T", name="A", account_id="a",
            configuration={}, instrument_tokens=[], lifecycle_state="ACTIVE",
            enabled=True, session=async_session,
        )
        await strategy_repo.save(
            strategy_id="s_stopped", strategy_type="T", name="S", account_id="a",
            configuration={}, instrument_tokens=[], lifecycle_state="STOPPED",
            enabled=True, session=async_session,
        )
        non_term = await strategy_repo.list_non_terminal(async_session)
        ids = {m.strategy_id for m in non_term}
        assert "s_active" in ids
        assert "s_stopped" not in ids

    async def test_list_non_terminal_excludes_error(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s_err", strategy_type="T", name="E", account_id="a",
            configuration={}, instrument_tokens=[], lifecycle_state="ERROR",
            enabled=True, session=async_session,
        )
        non_term = await strategy_repo.list_non_terminal(async_session)
        assert all(m.strategy_id != "s_err" for m in non_term)

    async def test_update_lifecycle_state(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s1", strategy_type="T", name="N", account_id="a",
            configuration={}, instrument_tokens=[], lifecycle_state="REGISTERED",
            enabled=True, session=async_session,
        )
        ok = await strategy_repo.update_lifecycle_state("s1", "ACTIVE", async_session)
        assert ok is True
        loaded = await strategy_repo.load("s1", async_session)
        assert loaded.lifecycle_state == "ACTIVE"

    async def test_update_lifecycle_state_missing_returns_false(self, async_session, strategy_repo):
        ok = await strategy_repo.update_lifecycle_state("missing", "ACTIVE", async_session)
        assert ok is False

    async def test_to_dict_hydration(self, async_session, strategy_repo):
        await strategy_repo.save(
            strategy_id="s1", strategy_type="T", name="N", account_id="a",
            configuration={"k": "v"}, instrument_tokens=["t1"],
            lifecycle_state="ACTIVE", enabled=True, session=async_session,
        )
        loaded = await strategy_repo.load("s1", async_session)
        data = StrategyRepository.to_dict(loaded)
        assert data["strategy_id"] == "s1"
        assert data["configuration"] == {"k": "v"}
        assert data["instrument_tokens"] == ["t1"]
