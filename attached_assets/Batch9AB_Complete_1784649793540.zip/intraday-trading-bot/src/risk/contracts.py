"""Stub for risk/contracts.py - RC-8 frozen module."""
from decimal import Decimal
from enum import Enum
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any


class RiskSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    FATAL = "FATAL"


class RiskCheckType(str, Enum):
    KILL_SWITCH = "KILL_SWITCH"
    EMERGENCY_HALT = "EMERGENCY_HALT"
    CIRCUIT_BREAKER = "CIRCUIT_BREAKER"
    ORDER_QUANTITY = "ORDER_QUANTITY"
    ORDER_VALUE = "ORDER_VALUE"
    TICK_SIZE = "TICK_SIZE"
    PRICE_BAND = "PRICE_BAND"
    MAX_POSITION_SIZE = "MAX_POSITION_SIZE"
    INSTRUMENT_EXPOSURE = "INSTRUMENT_EXPOSURE"
    NET_EXPOSURE = "NET_EXPOSURE"
    CONCENTRATION_LIMIT = "CONCENTRATION_LIMIT"
    CASH_AVAILABILITY = "CASH_AVAILABILITY"
    BUYING_POWER = "BUYING_POWER"
    PORTFOLIO_EXPOSURE = "PORTFOLIO_EXPOSURE"
    MARGIN_AVAILABILITY = "MARGIN_AVAILABILITY"
    DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
    DAILY_PROFIT_TARGET_LOCK = "DAILY_PROFIT_TARGET_LOCK"
    MAX_TRADES_PER_DAY = "MAX_TRADES_PER_DAY"
    MAX_ORDERS_PER_MINUTE = "MAX_ORDERS_PER_MINUTE"
    DRAWDOWN = "DRAWDOWN"


class RiskViolation(BaseModel, frozen=True):
    check_type: RiskCheckType
    severity: RiskSeverity
    message: str
    rule_id: str


class RiskResult(BaseModel, frozen=True):
    approved: bool
    violations: List[RiskViolation] = Field(default_factory=list)
    check_timestamp: datetime = Field(default_factory=datetime.utcnow)

    @property
    def action(self) -> str:
        if any(v.severity == RiskSeverity.FATAL for v in self.violations):
            return "KILL_SWITCH"
        elif any(v.severity == RiskSeverity.CRITICAL for v in self.violations):
            return "BLOCK"
        elif self.violations:
            return "WARN"
        return "ALLOW"

    @property
    def has_critical(self) -> bool:
        return any(v.severity in (RiskSeverity.CRITICAL, RiskSeverity.FATAL) for v in self.violations)


class RiskStateSnapshot(BaseModel, frozen=True):
    account_id: str
    snapshot_timestamp: datetime
    daily_realized_pnl: Decimal = Decimal("0")
    daily_turnover: Decimal = Decimal("0")
    trade_count: int = 0
    order_count: int = 0
    peak_equity: Decimal = Decimal("0")
    kill_switch_active: bool = False
    kill_switch_reason: Optional[str] = None
    emergency_halt_active: bool = False
    circuit_breaker_triggered: bool = False
    message_counts: Dict[str, int] = Field(default_factory=dict)
    extra_metadata: Dict[str, Any] = Field(default_factory=dict)


class RiskRequest(BaseModel, frozen=True):
    account_id: str
    instrument_token: str
    side: str
    quantity: Decimal
    price: Optional[Decimal] = None
    order_type: str = "MARKET"


class RiskContext(BaseModel, frozen=True):
    account_id: str
    portfolio_value: Decimal = Decimal("0")
    available_cash: Decimal = Decimal("0")
    current_positions: Dict[str, Decimal] = Field(default_factory=dict)
    market_price: Optional[Decimal] = None
