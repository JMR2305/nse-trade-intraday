"""Stub for risk/integration_layer.py - RC-8 frozen module."""
from typing import Optional
from abc import ABC, abstractmethod
from risk.contracts import RiskResult, RiskRequest, RiskContext
from execution.contracts import ExecutionOrder


class ExecutionEnginePort(ABC):
    @abstractmethod
    async def submit_order(self, account_id: str, order: ExecutionOrder) -> dict:
        ...

    @abstractmethod
    def get_market_price(self, instrument_token: str) -> Optional[float]:
        ...


class RiskIntegrationLayer:
    """Minimal stub for RiskIntegrationLayer."""

    def __init__(self, engine=None, enabled: bool = True):
        self._engine = engine
        self._enabled = enabled
        self._port: Optional[ExecutionEnginePort] = None

    def set_port(self, port: ExecutionEnginePort) -> None:
        self._port = port

    async def submit_order(self, account_id: str, order: ExecutionOrder) -> dict:
        if not self._enabled:
            if self._port:
                return await self._port.submit_order(account_id, order)
            return {"status": "APPROVED"}

        # Minimal stub - just approve
        if self._port:
            return await self._port.submit_order(account_id, order)
        return {"status": "APPROVED"}

    def disable(self) -> None:
        self._enabled = False

    def enable(self) -> None:
        self._enabled = True
