"""Stub for risk/fill_event_bus.py - RC-8 frozen module."""
from typing import Callable, Dict, List
from execution.fills import FillEvent


class FillEventBus:
    """Pub/sub bus for fill events."""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}

    def subscribe(self, account_id: str, callback: Callable[[FillEvent], None]) -> None:
        if account_id not in self._subscribers:
            self._subscribers[account_id] = []
        self._subscribers[account_id].append(callback)

    def unsubscribe(self, account_id: str, callback: Callable[[FillEvent], None]) -> None:
        if account_id in self._subscribers:
            if callback in self._subscribers[account_id]:
                self._subscribers[account_id].remove(callback)

    def publish(self, fill_event: FillEvent) -> None:
        # In real implementation, account_id would be derived from fill_event
        # For stub, we broadcast to all
        for account_id, callbacks in self._subscribers.items():
            for callback in callbacks:
                callback(fill_event)
