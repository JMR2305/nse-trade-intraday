"""Domain contracts for the Strategy Engine.

All types are Pydantic v2 models with frozen=True.
All monetary values use Decimal.
"""
from __future__ import annotations

from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
from pydantic import BaseModel, Field

from execution.contracts import (
    ExecutionOrderSide,
    ExecutionOrderType,
    ExecutionOrder,
)
from execution.fills import FillEvent
from execution.portfolio import PortfolioSnapshot, PositionSnapshot
from market_data.contracts import CompletedBar, Tick
from risk.contracts import RiskStateSnapshot


class SignalAction(str, Enum):
    """Actions that a strategy signal can represent."""
    ENTER_LONG = "ENTER_LONG"
    EXIT_LONG = "EXIT_LONG"
    ENTER_SHORT = "ENTER_SHORT"
    EXIT_SHORT = "EXIT_SHORT"
    HOLD = "HOLD"
    REBALANCE = "REBALANCE"


class StrategyLifecycleState(str, Enum):
    """Lifecycle states for a strategy instance."""
    REGISTERED = "REGISTERED"
    STARTING = "STARTING"
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    STOPPING = "STOPPING"
    STOPPED = "STOPPED"
    ERROR = "ERROR"


class Signal(BaseModel, frozen=True):
    """Immutable trading signal emitted by a strategy.

    A signal represents a trading intent that the strategy runtime
    will validate, map to an order, and route through execution.
    """
    signal_id: UUID = Field(default_factory=uuid4)
    strategy_id: str
    instrument_token: str
    action: SignalAction
    side: ExecutionOrderSide
    quantity: Decimal = Field(..., gt=Decimal("0"))
    order_type: ExecutionOrderType = ExecutionOrderType.MARKET
    limit_price: Optional[Decimal] = None
    trigger_price: Optional[Decimal] = None
    reason: str = ""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @property
    def is_entry(self) -> bool:
        return self.action in (SignalAction.ENTER_LONG, SignalAction.ENTER_SHORT)

    @property
    def is_exit(self) -> bool:
        return self.action in (SignalAction.EXIT_LONG, SignalAction.EXIT_SHORT)


class StrategyConfig(BaseModel, frozen=True):
    """Immutable configuration for a strategy instance.

    This is the contract that users provide when registering a strategy.
    It is persisted and used to reconstruct the strategy on restart.
    """
    strategy_id: str
    strategy_type: str
    name: str
    description: Optional[str] = None
    instrument_tokens: List[str] = Field(default_factory=list)
    bar_timeframe: str = "1m"
    parameters: Dict[str, Any] = Field(default_factory=dict)
    max_position_quantity: Decimal = Decimal("1000")
    max_orders_per_minute: int = 10
    enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)


class StrategyContext(BaseModel, frozen=True):
    """Per-strategy view of market + portfolio + risk state.

    This is a snapshot-in-time view constructed by the ContextBuilder
    and passed to strategy callbacks. It is immutable and safe to
    share across coroutines.
    """
    strategy_id: str
    timestamp: datetime
    market_snapshots: Dict[str, Any] = Field(default_factory=dict)
    portfolio: PortfolioSnapshot = Field(default_factory=PortfolioSnapshot)
    strategy_positions: Dict[str, PositionSnapshot] = Field(default_factory=dict)
    risk_state: RiskStateSnapshot = Field(
        default_factory=lambda: RiskStateSnapshot(account_id="", snapshot_timestamp=datetime.utcnow())
    )
    strategy_state: StrategyStateSnapshot = Field(
        default_factory=lambda: StrategyStateSnapshot(strategy_id="", lifecycle_state=StrategyLifecycleState.REGISTERED)
    )


class StrategyStateSnapshot(BaseModel, frozen=True):
    """Frozen point-in-time capture of mutable strategy runtime state.

    Used for persistence and for passing state into the StrategyContext.
    """
    strategy_id: str
    lifecycle_state: StrategyLifecycleState = StrategyLifecycleState.REGISTERED
    current_signals: List[Signal] = Field(default_factory=list)
    pending_orders: List[str] = Field(default_factory=list)
    filled_today: int = 0
    rejected_today: int = 0
    last_signal_timestamp: Optional[datetime] = None
    extra_metadata: Dict[str, Any] = Field(default_factory=dict)


class StrategyPerformanceSnapshot(BaseModel, frozen=True):
    """Frozen performance metrics for a strategy.

    Captured at a point in time for reporting and persistence.
    All monetary values are Decimal.
    """
    strategy_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: Decimal = Decimal("0")
    avg_profit_per_trade: Decimal = Decimal("0")
    avg_loss_per_trade: Decimal = Decimal("0")
    profit_factor: Decimal = Decimal("0")
    max_drawdown: Decimal = Decimal("0")
    max_drawdown_pct: Decimal = Decimal("0")
    realized_pnl: Decimal = Decimal("0")
    unrealized_pnl: Decimal = Decimal("0")
    sharpe_ratio: Optional[Decimal] = None
    return_pct: Optional[Decimal] = None


class SignalRoutingResult(BaseModel, frozen=True):
    """Result of routing a signal through the SignalRouter.

    Contains the outcome of validation, conflict detection, and order submission.
    """
    signal_id: UUID
    routed: bool
    client_order_id: Optional[str] = None
    status: str = "PENDING"  # PENDING, ROUTED, REJECTED, ERROR
    rejection_reason: Optional[str] = None
    violations: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class StrategyRegistrationResult(BaseModel, frozen=True):
    """Result of registering a strategy with the StrategyCoordinator."""
    strategy_id: str
    success: bool
    error_message: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ConflictResolution(BaseModel, frozen=True):
    """Result of conflict detection between two or more signals."""
    has_conflict: bool
    conflict_reason: Optional[str] = None
    resolved_signal: Optional[Signal] = None
    rejected_signals: List[Signal] = Field(default_factory=list)
