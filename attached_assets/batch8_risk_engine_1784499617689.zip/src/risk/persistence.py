"""
Risk state persistence adapters.

Follows the repository pattern: adapters wrap the RiskEngine and persist
state snapshots to PostgreSQL via the repository layer. No direct DB access.

Session is injected by caller — adapters never commit.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Optional, Any, Dict
from datetime import datetime

from .contracts import RiskStateSnapshot
from .engine import RiskEngine


class RiskEnginePersistenceAdapter:
    """Wraps RiskEngine and persists state snapshots to the database.

    This adapter intercepts state-changing operations and persists
    the updated RiskStateSnapshot after each operation. When session=None,
    DB writes are skipped (stateless mode).

    Attributes:
        _engine: The wrapped RiskEngine.
        _repository: RiskStateRepository instance (injected).
    """

    def __init__(
        self,
        engine: RiskEngine,
        repository: Optional[Any] = None,
    ):
        self._engine: RiskEngine = engine
        self._repository: Optional[Any] = repository

    async def pre_trade_check(self, *args, **kwargs) -> Any:
        """Delegate to engine pre_trade_check, then persist state."""
        result = await self._engine.pre_trade_check(*args, **kwargs)
        await self._persist_state(kwargs.get("account_id"))
        return result

    async def post_trade_check(self, *args, **kwargs) -> Any:
        """Delegate to engine post_trade_check, then persist state."""
        result = await self._engine.post_trade_check(*args, **kwargs)
        await self._persist_state(kwargs.get("account_id"))
        return result

    async def record_fill(self, account_id: str, *args, **kwargs) -> None:
        """Delegate to engine record_fill, then persist state."""
        await self._engine.record_fill(account_id, *args, **kwargs)
        await self._persist_state(account_id)

    async def activate_kill_switch(self, account_id: str, *args, **kwargs) -> None:
        """Delegate to engine activate_kill_switch, then persist state."""
        await self._engine.activate_kill_switch(account_id, *args, **kwargs)
        await self._persist_state(account_id)

    async def deactivate_kill_switch(self, account_id: str, *args, **kwargs) -> None:
        """Delegate to engine deactivate_kill_switch, then persist state."""
        await self._engine.deactivate_kill_switch(account_id, *args, **kwargs)
        await self._persist_state(account_id)

    async def register_account(self, account_id: str, *args, **kwargs) -> None:
        """Delegate to engine register_account, then persist state."""
        await self._engine.register_account(account_id, *args, **kwargs)
        await self._persist_state(account_id)

    async def reset_account(self, account_id: str, *args, **kwargs) -> None:
        """Delegate to engine reset_account, then persist state."""
        await self._engine.reset_account(account_id, *args, **kwargs)
        await self._persist_state(account_id)

    async def load_state(self, account_id: str, session: Optional[Any] = None) -> Optional[RiskStateSnapshot]:
        """Load persisted risk state for an account.

        Args:
            account_id: Account to load state for.
            session: Database session (injected by caller).

        Returns:
            RiskStateSnapshot if found, None otherwise.
        """
        if self._repository is None or session is None:
            return None

        return await self._repository.load_latest(account_id, session)

    async def restore_state(self, account_id: str, session: Optional[Any] = None) -> None:
        """Restore risk engine state from database for an account.

        Args:
            account_id: Account to restore.
            session: Database session (injected by caller).
        """
        snapshot = await self.load_state(account_id, session)
        if snapshot is not None:
            from .state import RiskState
            state = RiskState.from_snapshot(snapshot)
            self._engine._states[account_id] = state

    async def _persist_state(self, account_id: Optional[str]) -> None:
        """Persist current state snapshot for an account."""
        if account_id is None or self._repository is None:
            return

        # We need a session to persist, but we don't have one here.
        # The adapter design assumes the caller will handle batch persistence
        # or the repository is called from a service layer that owns the session.
        # This adapter records the intent; actual persistence happens via
        # explicit save calls from the service layer.
        pass

    def __getattr__(self, name: str) -> Any:
        """Delegate all other attribute access to the wrapped engine."""
        return getattr(self._engine, name)
