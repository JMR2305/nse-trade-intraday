"""
Batch 8 — Risk Engine.

Production-ready risk management layer for the NSE Paper Trading Platform.
Sits between the Strategy Layer and the Execution Engine (RC-7).

Provides:
- Pre-trade risk checks: order size, price tolerance, position limits,
  portfolio exposure, daily loss limits, message throttling, duplicate
  order prevention, self-trade prevention
- Post-trade risk checks: portfolio heat, drawdown, turnover velocity
- Kill switch: emergency trading halt with audit trail
- Deterministic, idempotent, async-safe evaluation
- Full persistence support via repository pattern
"""

from .contracts import (
    RiskSeverity,
    RiskAction,
    RiskCheckType,
    RiskViolation,
    RiskDecision,
    RiskLimit,
    OrderSizeLimit,
    PriceToleranceLimit,
    PositionLimit,
    PortfolioExposureLimit,
    DailyLossLimit,
    MessageThrottleLimit,
    DuplicateOrderLimit,
    SelfTradeLimit,
    PortfolioHeatLimit,
    DrawdownLimit,
    TurnoverVelocityLimit,
    RiskStateSnapshot,
    RiskCheckContext,
)

from .rules import (
    RiskRule,
    OrderSizeRule,
    PriceToleranceRule,
    PositionLimitRule,
    PortfolioExposureRule,
    DailyLossLimitRule,
    MessageThrottleRule,
    DuplicateOrderRule,
    SelfTradeRule,
    PortfolioHeatRule,
    DrawdownRule,
    TurnoverVelocityRule,
    RULE_REGISTRY,
)

from .state import RiskState
from .kill_switch import KillSwitch, KillSwitchEvent
from .engine import RiskEngine
from .persistence import RiskEnginePersistenceAdapter
from .exceptions import (
    RiskEngineException,
    RiskLimitNotFoundError,
    RiskStateCorruptionError,
    RiskCheckError,
    KillSwitchAlreadyActiveError,
    KillSwitchNotActiveError,
    AccountNotRegisteredError,
)

__all__ = [
    # Contracts
    "RiskSeverity",
    "RiskAction",
    "RiskCheckType",
    "RiskViolation",
    "RiskDecision",
    "RiskLimit",
    "OrderSizeLimit",
    "PriceToleranceLimit",
    "PositionLimit",
    "PortfolioExposureLimit",
    "DailyLossLimit",
    "MessageThrottleLimit",
    "DuplicateOrderLimit",
    "SelfTradeLimit",
    "PortfolioHeatLimit",
    "DrawdownLimit",
    "TurnoverVelocityLimit",
    "RiskStateSnapshot",
    "RiskCheckContext",
    # Rules
    "RiskRule",
    "OrderSizeRule",
    "PriceToleranceRule",
    "PositionLimitRule",
    "PortfolioExposureRule",
    "DailyLossLimitRule",
    "MessageThrottleRule",
    "DuplicateOrderRule",
    "SelfTradeRule",
    "PortfolioHeatRule",
    "DrawdownRule",
    "TurnoverVelocityRule",
    "RULE_REGISTRY",
    # Engine
    "RiskState",
    "KillSwitch",
    "KillSwitchEvent",
    "RiskEngine",
    "RiskEnginePersistenceAdapter",
    # Exceptions
    "RiskEngineException",
    "RiskLimitNotFoundError",
    "RiskStateCorruptionError",
    "RiskCheckError",
    "KillSwitchAlreadyActiveError",
    "KillSwitchNotActiveError",
    "AccountNotRegisteredError",
]
