"""
Risk State ORM Model.

SQLAlchemy declarative model for persisting risk engine state snapshots.
Inherits from the shared Base in database/models/base.py.

All monetary columns use Numeric(20, 8) for Decimal fidelity.
All timestamps are DateTime(timezone=True).
"""

from __future__ import annotations

from sqlalchemy import Column, String, DateTime, Numeric, Boolean, Text, JSON
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import declarative_base
import uuid

# Import from the shared base — in production this would be:
# from database.models.base import Base
# For Batch 8 standalone, we define it locally for clarity
Base = declarative_base()


class RiskStateModel(Base):
    """ORM model for risk_state_snapshots table.

    Stores point-in-time snapshots of RiskState for crash recovery.
    Each row represents one snapshot for one account.
    """

    __tablename__ = "risk_state_snapshots"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    account_id = Column(String(64), nullable=False, index=True)
    snapshot_timestamp = Column(DateTime(timezone=True), nullable=False, index=True)

    # Monetary fields — Decimal precision
    daily_realized_pnl = Column(Numeric(20, 8), nullable=False, default=0)
    daily_turnover = Column(Numeric(20, 8), nullable=False, default=0)
    peak_equity = Column(Numeric(20, 8), nullable=False, default=0)

    # Kill switch state
    kill_switch_active = Column(Boolean, nullable=False, default=False)
    kill_switch_reason = Column(Text, nullable=True)

    # Message counts stored as JSONB
    message_counts = Column(JSONB, nullable=False, default=dict)

    # Metadata for extensibility
    metadata = Column(JSONB, nullable=False, default=dict)

    __table_args__ = (
        # Ensure we can efficiently find the latest snapshot per account
        {"postgresql_indexes": [
            {"name": "ix_risk_state_account_timestamp", "columns": ["account_id", "snapshot_timestamp"], "unique": False}
        ]}
    )
