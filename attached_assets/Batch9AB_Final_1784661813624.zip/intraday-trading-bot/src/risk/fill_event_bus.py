"""Stub for risk/fill_event_bus.py - RC-8 frozen module.

This stub routes fills by account_id, matching the real RC-8 behavior.
"""
from typing import Callable, Dict, List
from execution.fills import FillEvent


class FillEventBus:
    """Pub/sub bus for fill events. Routes by account_id."""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}

    def subscribe(self, account_id: str, callback: Callable[[FillEvent], None]) -> None:
        if account_id not in self._subscribers:
            self._subscribers[account_id] = []
        self._subscribers[account_id].append(callback)

    def unsubscribe(self, account_id: str, callback: Callable[[FillEvent], None]) -> None:
        if account_id in self._subscribers:
            if callback in self._subscribers[account_id]:
                self._subscribers[account_id].remove(callback)

    def publish(self, fill_event: FillEvent, account_id: str) -> None:
        """Publish a fill event to subscribers for the given account_id."""
        for callback in self._subscribers.get(account_id, []):
            callback(fill_event)
