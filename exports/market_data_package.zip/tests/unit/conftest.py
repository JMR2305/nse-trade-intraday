"""pytest configuration for unit tests.

Ensures 'src' package is importable by adding the project root to sys.path.
"""
import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))
